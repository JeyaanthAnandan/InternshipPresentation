# PRS baseline prompts

Agent prompts that work out the **performance, resilience and security (PRS)** baseline of a repository. They find which best practices apply to it and whether each one is implemented. The prompts work on backend services, frontends, batch jobs and CLIs.

Test evidence (whether tests verify each practice) is a later step and is not included yet.

## How it works

```
                         ┌──────────────────────────────────────────┐
 Session 1               │ 01-fact-discovery/fact-discovery.md      │──► out/facts.json
 (one per repo)          │ inventory: components, app types, entry  │     (+ one routing job per
                         │ points, dependencies, sinks, deployments │      component × app type)
                         └───────────────┬──────────────────────────┘
                                         │ hands off each job to a NEW session
                 ┌───────────────┬───────┴───────┬───────────────┐
 Session 2..n    ▼               ▼               ▼               ▼
 (one per job)  backend_service  frontend_web    batch_job       cli_tool      02-applicability/<type>.md
                 │ facts.json only — no repo reading; numbered first-match rules
                 ▼                                                            ──► out/applicability/<slug>__<type>.json
 Session n+1..   03-implementation-check/<type>.md
 (one per job)   reads code/config; fixed criteria, pitfalls, defaults tables ──► out/implementation/<slug>__<type>.json
```

Each session reads only files written by earlier sessions plus the repository. Nothing depends on chat history, so any step can be re-run on its own.

## Folder layout

| Path | What it is |
|---|---|
| `shared/conventions.md` | Rules every session follows: IDs, statuses, evidence format, exclusions, ordering, the ownership rule. |
| `shared/practice-catalog.yaml` | The fixed list of 62 practices (14 performance, 21 resilience, 27 security) with IDs, scope, app types, severity and references. **The single source of practice IDs.** |
| `shared/overrides.example.yaml` | Template for human-supplied knowledge the code cannot show: public endpoints, ASVS level, latency targets, gateway or edge controls. |
| `01-fact-discovery/fact-discovery.md` | Session 1. Inventory procedure, per-language signal tables, `facts.json` format, routing and hand-off. |
| `02-applicability/<app_type>.md` | One per app type. Numbered rules per practice, evaluated first match wins, using facts only. |
| `03-implementation-check/<app_type>.md` | One per app type. Criteria (`I…`), pitfalls (`P…`), library-default tables and status rules per practice. |
| `schemas/*.schema.json` | JSON Schemas for the three outputs, which are the contracts between sessions. |
| `tools/prs_tools.py` | `validate`, `canonicalize`, `compare` (run-to-run consistency) and `summarize` (markdown table). |
| `examples/out/` | A small worked example (a Python click CLI) that passes `validate`. It shows the output format only; it is not used as input by the prompts. |

## Running it

Prerequisites: an agent that can read files and run read-only shell commands (`rg`/`grep`). Python 3.9+ with `pip install pyyaml jsonschema` is needed for the checker.

1. Optional: copy `shared/overrides.example.yaml` next to the repository, then edit it.
2. **Session 1:** start an agent with:
   ```
   Read <PROMPTS>/shared/conventions.md, then follow <PROMPTS>/01-fact-discovery/fact-discovery.md.
   PROMPTS=<path to this folder> CODE_ROOT=<repo path> CONFIG_PATHS=<extra config paths or none>
   OVERRIDES=<overrides file or none> OUT=<output dir>
   ```
   It writes `OUT/facts.json`. Then, for each routing job, it starts a new session with the applicability prompt for that app type, or prints the hand-off messages if it cannot start sessions.
3. **Applicability sessions** (one per job, can run in parallel) write `OUT/applicability/<slug>__<app_type>.json`. Each hands off to its implementation-check session.
4. **Implementation sessions** write `OUT/implementation/<slug>__<app_type>.json`.
5. Check and summarize:
   ```
   python tools/prs_tools.py validate OUT
   python tools/prs_tools.py summarize OUT --write      # writes OUT/summary.md
   ```

**Repos with several app types.** A component can be, for example, a Spring Boot service with `@Scheduled` tasks, or a Next.js app with API routes. It gets one job per app type. The **primary** job, chosen by the priority `backend_service > frontend_web > batch_job > cli_tool`, evaluates everything for its type. A **secondary** job evaluates only its own units plus practices the primary type does not have. The validator rejects any result evaluated twice.

## Why the results stay consistent

| Design choice | Effect |
|---|---|
| Closed catalog with stable IDs; no step may add or rename practices | Every run evaluates the same practices. |
| Fact discovery records surfaces only; judgments come later | The step that varies most has the simplest job. |
| Applicability uses **only** `facts.json` plus overrides, through numbered first-match rules | The same facts always give the same applicability result. |
| Missing facts become `undetermined`, never a guess | Gaps show up instead of flipping between runs. |
| Fixed criteria/pitfall IDs and a fixed status-decision order | Implementation verdicts are reproducible and auditable. |
| Library defaults come only from the tables in the prompts; unknown defaults give `cannot_verify_statically` | Defaults are never recalled from memory. |
| Semantic IDs (routes, symbols, config keys), never line numbers | IDs survive refactors and reformatting. |
| `canonicalize` sorts keys and arrays | Two runs can be diffed directly. |
| `validate` enforces completeness, ordering, catalog values and the ownership rule | Format drift is caught mechanically. |

Recommended runtime settings:

- Pin the model version.
- Use the lowest temperature your platform allows.
- Start a fresh session for every step.
- Keep the prompt versions (`version:` in each file's front matter) unchanged between runs you compare.

To measure consistency, run the pipeline twice into two output folders and run:

```
python tools/prs_tools.py compare OUT_run1 OUT_run2
```

This prints Jaccard similarity for each inventory list and the agreement rate for applicability and implementation verdicts, and lists every difference. Expect most remaining variance in step 1 (missed or extra units) and step 3 (borderline evidence). Step 2 should agree almost completely when step 1 agrees.

## Extending

- **New practice:** add it to `shared/practice-catalog.yaml` with a new ID (never reuse or renumber IDs). Add its rule table to every listed `02-applicability/<type>.md` and its criteria to every `03-implementation-check/<type>.md`. Bump the `version:` of the prompts you changed.
- **New framework or library:** add its signals to `01-fact-discovery` Appendix A and its defaults to the relevant `03-*` tables. Rules and IDs stay the same.
- **New app type:** add it to conventions §3 (including the primary priority), add a `02-` and a `03-` prompt, and add the app type to the schemas' enums and to `APP_TYPES` in `tools/prs_tools.py`.
- **Test evidence (next step):** a `04-test-evidence/<type>.md` prompt can read the implementation files and the test repo. It can reuse the same `result_id`s and add a test status per result.

## Limits

- **Static analysis only.** Actual latency, Core Web Vitals, job duration and object-level authorization correctness need runtime data. Those results carry a note or `cannot_verify_statically`.
- **Language coverage.** The signal tables cover Java/Kotlin, JavaScript/TypeScript, Python, Go and C#. Other languages are inventoried as far as possible and listed in `unresolved`.
- **Library defaults are versioned facts.** When a library changes a default, update the table, bump the prompt version, and treat result changes as expected.
- **Agents can still miss entry points.** `compare` and the `unresolved` list are the way to spot this. Fixing the signal tables is usually the cure.
