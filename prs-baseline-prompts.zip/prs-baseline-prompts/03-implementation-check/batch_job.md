---
name: prs-implementation-batch-job
version: 1
description: PRS step 3 for app type batch_job. For every applicable or undetermined practice result from step 2, checks job definitions, code, config, schedules and deployment files and decides whether the practice is implemented, using fixed criteria, pitfalls and default tables.
inputs: CODE_ROOT, CONFIG_PATHS (optional), OUT, OVERRIDES (optional), COMPONENT, APP_TYPE=batch_job, ROLE, PROMPTS
output: OUT/implementation/<component slug>__batch_job.json
---

# PRS step 3 — Implementation check: batch job

## Role

For each practice that step 2 marked `applicable` or `undetermined`, find out whether it is **implemented** for this component's batch and scheduled work, and record evidence. You read code and config; you never run, build or change anything.

Read first: `PROMPTS/shared/conventions.md`, `PROMPTS/shared/practice-catalog.yaml`, `OUT/facts.json` and `OUT/applicability/<slug>__batch_job.json`.

## Procedure

1. **Work list:** every result in the applicability file with status `applicable` or `undetermined`, in file order. Do not add or drop results.
2. **Search scope:** the component root, job/DAG definition files, `CONFIG_PATHS`, deployment files (Kubernetes `Job`/`CronJob`, Helm values), and CI files. Apply conventions §9 exclusions. Start from the unit's evidence (job/step builders, DAG files, `@Scheduled` methods, CronJob manifests), then follow readers, processors and writers one hop.
3. For each result, evaluate the criteria (`I…`) and pitfalls (`P…`) of its practice section. A criterion is met only with evidence. Use only the defaults written in this prompt; if a library is not covered and nothing is configured explicitly, use `cannot_verify_statically` with `notes` starting `DEFAULT_UNKNOWN:`.
4. Choose the status with the practice's **Status** line, or else this order (first match wins):
   1. any **blocking** pitfall → `missing`
   2. all required criteria met **and** a non-blocking pitfall present → `partially_implemented`
   3. all required criteria met explicitly → `implemented`
   4. all required criteria met, at least one only through a documented default → `implemented_by_default`
   5. all required criteria met, at least one only through platform evidence (repo manifests or `OVERRIDES.platform`) → `implemented_by_platform`
   6. some required criteria met → `partially_implemented`
   7. the deciding evidence lives outside the repository or needs runtime data → `cannot_verify_statically`
   8. otherwise → `missing`
5. Record the result (format at the end). Put each offending location in `findings` with the pitfall ID (max 20, sorted).
6. Write the output, canonicalize and validate (conventions §12). Test evidence is out of scope.

**Terms:** *runnable unit* = `batch_job` or `scheduled_task`; *work unit* = `batch_step`, a `batch_job` without steps, or a `scheduled_task`.

---

## Performance

### PERF-02 · No per-item calls inside loops (target: component)
Search loops over records (including inside `ItemProcessor.process`, `ItemWriter.write`, DAG task callables, pandas `apply`/`iterrows`) whose body issues a query, ORM lookup or remote call per record.
- **I1** (required) No such loop found.
- **P1** (non-blocking) Each per-record lookup or call (record every one). Lookups that are cached or pre-loaded once per chunk do not count.
- **Status:** 0 findings → `implemented`; 1 or more → `partially_implemented`.

### PERF-03 · Connection pooling and client reuse (target: component)
- **I1** (required) DB access uses a pool or one long-lived connection per run (not one per record).
- **I2** (required) HTTP/gRPC clients are created once per run, not per record.
- **P1** (blocking) A connection or client created inside the per-record path.
- Defaults: Spring Boot → HikariCP; SQLAlchemy engine → QueuePool; Go `database/sql` pool; ADO.NET pooling → by default.

### PERF-05 · Streaming of large inputs (target: work unit)
- **I1** (required) Inputs are read incrementally: Spring Batch streaming readers (`FlatFileItemReader`, `JdbcCursorItemReader`, `JdbcPagingItemReader`, `JpaPagingItemReader`, `StaxEventItemReader`, `JsonItemReader`) → `implemented_by_default`; line/chunk iteration (`for line in f`, `pd.read_csv(..., chunksize=)`, `iterator=True`, server-side cursors, `yield_per`, `bufio.Scanner`, `File.ReadLines`, `BufferedReader.lines()`); paginated API reads.
- **P1** (non-blocking) Whole-input loads: `ListItemReader` built from a full query, `Files.readAllLines`/`readAllBytes`, `json.load` on input files, `pd.read_csv`/`read_excel` without `chunksize`, `fetchall()`, unbounded `.all()`/`findAll()`, `io.ReadAll`/`os.ReadFile` on inputs, `File.ReadAllText`/`ReadAllLines`.
- **P2** (non-blocking) Airflow tasks passing data sets through XCom instead of references (paths, table names).

### PERF-06 · Time window declared (target: runnable unit)
- **I1** `OVERRIDES.window_bound_units` has an entry for the unit.
- **I2** A deadline or timeout encoding the window is configured: Kubernetes `activeDeadlineSeconds`; Airflow `dagrun_timeout`, task `execution_timeout`, or `deadline=DeadlineAlert(...)` (Airflow ≥ 3.1); Celery `time_limit`.
- **Status:** I1 or I2 → `implemented`; none → `missing`. Always add `notes`: `Actual run duration needs runtime data.`

### PERF-07 · Chunked processing with bulk writes (target: work unit)
- **I1** (required) Records are processed in chunks with one commit per chunk: Spring Batch `.chunk(n)` with n > 1; manual batching with commit every N records; dataframe chunks.
- **I2** (required) Writes are bulk: Spring Batch `JdbcBatchItemWriter` (batched by default); JPA `saveAll` **with** `hibernate.jdbc.batch_size` (or `spring.jpa.properties.hibernate.jdbc.batch_size`) set; `executemany`, `COPY`, `bulk_create`/`bulk_update`, `insertMany`/`bulkWrite`, `SqlBulkCopy`, pgx `CopyFrom`.
- **P1** (blocking) A commit or insert per record across the whole input (`save()` + `flush()`/`commit()` inside the record loop).
- **P2** (non-blocking) Chunk size 1; `saveAll` without JDBC batching configured; Spring Batch `JpaItemWriter` without `hibernate.jdbc.batch_size`.

---

## Resilience

### RES-01 · Timeouts on outbound calls (target: dependency)
- **I1** (required) Connect timeout finite (DB: connection/acquire timeout).
- **I2** (required) Request/read or total timeout finite (DB: query/statement/socket timeout; gRPC: deadline).
- **P1** (blocking) Effective request timeout is none (table).
- **P2** (non-blocking) Above 300 s for a single call (batch calls may be slower, but must still be bounded).
- **DB special case:** a `db` dependency missing only I2 is `partially_implemented`.

| Client | Default |
|---|---|
| Python `requests` / `urllib.request.urlopen` | none → P1 |
| Python `httpx` | 5 s → by default |
| `boto3`/botocore | connect 60 s, read 60 s → by default |
| axios | `0` = none → P1 |
| Node.js global `fetch`/undici | headers/body 300 s → by default |
| Go `http.Client{}`/`http.Get`/`DefaultClient` | none → P1 |
| Java `java.net.http.HttpClient` | no request timeout unless set → P1 |
| Spring `RestTemplate` on `SimpleClientHttpRequestFactory` | infinite read → P1 |
| Spring `WebClient` (Reactor Netty) | connect 30 s, no response timeout → P1 |
| OkHttp | 10 s connect/read/write → by default |
| .NET `HttpClient` | 100 s → by default |
| gRPC | no deadline → P1 |
| HikariCP | `connectionTimeout` 30 s → I1 by default |
| redis-py | none → P1 |
| other clients | explicit settings only, else `cannot_verify_statically` (`DEFAULT_UNKNOWN`) |

### RES-02 · Safe retries (target: dependency)
List every retry layer (explicit, library default, platform).
- **I0** No retry layer → satisfies the practice.
- **I1–I5** (required if retries exist): bounded attempts; backoff; jitter; transient failures only; one layer only. Task-level retries (Airflow `retries`, Kubernetes `backoffLimit`) wrapping client-level retries count as a second layer only if both retry the same call.
- **P1** (blocking) Unbounded retries (tenacity without `stop`, `while True` loops).
- **P2** (blocking) Retrying non-idempotent writes without dedupe.
- **P3** (non-blocking) Multiplying layers (for example tenacity inside an Airflow task with `retries` and an SDK that also retries).
- **P4** (non-blocking) No backoff or no jitter.
- Defaults: tenacity retries forever with no wait unless configured; Spring `@Retryable` 3 retries, 1 s fixed delay, all exceptions, no jitter; Resilience4j Retry 3 attempts, 500 ms fixed; AWS SDKs standard mode 3 attempts with full jitter; Airflow task `retries` 0 unless set.
- **Status:** I0 → `implemented`; else the general order.

### RES-04 · Idempotent re-runs (target: runnable unit)
Follow the writer(s).
- **I1** Upserts/merges keyed by business keys (`ON CONFLICT`, `MERGE`, `upsert`), or delete-and-replace of the run's partition inside one transaction, or a processed-keys/watermark table that skips completed work.
- **I2** File outputs are overwritten or written to a run-specific path, not appended.
- **P1** (blocking) Plain inserts with generated IDs and no uniqueness/dedupe; append-only outputs; per-record emails, payments or messages without dedupe.
- Note: Spring Batch refuses to re-run a *completed* job instance with the same identifying parameters, but a `RunIdIncrementer` creates a new instance on every launch, so it does not prevent duplicate processing.
- **Status:** I1 (and I2 when files are written) → `implemented`; P1 → `missing`; write path not traceable → `cannot_verify_statically`.

### RES-08 · Container requests and limits (target: deployment)
- **I1** (required) CPU and memory requests on every container of the Job/CronJob pod template.
- **I2** (required) Memory limit on every container.
- **P1** (non-blocking) Limit below request, or no CPU request.
- Unresolvable templated values → `cannot_verify_statically`.

### RES-10 · Bounded concurrency (target: component)
- **I1** (required) Parallel processing uses bounded executors/pools: Spring Batch partitioning or multi-threaded steps with a `ThreadPoolTaskExecutor` (bounded core/max/queue), Python `ThreadPoolExecutor`/`ProcessPoolExecutor`/`multiprocessing.Pool`, `asyncio.Semaphore`, Go worker pools or `errgroup.SetLimit`, `Parallel.ForEach` with `MaxDegreeOfParallelism`, Airflow pools/`max_active_tasks`.
- **P1** (blocking) Unbounded fan-out: Spring Batch `SimpleAsyncTaskExecutor` without a `concurrencyLimit` (a new thread per task), `asyncio.gather` over all records, one goroutine per record without a limit, `Promise.all(records.map(...))`.
- **Status:** no parallelism at all → `implemented` with note `single-threaded processing`.

### RES-12 · No swallowed failures (target: component)
- **I1** (required) Errors either propagate (failing the step/task/job) or are handled by an explicit policy (skip/retry policy, error output) with logging that identifies the record.
- **P1** (non-blocking) Swallowed exceptions: catch-all blocks that log and continue without counting, recording or skipping through a policy; `except: pass`; ignored Go errors in record loops (list each).

### RES-14 · Restartability / checkpointing (target: runnable unit)
- **I1** (required) Progress is persisted durably: Spring Batch with a persistent `JobRepository` (JDBC/Mongo: `@EnableJdbcJobRepository`, `JobRepositoryFactoryBean`/`JdbcJobRepositoryFactoryBean` with a DataSource, or Spring Boot batch auto-configuration with a DataSource and `spring.batch.jdbc.*`) and stateful readers (`saveState` true, the reader default); a watermark/offset/processed-keys table updated as work completes; per-task granularity in DAGs (separate tasks per stage, so clearing a failed task resumes from there).
- **I2** (required) A restart resumes from the checkpoint instead of reprocessing everything.
- **P1** (blocking) A non-persistent job repository (`ResourcelessJobRepository`, in-memory/H2 embedded database recreated each run), `preventRestart()`/`restartable(false)` on a job that reads input, or one monolithic task/script with no saved progress over a multi-record input.
- **Status:** Spring Batch with persistent repository and default stateful readers → `implemented_by_default`.

### RES-15 · Bounded skip and retry for bad records (target: work unit)
- **I1** (required) Bad records are skipped with a limit or routed to an error/quarantine output: Spring Batch `.faultTolerant().skip(X).skipLimit(n)` or a `SkipPolicy`; try/except per record writing rejects; pandas/pandera validation splitting valid and invalid rows.
- **I2** (required) Retries apply only to transient errors and are bounded: Spring Batch `.retry(X).retryLimit(n)`/`RetryPolicy` with transient exception types; deterministic errors (parse/validation) go to skip, not retry.
- **I3** (required) Skipped/quarantined records are recorded with their identity (`SkipListener`, error file/table, DLQ).
- **P1** (blocking) Unlimited skipping without recording (`AlwaysSkipItemSkipPolicy`, `skipLimit(Integer.MAX_VALUE)` with no `SkipListener`).
- **P2** (non-blocking) Retrying non-transient exceptions (`retry(Exception.class)`).
- Defaults: Spring Batch 5.x — when `.skip(...)` is used without `skipLimit`, the limit defaults to 10; without `faultTolerant()`, the first exception fails the step.
- **Status:** no fault tolerance at all (fails on the first bad record) → `partially_implemented` with note `fail-fast: skip limit 0`.

### RES-16 · Execution deadline / timeout (target: runnable unit)
- **I1** (required) A maximum runtime is enforced: Kubernetes `activeDeadlineSeconds`; Airflow task `execution_timeout` or DAG `dagrun_timeout`; Celery `time_limit`; an explicit timeout around `@Scheduled`/cron task bodies (future with timeout, context deadline); Spring Batch tasklet `TimeoutTerminationPolicy` or a watchdog stopping the job via `JobOperator`.
- **I2** (non-required) An alert fires on a missed deadline (Airflow ≥ 3.1 `DeadlineAlert`).
- **P1** (non-blocking) Airflow `sla=`/`sla_miss_callback` in a project on Airflow ≥ 3.0 (SLAs were removed; this is dead configuration).

### RES-17 · Overlapping runs prevented (target: runnable unit)
- **I1** (required) A concurrency guard exists: CronJob `concurrencyPolicy: Forbid` (or `Replace` where safe); Airflow `max_active_runs=1` on the DAG; ShedLock `@SchedulerLock`, Quartz clustered job store (`org.quartz.jobStore.isClustered=true`) or `@DisallowConcurrentExecution`; Hangfire `[DisableConcurrentExecution]`; a distributed lock (Redis/DB advisory lock, `celery-once`) around the task body.
- **P1** (blocking) No guard where overlap is possible: CronJob without `concurrencyPolicy` (default `Allow`); Airflow DAG without `max_active_runs` (default `max_active_runs_per_dag` 16); an in-process scheduled task in a service with `F.deploy.multi_instance` true and no distributed lock (it runs on every replica).
- Defaults: Spring `@Scheduled` on a single instance (`F.deploy.multi_instance` false) uses a single-threaded scheduler, so a task does not overlap itself → `implemented_by_default`. Spring Batch rejects launching a job instance that is already running with the same identifying parameters → `implemented_by_default` only when parameters are not incremented per run.

### RES-18 · Failure is surfaced (target: runnable unit)
- **I1** (required) A failed run ends in a failed state visible to the scheduler: non-zero process exit (uncaught exceptions in Python/Java/Go exit non-zero by default), failed Airflow task state, Kubernetes Job `Failed` condition.
- **I2** (required) Someone is alerted: Airflow `on_failure_callback` or `email_on_failure` with email configured, a job listener sending notifications, alert rules on job failure in the repo (for example Prometheus `kube_job_status_failed`), cron-monitor check-ins (Sentry cron monitors, healthchecks.io, Cronitor).
- **P1** (blocking) A run-to-completion entry point that catches all exceptions and exits 0 or returns normally on failure; a Spring Boot batch application run as a Job whose `main` does not propagate the job's exit status (`System.exit(SpringApplication.exit(context))`) when the job can fail.
- **P2** (non-blocking) A Kubernetes Job without `backoffLimit` set explicitly (default 6 retries) or without a `podFailurePolicy` for non-retriable exit codes.
- **Status:** I1 only → `partially_implemented`; I1 and I2 → `implemented`; alerting configured outside the repository → `cannot_verify_statically` for I2 (note it).

### RES-21 · Atomic, recoverable file outputs (target: component)
- **I1** (required) Outputs are written to a temporary path and atomically renamed (`os.replace`, `Files.move(..., ATOMIC_MOVE)`, `rename`), or written to staging tables/prefixes and swapped/committed at the end.
- **I2** (required) A re-run overwrites or resumes outputs instead of appending duplicates.
- **P1** (non-blocking) Writing straight into the final path that downstream consumers read.
- Defaults: Spring Batch `FlatFileItemWriter` buffers output until chunk commit (`transactional` true) and is restartable → I2 by default.

---

## Security

### SEC-01 · Input validation for files, records, messages and API responses (target: work unit)
- **I1** (required) Each record/file is validated against a schema or typed mapping before processing: Spring Batch `ValidatingItemProcessor`/`BeanValidatingItemProcessor`, typed `FieldSetMapper`s, pydantic/marshmallow models, pandera/Great Expectations checks, JSON Schema, Avro/Protobuf schemas, header/column checks for CSV.
- **I2** (required) Invalid records are rejected or quarantined, not silently coerced.
- **P1** (non-blocking) Lenient parsing that hides bad data (`errors="coerce"`, `strict(false)` readers, `on_bad_lines="skip"` without recording).
- **Status:** general order; list unvalidated inputs in `findings`.

### SEC-04 · Safe file-system access (target: component)
- **I1** (required) Paths built from external data (record fields, file names in input, API responses, arguments) are normalised and confined to a base directory, or mapped from allowlisted IDs.
- **I2** (required) Temp files created securely (`tempfile.mkstemp`/`NamedTemporaryFile`/`TemporaryDirectory`, `Files.createTempFile`, `os.CreateTemp`).
- **P1** (blocking) An externally derived path reaches a file API without confinement.
- **P2** (blocking) `tempfile.mktemp(`, `os.tempnam(`.
- **P3** (non-blocking) World-writable permissions on outputs or work directories.

### SEC-05 · Injection-safe data access (target: component)
- **I1** (required) Every raw query uses bind parameters; ORM/query builders with bound values.
- **I2** (required) Dynamic identifiers (table/partition/column names, often built from dates or input) come from an allowlist or a strict format check.
- **P1** (blocking) Query text built with concatenation/interpolation/formatting of non-constant values (`f"…"`, `%`, `.format`, `+`, `fmt.Sprintf`, `String.format`, template literals) in query APIs.
- Defaults: ORM-only access → `implemented_by_default`.

### SEC-06 · Safe command and code execution (target: component)
- **I1** (required) Commands run without a shell and with argument lists; external values are allowlisted or placed after `--`.
- **I2** (required) No `eval`/`exec`/dynamic code or template compilation on external data.
- **P1** (blocking) `shell=True`, `os.system(`, `sh -c`, `Runtime.exec(String)` or `child_process.exec(` with non-constant input; `eval`/`exec` on external data.

### SEC-07 · Safe deserialization and XML parsing (target: component)
- **I1** (required) Input files/messages are parsed with data-only loaders or type allowlists (`yaml.safe_load`, SnakeYAML ≥ 2.0 defaults, js-yaml ≥ 4 `load`, JSON).
- **I2** (required) XML parsers have DTDs/external entities disabled (Java factories with `disallow-doctype-decl`; Python `defusedxml`; .NET Core defaults are safe; Go `encoding/xml` is safe).
- **P1** (blocking) `pickle`/`marshal`/`shelve`/`dill`/`jsonpickle` on input data; `yaml.load(..., Loader=yaml.Loader|UnsafeLoader)`/`yaml.unsafe_load`; Java `ObjectInputStream` without `ObjectInputFilter`; Jackson default typing without an allowlist; .NET `BinaryFormatter`.
- **P2** (blocking) Java XML factories parsing input files without XXE hardening.
- **P3** (non-blocking) Python stdlib `xml.etree`/`minidom` on external files (prefer `defusedxml`).

### SEC-20 · No hard-coded secrets (target: component)
Search code, DAG files, config, `.env*` (except examples), Helm values, CronJob manifests and Dockerfiles for: private keys `-----BEGIN [A-Z ]*PRIVATE KEY-----`; `AKIA[0-9A-Z]{16}`; `gh[pousr]_[A-Za-z0-9]{36,}`; `xox[abprs]-`; `AIza[0-9A-Za-z_-]{35}`; `sk_live_`; credentials in URLs `://[^/:@\s]+:[^/@\s]+@`; `(password|passwd|pwd|secret|token|api[_-]?key|client[_-]?secret|access[_-]?key)\s*[:=]\s*["'][^"'${}<>]{8,}["']`. Ignore placeholders and secret references. Airflow: secrets belong in Connections/Variables backed by a secrets backend, not in DAG code.
- **I1** (required) No hard-coded secret found.
- **P1** (blocking) A real-looking secret (location and kind only; value `<redacted>`).
- **P2** (non-blocking) Default credentials in committed config.

### SEC-21 · No sensitive data in logs (target: component)
- **I1** (required) Record contents with personal or financial data, credentials, tokens and connection strings are not logged.
- **P1** (blocking) Logging of passwords, tokens, secrets, `Authorization` headers or connection strings with credentials.
- **P2** (non-blocking) Logging whole records/rows/payloads (`log.info(record)`, `print(row)`, `logger.debug(item)`) or PII-named fields (`ssn`, `card`, `cvv`, `pan`, `dob`, `email`, `phone`, `account`).

### SEC-22 · Secure transport (target: component)
- **I1** (required) TLS verification never disabled.
- **I2** (required) Outbound URLs/connection strings use TLS (except loopback or in-cluster traffic under mesh mTLS).
- **P1** (blocking) `verify=False`, `rejectUnauthorized: false`, `InsecureSkipVerify: true`, trust-all `TrustManager`, `CERT_NONE`, forced TLS < 1.2.
- **P2** (non-blocking) `http://`, `ftp://`, `sslmode=disable`, `useSSL=false`, `TrustServerCertificate=True` to non-local hosts.

### SEC-24 · Dependency vulnerability management (target: component)
- **I1** (required) Locked dependency versions (lockfiles, exact/BOM-managed versions; Airflow constraints files count).
- **I2** (required) Automated vulnerability scanning in CI, or Dependabot/Renovate security updates.
- **Platform:** `OVERRIDES.platform.dependency_scanning_external: true` → I2 as platform evidence.

### SEC-25 · Least-privilege container runtime (target: deployment)
- **Kubernetes I1** (required) `runAsNonRoot: true` or non-zero `runAsUser`; **I2** (required) `allowPrivilegeEscalation: false`; **I3/I4** (non-required) `readOnlyRootFilesystem: true`, `capabilities.drop: ["ALL"]`.
- **Dockerfile I1** (required) Non-root `USER` in the final stage, or a non-root base image.
- **P1** (blocking) `privileged: true`, `hostPID`/`hostNetwork`, `runAsUser: 0`. **P2** (non-blocking) `hostPath` volumes or added capabilities.

---

## Output format

`OUT/implementation/<slug>__batch_job.json` (schema: `PROMPTS/schemas/implementation.schema.json`):

```json
{
  "schema_version": "prs-implementation/1",
  "prompt": "03-implementation-check/batch_job@1",
  "catalog_version": 1,
  "component_id": "cmp:jobs/settlement",
  "app_type": "batch_job",
  "role": "primary",
  "results": [
    {
      "result_id": "RES-17@job:nightly-settlement",
      "practice_id": "RES-17",
      "category": "resilience",
      "severity": "high",
      "target_id": "job:nightly-settlement",
      "applicability": "applicable",
      "status": "missing",
      "criteria_met": [],
      "criteria_failed": ["I1"],
      "pitfalls": ["P1"],
      "defaults_applied": [{"library": "kubernetes CronJob", "version": "batch/v1", "setting": "concurrencyPolicy", "default": "Allow"}],
      "findings": [{"file": "deploy/settlement-cronjob.yaml", "line": 6, "symbol": "", "snippet": "spec:", "issue": "P1"}],
      "evidence": [],
      "notes": ""
    }
  ],
  "search_log": [{"pattern": "concurrencyPolicy", "paths": "deploy", "hits": 0}]
}
```

- One result per work-list item, same `result_id`, same order.
- `criteria_met` + `criteria_failed` list every criterion that applies to the target.
- `notes`: at most 300 characters; plain facts only.
