---
name: prs-implementation-backend-service
version: 1
description: PRS step 3 for app type backend_service. For every applicable or undetermined practice result from step 2, checks the code, config and deployment files and decides whether the practice is implemented, using fixed criteria, pitfalls and library-default tables.
inputs: CODE_ROOT, CONFIG_PATHS (optional), OUT, OVERRIDES (optional), COMPONENT, APP_TYPE=backend_service, ROLE, PROMPTS
output: OUT/implementation/<component slug>__backend_service.json
---

# PRS step 3 — Implementation check: backend service

## Role

For each practice that step 2 marked `applicable` or `undetermined`, find out whether it is **implemented** in this component, and record evidence. You read code and config; you never run, build or change anything.

Read first: `PROMPTS/shared/conventions.md`, `PROMPTS/shared/practice-catalog.yaml`, `OUT/facts.json` and `OUT/applicability/<slug>__backend_service.json`.

## Procedure

1. **Work list:** every result in the applicability file with status `applicable` or `undetermined`, in file order. Do not add or drop results. Skip `not_applicable` ones.
2. **Search scope:** the component root, `CONFIG_PATHS`, the component's deployment files (facts `deployments`), and CI files (`F.ci.files`). Apply the exclusions of conventions §9. Start from the facts (unit handler, dependency `call_sites` and `config_keys`, sink and data-access evidence), then search.
3. For each result, go to its practice section below:
   - Evaluate every listed criterion (`I…`) and pitfall (`P…`). A criterion is met only with evidence (a file/line, a config key, a manifest field, an override, or a default from a table in this prompt).
   - **Defaults:** use only the default values written in this prompt, keyed by the library and version in `facts.json`. If a client or framework is not in the tables and nothing is configured explicitly, do not assume a value: use status `cannot_verify_statically` with `notes` starting `DEFAULT_UNKNOWN:`.
   - Choose the status with the practice's **Status** line. Where a practice gives no special rule, use this order (first match wins):
     1. any **blocking** pitfall → `missing`
     2. all required criteria met **and** a non-blocking pitfall present → `partially_implemented`
     3. all required criteria met explicitly in code/config → `implemented`
     4. all required criteria met, at least one only through a documented default → `implemented_by_default`
     5. all required criteria met, at least one only through platform evidence (repo manifests or `OVERRIDES.platform`) → `implemented_by_platform`
     6. some required criteria met → `partially_implemented`
     7. the deciding evidence lives outside the repository or needs runtime data → `cannot_verify_statically`
     8. otherwise → `missing`
4. Record the result (format at the end). Put each offending location in `findings` with the pitfall ID (max 20 per result, sorted by file and line).
5. Write the output, canonicalize and validate (conventions §12). Test-evidence checks are **out of scope** for this step.

**Do not fix, suggest code, or rate severity.** Severity comes from the catalog.

---

## Performance

### PERF-01 · Bounded result sets (target: unit)
Look at the handler and the query it calls (one hop into the service/repository).
- **I1** (required) Accepts page/limit/cursor parameters, or applies a hard limit in the query (`LIMIT`, `.limit(`, `Top`, `Take(`, `[:n]`).
- **I2** (required) A maximum page size is enforced (cap on the client-supplied size, or the client cannot change the size).
- **P1** (blocking) Returns an unbounded query directly (`findAll()` without `Pageable`, `.objects.all()`, `.find({})`, `SELECT` without `LIMIT`, `ToList()` on an unfiltered set).
- Defaults: Spring Data web `Pageable` caps size at 2000 (`spring.data.web.pageable.max-page-size`) → I2 by default. DRF `PageNumberPagination` with `page_size_query_param` unset → client cannot change size → I2 met by default.

### PERF-02 · No per-item calls inside loops (target: component)
Search loops (`for`, `forEach`, `.map(`, `stream().map/forEach`, list comprehensions, `for range`) whose body calls a repository/DAO/ORM method, a raw query API, or an outbound client from `dependencies`. Include ORM lazy loading in loops (JPA relation getters without `JOIN FETCH`/`@EntityGraph`; Django FK/reverse access without `select_related`/`prefetch_related`; ORM relations without eager `include`).
- **I1** (required) No such loop found.
- **P1** (non-blocking) Each loop found (record every one in `findings`).
- **Status:** 0 findings → `implemented`; 1 or more → `partially_implemented`.

### PERF-03 · Connection pooling and client reuse (target: component)
- **I1** (required) Every `db` dependency uses a connection pool (explicit or default).
- **I2** (required) HTTP/gRPC clients are created once and reused (singleton bean, module-level client, `IHttpClientFactory`, injected client).
- **P1** (blocking) A client or DB connection is created per request or per call: `new RestTemplate()`/`OkHttpClient()`/`HttpClients.create…` inside a handler or service method body, `new HttpClient()` per call in .NET, `new pg.Client()` + `connect()` per request, `httpx.Client()`/`aiohttp.ClientSession()` created per request, `&http.Transport{}` created per call in Go.
- **P2** (non-blocking) Django `CONN_MAX_AGE` is 0/unset (new DB connection per request); Go `SetMaxOpenConns` never called (unbounded pool); Python `requests.<method>(` without a `Session` on hot paths.
- Defaults: Spring Boot JDBC → HikariCP (pool size 10, `connectionTimeout` 30 s); SQLAlchemy `create_engine` → QueuePool; Go `database/sql` → built-in pool; ADO.NET/EF Core → connection pooling on; Node.js ≥ 19 global HTTP agent keeps connections alive.

### PERF-04 · No blocking I/O on async paths (target: component)
Only async/event-loop code paths (handlers, resolvers, consumers).
- **P1** (blocking) Node.js handlers using `fs.*Sync`, `child_process.execSync`, `crypto.pbkdf2Sync`/`scryptSync`, `bcrypt.hashSync`/`compareSync`.
- **P1** (blocking) Python `async def` handlers calling `requests.`, `time.sleep(`, sync DB drivers (`psycopg2`, `pymysql`, `sqlite3`, sync SQLAlchemy `Session`), or `urllib.request` without `run_in_executor`/`asyncio.to_thread`/`run_in_threadpool`.
- **P1** (blocking) WebFlux/Reactor/Vert.x code calling `.block()`, `Thread.sleep(`, JDBC/JPA repositories, `RestTemplate`, or blocking file I/O without `subscribeOn(Schedulers.boundedElastic())`/`executeBlocking`.
- **I1** (required) None of the above found.
- **Status:** I1 → `implemented`; any P1 → `missing`.

### PERF-05 · Streaming of large inputs/outputs (target: unit)
- **I1** (required) Large payloads are streamed: uploads processed as streams or written to disk with a size cap; downloads/exports via `StreamingResponseBody`, `InputStreamResource`, `ResponseEntity<Resource>`, `res.pipe(`/`stream.pipeline(`, `StreamingResponse`/`FileResponse`, `http.ServeContent`/`io.Copy`, `FileStreamResult`/`PhysicalFile`; DB exports via cursors/pagination.
- **P1** (blocking) Whole-content reads without a size cap: `MultipartFile.getBytes()`, `readAllBytes()`, `file.read()`/`await file.read()` on uploads, multer `memoryStorage()` without `limits.fileSize`, `ioutil.ReadAll`/`io.ReadAll(r.Body)` without `MaxBytesReader`, building a whole export list/string before writing.

### PERF-06 · Performance target declared (target: unit)
- **I1** `OVERRIDES.latency_targets` has an entry for the unit.
- **I2** A performance-test script in the repo asserts a threshold covering this route (k6 `thresholds`, Gatling `assertions`, JMeter Duration/Response assertions, Locust exit-code checks, Artillery `ensure`); match by method and path.
- **I3** An SLO or latency alert definition in the repo names this route (OpenSLO, Sloth, Prometheus rules on route latency).
- **Status:** any of I1–I3 → `implemented`; none → `missing`. Always add `notes`: `Actual latency needs runtime measurement.`

---

## Resilience

### RES-01 · Timeouts on outbound calls (target: dependency)
Look at the client's construction, its `config_keys`, the call sites, and wrappers (Feign config, `RestClient.Builder` customizers, `HttpClient` registrations, resilience pipelines).
- **I1** (required) Connect timeout is finite (for DB: connection/acquire timeout).
- **I2** (required) Request/read/response timeout, or a total-call timeout/deadline, is finite (for DB: query/statement/socket timeout; for gRPC: a deadline on every call or in service config).
- **P1** (blocking) The effective request timeout is infinite: nothing configured and the default below is "none".
- **P2** (non-blocking) A timeout above 60 s on a synchronous request path.
- **P3** (non-blocking) Attempt timeout ≥ total timeout, or (retries × attempt timeout) exceeds the caller's own timeout.
- **Platform:** a mesh/gateway route timeout for this destination in repo manifests (Istio `VirtualService.http[].timeout`, Envoy/Linkerd route timeouts), or `OVERRIDES.platform.timeouts_at_mesh: true`, satisfies I2 as platform evidence.
- **DB special case:** a `db` dependency missing only I2 is `partially_implemented`, not `missing`.

| Client | Default (only these values may be used) |
|---|---|
| Python `requests` | none, waits forever unless `timeout=` is passed → P1 |
| Python `urllib.request.urlopen` | none unless `timeout=` → P1 |
| Python `httpx` | 5 s for connect/read/write/pool → I1+I2 by default |
| Python `aiohttp` | total 300 s → I1+I2 by default, P2 |
| `boto3`/botocore | connect 60 s, read 60 s → by default |
| axios | `timeout: 0` = none → P1 |
| Browser `fetch` | none → P1 unless an `AbortSignal` with a timeout is passed |
| Node.js global `fetch`/undici | headers 300 s, body 300 s → by default, P2 |
| ky | 10 s → by default |
| Go `http.Client{}` / `http.Get`/`Post`/`Head` / `http.DefaultClient` | `Timeout: 0` = none → P1 |
| Java `java.net.http.HttpClient` | no connect timeout; a request without `HttpRequest.Builder.timeout` blocks forever → P1 |
| Spring `RestTemplate` on `SimpleClientHttpRequestFactory` (`HttpURLConnection`) | read timeout infinite → P1 |
| Spring `WebClient` on Reactor Netty | connect 30 s, **no** response timeout → I1 by default, I2 missing → P1 |
| Spring `ReactorClientHttpRequestFactory` (Spring 6.2+) | connect 30 s, read 10 s → by default |
| Spring `RestClient` | depends on the request factory on the classpath (Spring Boot 4 order: Apache HttpClient, Jetty, Reactor Netty, JDK `HttpClient`, `HttpURLConnection`); apply that client's row |
| OkHttp | connect/read/write 10 s each, no call timeout → I1+I2 by default |
| OpenFeign | connect 10 s, read 60 s → by default |
| .NET `HttpClient` | `Timeout` 100 s → by default, P2 |
| .NET `AddStandardResilienceHandler` | total 30 s, attempt 10 s → by default |
| gRPC (all languages) | no deadline → P1 unless set per call or in service config |
| HikariCP (DB pool acquire) | `connectionTimeout` 30 s → I1 by default; no query timeout |
| Lettuce (Redis) | command timeout 60 s → by default, P2 |
| Jedis | 2 s → by default |
| redis-py | `socket_timeout` none → P1 |
| go-redis | dial 5 s, read 3 s, write 3 s → by default |
| StackExchange.Redis | connect 5 s, sync 5 s → by default |
| Kafka producer (Java client) | `request.timeout.ms` 30 s, `delivery.timeout.ms` 120 s → by default |
| Apache HttpClient 5, AWS SDK for JS v3, Azure SDKs, other DB drivers | not in this table → explicit settings only, else `cannot_verify_statically` (`DEFAULT_UNKNOWN`) |

### RES-02 · Safe retries (target: dependency)
First list every **retry layer** that applies to this dependency: explicit (resilience libraries, annotations, loops that catch-and-retry), library defaults (table below) and platform (mesh retry policy in manifests, `OVERRIDES.platform.retries_at_mesh`).
- **I0** No retry layer at all (fail fast). This alone satisfies the practice.
- **I1** (required if retries exist) Bounded attempts (max attempts or max elapsed time).
- **I2** (required if retries exist) Backoff between attempts (fixed delay > 0 at minimum; exponential preferred).
- **I3** (required if retries exist) Jitter.
- **I4** (required if retries exist) Retries only transient failures (timeouts, connection errors, 429, 502/503/504), not every exception or 4xx.
- **I5** (required if retries exist) Only one retry layer.
- **P1** (blocking) Unbounded retries (tenacity `@retry` without `stop=`, `while True` retry loops, infinite `maxAttempts`).
- **P2** (blocking) Retrying non-idempotent operations (POST/PATCH, inserts, payments) without an idempotency key.
- **P3** (non-blocking) Two or more retry layers (multiplies load).
- **P4** (non-blocking) No backoff (immediate retries) or no jitter.
- **Status:** I0 → `implemented`; else the general order (default-only layers → `implemented_by_default` if they meet I1–I5).

| Layer | Default behaviour |
|---|---|
| tenacity `@retry` | retries forever, no wait → P1 unless `stop=`; P4 unless `wait=` (jitter via `wait_random_exponential`) |
| Spring Framework 7 `@Retryable` / `RetryPolicy` | 3 retries, 1 s fixed delay, multiplier 1.0, jitter 0, no timeout, **all** exceptions → I1+I2 by default; I3 and I4 not met |
| spring-retry `@Retryable` (legacy) | 3 attempts in total, 1 s fixed delay, all exceptions → I1+I2 by default; I3, I4 not met |
| Resilience4j Retry | 3 attempts, 500 ms fixed wait → I1+I2 by default; I3 not met unless randomized/exponential random backoff configured |
| .NET standard resilience handler | 3 retries, exponential, jitter on, transient errors (5xx, 408, 429) → I1–I4 by default; P2 unless `DisableForUnsafeHttpMethods()` |
| Polly v8 `AddRetry` | 3 retries, 2 s constant delay, no jitter unless `UseJitter = true` |
| AWS SDKs (standard mode) | 3 attempts, exponential backoff with full jitter → I1–I4 by default (one layer) |
| OkHttp | `retryOnConnectionFailure` true (connection-level only) → not counted as a layer |
| axios-retry | 3 retries, no delay by default → P4 unless `retryDelay` set |
| Istio (mesh present, no explicit policy) | 2 retries → counts as a layer (platform) |
| OpenFeign (Spring Cloud) | no retries by default |
| gRPC | no retries unless a `retryPolicy` is in service config |

### RES-03 · Circuit breaker / fail-fast (target: dependency)
- **I1** (required) A circuit breaker wraps calls to this dependency: Resilience4j `@CircuitBreaker`/`CircuitBreakerRegistry`, Spring Cloud CircuitBreaker, opossum `new CircuitBreaker(`, cockatiel `circuitBreaker(`, pybreaker, gobreaker/failsafe-go, Polly circuit breaker, .NET standard resilience handler.
- **I2** (required) A fallback or fast failure is defined (fallback method/`breaker.fallback(`, mapped error response).
- **Platform:** Istio `DestinationRule.trafficPolicy.outlierDetection` or Envoy outlier detection for this destination → I1 as platform evidence.
- **P1** (non-blocking) Breaker that rarely opens: Resilience4j `minimumNumberOfCalls` left at 100 for a low-traffic dependency, or opossum `volumeThreshold` 0 (opens on the first failures).
- Defaults: the .NET standard resilience handler includes a circuit breaker (failure ratio 10%, minimum throughput 100, break 5 s) → I1 by default.

### RES-04 · Idempotent handling of retried/redelivered work (target: unit)
Follow the handler one hop into the service/repository.
- **I1** Deduplication: idempotency key / message ID stored and checked (processed-message table, unique constraint on a business key plus conflict handling, Redis `SET NX`/`SETNX` with TTL, inbox/outbox tables, `Idempotency-Key` header handling, AWS Powertools idempotency).
- **I2** Natural idempotency: the write is an upsert/replace keyed by a client- or message-supplied ID (`ON CONFLICT DO UPDATE/NOTHING`, `MERGE`, `save` with a supplied ID, PUT semantics).
- **P1** (blocking) Non-idempotent side effects with no dedupe: inserts with generated IDs, counters or balances incremented, emails/payments sent, messages re-published.
- **Status:** I1 or I2 → `implemented`; P1 → `missing`; the write path cannot be traced statically → `cannot_verify_statically`.

### RES-05 · Dead-letter / poison-message handling (target: unit `message_consumer`)
- **I1** (required) Failed messages are moved to a DLQ/DLT/parking queue after bounded attempts.
- **I2** (required) Undeserializable messages (poison pills) do not block the partition/queue.
- **P1** (blocking) Failed messages are only logged and dropped, or retried forever.

| Stack | Default / what to check |
|---|---|
| Spring Kafka `DefaultErrorHandler` | `FixedBackOff(0, 9)`: 9 immediate retries, then **log only** → P1 unless a `DeadLetterPublishingRecoverer` (or other recoverer) is set; I2 needs `ErrorHandlingDeserializer` |
| Spring Cloud Stream (Kafka binder) | `enable-dlq` false by default → P1 unless `…consumer.enable-dlq: true`; `max-attempts` is ignored when DLQ is off |
| RabbitMQ / Spring AMQP | needs `x-dead-letter-exchange` on the queue and rejected messages not requeued (`default-requeue-rejected: false` or `AmqpRejectAndDontRequeueException`) |
| AWS SQS | `RedrivePolicy` with `deadLetterTargetArn` and `maxReceiveCount` in IaC → platform evidence; absent from repo → `cannot_verify_statically` |
| Azure Service Bus | built-in dead-letter queue after `MaxDeliveryCount` (default 10) → `implemented_by_default` |
| MassTransit | faulted messages move to `<queue>_error` by default → `implemented_by_default` |
| kafkajs, kafka-go, confluent-kafka, sarama | no DLQ built in → needs explicit code |
| Celery | check `acks_late`, `max_retries`, `task_reject_on_worker_lost` and a failure route; none → P1 |
| BullMQ | failed jobs kept in the failed set after `attempts` → I1 by default if `attempts` is set; else retried 0 times and kept |

### RES-06 · Readiness and liveness health checks (target: component)
- **I1** (required) A health endpoint exists (Spring Actuator `/actuator/health`, `AddHealthChecks()`+`MapHealthChecks(`, a `/health`-style handler, gRPC health service).
- **I2** (required when `F.deploy.kinds` includes a Kubernetes workload) `readinessProbe` and `livenessProbe` on the container (`startupProbe` optional).
- **P1** (non-blocking) Liveness checks external dependencies (DB, downstream calls), or liveness and readiness are the same check.
- Defaults: Spring Boot Actuator exposes liveness/readiness groups automatically when running on Kubernetes → I1 by default if Actuator is present.

### RES-07 · Graceful shutdown (target: component)
- **I1** (required) On SIGTERM the server stops accepting new work and drains in-flight requests/messages with a bounded grace period.
- **P1** (blocking) `server.shutdown=immediate`; Go `http.ListenAndServe` with no `Server.Shutdown(ctx)` on a signal; Node.js with no `SIGTERM` handler calling `server.close(`.
- **P2** (non-blocking) Kubernetes `terminationGracePeriodSeconds` shorter than the app's shutdown timeout.

| Stack | Default |
|---|---|
| Spring Boot ≥ 3.4 | graceful by default → `implemented_by_default` |
| Spring Boot < 3.4 | not graceful unless `server.shutdown=graceful` |
| .NET Generic Host / ASP.NET Core | handles SIGTERM; `HostOptions.ShutdownTimeout` 30 s (.NET 6+) → by default |
| gunicorn | `graceful_timeout` 30 s → by default |
| uvicorn | drains connections on SIGTERM → by default |
| Go, Node.js, plain Python servers | nothing by default → needs explicit code |

### RES-08 · Container requests and limits (target: deployment)
- **I1** (required) Every container has `resources.requests.cpu` and `resources.requests.memory` (Helm: resolved from `values*.yaml`; record the values file used).
- **I2** (required) Every container has `resources.limits.memory`.
- **P1** (non-blocking) No CPU request, or memory limit lower than the memory request.
- ECS: task/container `cpu` and `memory` set → I1+I2. Templated values that cannot be resolved from the repo → `cannot_verify_statically`.

### RES-09 · Inbound rate limiting (target: component)
- **I1** (required) Rate limiting/throttling applies to inbound requests: Bucket4j, Resilience4j `RateLimiter` on handlers, Spring Cloud Gateway `RequestRateLimiter`, express-rate-limit, `@nestjs/throttler`, slowapi, django-ratelimit, DRF `DEFAULT_THROTTLE_CLASSES`, ASP.NET Core `AddRateLimiter`+`UseRateLimiter`, `golang.org/x/time/rate`, chi `httprate`, tollbooth.
- **Platform:** ingress-nginx `limit-rps`/`limit-rpm`/`limit-connections` annotations, Istio/Envoy local rate limit, Kong `rate-limiting` plugin, API gateway throttling in IaC, or `OVERRIDES.platform.rate_limiting_at_gateway: true`.
- `OVERRIDES.platform.rate_limiting_at_gateway: false` and no in-app limiter → `missing`.

### RES-10 · Bounded concurrency and queues (target: component)
- **I1** (required) No unbounded thread/task/goroutine creation per request or per item.
- **I2** (required) Executors and work queues are bounded.
- **P1** (blocking) `Executors.newCachedThreadPool()` on request paths; a goroutine per request/item without a semaphore/`errgroup.SetLimit`/worker pool; `asyncio.gather(*all_items)` or `Promise.all(items.map(...))` over unbounded input; .NET `Parallel.ForEach` without `MaxDegreeOfParallelism`.
- **P2** (non-blocking) Unbounded queues: `Executors.newFixedThreadPool` (unbounded `LinkedBlockingQueue`), `ThreadPoolTaskExecutor` without `queueCapacity` (default `Integer.MAX_VALUE`), Spring Boot task executor without `spring.task.execution.pool.queue-capacity`, `Channel.CreateUnbounded`.
- Defaults: servlet containers (Tomcat `server.tomcat.threads.max` 200), Python `ThreadPoolExecutor` (`max_workers` = min(32, CPUs+4)) → bounded by default.
- **Status:** no concurrency constructs at all → `implemented` with note `single request-scoped execution`.

### RES-11 · Request body and upload size limits (target: component)
- **I1** (required) JSON/form body size is capped.
- **I2** (required when any unit `accepts_files`) Upload size is capped.
- **Platform:** ingress-nginx `proxy-body-size` annotation, gateway limits, or `OVERRIDES.platform.request_size_limit_at_edge: true`.

| Stack | Default |
|---|---|
| Express `express.json()`/body-parser | 100 KB → I1 by default (note if `limit` is raised) |
| Fastify | `bodyLimit` 1 MiB → by default |
| multer | no file size limit unless `limits.fileSize` → I2 not met |
| Spring MVC JSON body | no limit by default → I1 not met unless a filter or server setting caps it |
| Spring WebFlux codecs | `spring.codec.max-in-memory-size` 256 KB → I1 by default |
| Spring multipart | `max-file-size` 1 MB, `max-request-size` 10 MB → I2 by default |
| Django | `DATA_UPLOAD_MAX_MEMORY_SIZE` 2.5 MB → I1 by default |
| Flask | `MAX_CONTENT_LENGTH` unset → no limit |
| FastAPI / Starlette | no limit by default |
| Go `net/http` | no body limit unless `http.MaxBytesReader` |
| ASP.NET Core Kestrel | `MaxRequestBodySize` 30,000,000 bytes → I1 by default; multipart `MultipartBodyLengthLimit` 128 MB → I2 by default |
| ingress-nginx | `proxy-body-size` 1m when an Ingress uses it → platform |

### RES-12 · Centralized error handling (target: component)
- **I1** (required) A global handler maps unhandled exceptions to controlled responses: Spring `@(Rest)ControllerAdvice`+`@ExceptionHandler` or ProblemDetail, Express error middleware `(err, req, res, next)`, NestJS exception filters, FastAPI `exception_handler`, Flask `errorhandler`, Django middleware, Go recovery middleware (`gin.Recovery()`, chi `middleware.Recoverer`, echo `Recover`), ASP.NET `UseExceptionHandler`/`AddProblemDetails`.
- **I2** (required if `F.messaging.consumes`) Consumers and background tasks have error handlers (container error handler, try/catch per message, `process.on('unhandledRejection'`)).
- **P1** (non-blocking) Swallowed exceptions: empty `catch {}`/`except: pass`/ignored `err` that hides failures (list each).
- Defaults: NestJS built-in global exception filter, Django and FastAPI/Starlette default 500 handling, ASP.NET Core default 500 → I1 by default (still check I2 and P1).

---

## Security

### SEC-01 · Input validation on every external input (target: unit)
For each input of the unit (facts `inputs`):
- **I1** (required) The input is parsed into a typed structure or validated against a schema (typed path/query parameters, DTOs with Bean Validation and `@Valid`/`@Validated`, pydantic models, zod/joi/yup/class-validator/ajv/express-validator, DRF serializers with `is_valid(raise_exception=True)`, Django forms `is_valid()`, go-playground/validator `Struct()`, DataAnnotations/FluentValidation, protobuf/Avro schemas for messages).
- **I2** (required for string and numeric fields from bodies, forms, query and messages) Constraints beyond type: length, range, pattern/format or allowlist.
- **I3** (required) Invalid input is rejected (400/422, message rejected) before business processing.
- **P1** (blocking) Constraint annotations exist but are not enforced: Spring `@RequestBody` DTO with constraints but no `@Valid`/`@Validated`; NestJS class-validator DTOs without a `ValidationPipe` (global, `APP_PIPE`, or per parameter); manual `req.body.x` use with no validator.
- **P2** (non-blocking) Raw `Map`/`dict`/`any`/`JsonNode`/`object` bodies.
- Defaults: FastAPI/pydantic models enforce types (I1 by default); ASP.NET Core `[ApiController]` returns 400 automatically on invalid model state (I3 by default).
- **Status:** all inputs I1–I3 → `implemented`; some inputs → `partially_implemented`; none, or P1 → `missing`. List uncovered inputs in `findings` with issue `I1`/`I2`.

### SEC-02 · Mass-assignment protection (target: unit)
- **I1** (required) The body binds to a dedicated DTO/schema with explicit fields, or uses an allowlist (`fields = [...]`, `@JsonIgnoreProperties`, `[Bind(...)]`, pydantic models separate from ORM models).
- **P1** (blocking) The body binds directly to a persistence entity or is spread into a create/update: `@RequestBody` of an `@Entity` type, Django `ModelForm`/DRF `ModelSerializer` with `fields = '__all__'` or `exclude`, `Model.create(req.body)`, `Object.assign(entity, req.body)`, Prisma `data: req.body`, EF entity as `[FromBody]`.
- **P2** (non-blocking) Unknown fields silently accepted where privileged fields (`role`, `isAdmin`, `owner`, `tenant`, `price`, `status`) exist on the target model.

### SEC-03 · File upload validation (target: unit)
- **I1** (required) Size limit (per file).
- **I2** (required) Type allowlist by extension **and** content/magic bytes (`file-type`, `python-magic`, Apache Tika, `Files.probeContentType` is not enough alone).
- **I3** (required) Server-generated storage name, or the user filename is sanitised (no path components).
- **I4** (non-required) Stored outside the web root / not served as executable content.
- **P1** (blocking) User filename used directly in a storage path.

### SEC-04 · Safe file-system access (target: component)
Check every `file_path` sink with `input_derived` true or `"unknown"`, then search the component for temp-file and permission APIs.
- **I1** (required) Input-derived paths are confined: normalised/canonicalised then checked against a base directory (`Path.normalize().startsWith(base)`, `os.path.realpath` + `os.path.commonpath`, `path.resolve` + prefix check, `filepath.Clean` + prefix check or Go `os.Root`), or mapped from an allowlisted ID; framework helpers count (Flask `send_from_directory`, Starlette `StaticFiles`).
- **I2** (required) Temp files created securely (`tempfile.mkstemp`/`NamedTemporaryFile`/`TemporaryDirectory`, `Files.createTempFile`, `os.CreateTemp`).
- **P1** (blocking) An input-derived path reaches a file API with no confinement.
- **P2** (blocking) `tempfile.mktemp(`, `os.tempnam(`.
- **P3** (non-blocking) World-writable permissions (`0o777`, `chmod 777`, `setWritable(true, false)`).

### SEC-05 · Injection-safe data access (target: component)
Check every data-access site in facts (`data_access`) and search for string-built queries.
- **I1** (required) Every raw query uses placeholders/bind parameters (`?`, `:name`, `$1`, `%s` passed as parameters, `@p`), or the ORM/query builder with bound values.
- **I2** (required) Dynamic identifiers (table, column, `ORDER BY` direction) come from an allowlist.
- **P1** (blocking) A query string built by concatenation, interpolation or formatting with non-constant values: `"…" + x`, template literals/f-strings/`%`/`.format`/`fmt.Sprintf`/`String.format` inside query APIs, `$queryRawUnsafe`/`$executeRawUnsafe`, `knex.raw(` with interpolation, `sequelize.query(` with `${}`, Django `.extra(`/`RawSQL(` with formatting, `createQuery("…" + x)`, `FromSqlRaw($"…{x}")`, gorm `.Where(fmt.Sprintf(`, Mongo `$where` with input, LDAP filters concatenated with input.
- Defaults: ORM-only access with no raw sites → `implemented_by_default`.

### SEC-06 · Safe command and code execution (target: component)
Check every `os_exec`, `dynamic_code` and `template_string` sink.
- **I1** (required) Commands run without a shell and with an argument list (`subprocess.run([...])` without `shell=True`, `execFile`/`spawn` without `shell: true`, `ProcessBuilder(List)`, `exec.Command(name, args...)`, `ProcessStartInfo` with `ArgumentList`), and user-supplied arguments are allowlisted or placed after `--`.
- **I2** (required) No dynamic code evaluation or template compilation from non-constant strings (or a sandbox such as Jinja2 `SandboxedEnvironment` with constant templates).
- **P1** (blocking) `shell=True`, `os.system(`, `child_process.exec(` with interpolation, `Runtime.exec(String)` with concatenation, `sh -c` with input, where `input_derived` is true or `"unknown"`.
- **P2** (blocking) `eval(`/`new Function(`/`exec(`/SpEL `parseExpression(`/`ScriptEngine.eval(` on non-constant input; `render_template_string`/`Template(`/`from_string(` with input-derived templates.

### SEC-07 · Safe deserialization and XML parsing (target: component)
Check every `deserialization` and `xml_parser` sink. Resolve library versions from facts.
- **I1** (required) Untrusted data is deserialized only with data-only formats/loaders or a type allowlist.
- **I2** (required) XML parsers have DTDs/external entities disabled, or use a safe-by-default parser.
- **P1** (blocking) `ObjectInputStream.readObject` without an `ObjectInputFilter`/`jdk.serialFilter`; `XMLDecoder`; XStream without allowlist; Jackson default typing without a `PolymorphicTypeValidator` allowlist or `@JsonTypeInfo(use = Id.CLASS)`; `pickle`/`marshal`/`shelve`/`jsonpickle`/`dill` on external data; `yaml.unsafe_load` or `yaml.load(..., Loader=yaml.Loader|UnsafeLoader)`; .NET `BinaryFormatter`/`NetDataContractSerializer`/`LosFormatter`; Newtonsoft `TypeNameHandling` ≠ `None` without a `SerializationBinder`; `node-serialize`.
- **P2** (blocking) Java `DocumentBuilderFactory`/`SAXParserFactory`/`XMLInputFactory`/`TransformerFactory`/`SAXReader` parsing external input without `disallow-doctype-decl` (or external entities and DTD loading disabled); .NET `XmlReaderSettings.DtdProcessing = Parse` with a resolver; libxmljs `noent: true`.
- **P3** (non-blocking) Python stdlib `xml.etree`/`minidom`/`sax` on external input (use `defusedxml`); `lxml` without `resolve_entities=False`.

| Library | Safe default? |
|---|---|
| SnakeYAML ≥ 2.0 `new Yaml()` | global tags rejected by default → safe unless a permissive `TagInspector` is configured |
| SnakeYAML < 2.0 `new Yaml().load(` on input | unsafe → P1 |
| PyYAML `yaml.safe_load` / `Loader=SafeLoader` | safe |
| js-yaml ≥ 4 `load` | safe by default |
| js-yaml < 4 `load` | unsafe → P1 (`safeLoad` is safe) |
| .NET Core / .NET 5+ `XmlDocument`, `XmlReader` defaults | DTD processing prohibited → safe |
| Go `encoding/xml` | no external entities → safe |
| xml2js, fast-xml-parser | no external entity expansion → safe |

### SEC-08 · SSRF protection (target: dependency)
- **I1** (required) Destination allowlist (hosts or URL prefixes) checked before the call.
- **I2** (required) Scheme restricted to `http`/`https`.
- **I3** (required) Private, loopback, link-local and metadata addresses (`169.254.169.254`, `fd00:ec2::254`) blocked after DNS resolution, or the call goes through an egress proxy that does this.
- **I4** (non-required) Redirects disabled or re-validated.
- **P1** (blocking) An input-derived URL/host passed to the client with none of I1–I3.

### SEC-09 · Contextual output encoding (target: component)
- **I1** (required) The template engine auto-escapes by default and it is not turned off.
- **I2** (required) Every `html_raw` sink renders sanitised content (DOMPurify, bleach/nh3, OWASP Java HTML Sanitizer, HtmlSanitizer) or constants only.
- **P1** (blocking) An `html_raw` sink with `input_derived` true.
- **P2** (blocking) Autoescape off globally (`{% autoescape off %}` in base templates, `Environment(autoescape=False)`), Go `text/template` used for HTML, JSP scriptlets `<%= %>` printing request data.
- **P3** (non-blocking) An `html_raw` sink with `input_derived` `"unknown"`.

| Engine | Default |
|---|---|
| Jinja2 `Environment()` | autoescape **off** unless `autoescape=True`/`select_autoescape()` |
| Flask `render_template` (`.html`, `.htm`, `.xml`, `.xhtml` templates) | autoescape on → by default |
| Django templates | on |
| Thymeleaf `th:text` | escapes (`th:utext` does not) |
| Razor | encodes (`Html.Raw`/`HtmlString` do not) |
| Go `html/template` | contextual escaping (`text/template` does not) |
| EJS `<%=` / Handlebars `{{ }}` / Pug `#{}` | escape (`<%-`, `{{{ }}}`, `!{}` do not) |

### SEC-10 · Browser security headers and CSP (target: component)
- **I1** (required) Content-Security-Policy is set (ASVS L2 expects at least `object-src 'none'` and `base-uri 'none'` or `'self'`).
- **I2** (required) `X-Content-Type-Options: nosniff`.
- **I3** (required) Framing protection: CSP `frame-ancestors` or `X-Frame-Options`.
- **I4** (required) `Strict-Transport-Security` when served over HTTPS (app, ingress or edge).
- **Platform:** headers set in nginx/ingress/CDN config in the repo, or `OVERRIDES.platform.security_headers_at_edge: true`.
- **P1** (non-blocking) CSP with `unsafe-inline` or `unsafe-eval` in `script-src`, or wildcard sources.

| Stack | Default headers |
|---|---|
| Spring Security | `nosniff`, `X-Frame-Options: DENY`, HSTS on HTTPS, cache control; **no CSP** → I2–I4 by default, I1 needs `contentSecurityPolicy(...)` |
| helmet (Express) | CSP (`default-src 'self'` …), HSTS, `nosniff`, framing protection → I1–I4 by default (check that `helmet()` options do not disable them) |
| Django `SecurityMiddleware` + `XFrameOptionsMiddleware` | `nosniff` and `X-Frame-Options: DENY` by default; HSTS only with `SECURE_HSTS_SECONDS` > 0; CSP needs `django-csp` or Django's built-in CSP settings where available |
| ASP.NET Core | HSTS via `UseHsts()` (templates call it outside Development); no CSP/nosniff by default |
| Flask, FastAPI, Go, Next.js | none by default (Flask-Talisman, secure middleware, `next.config` `headers()` add them) |

### SEC-11 · Authentication enforced (target: unit)
Find the enforcement mechanism that covers this unit:
- **I1** (required) The unit cannot be reached without authentication: a global rule (Spring `SecurityFilterChain` with `anyRequest().authenticated()`/`denyAll()`, ASP.NET `FallbackPolicy` requiring an authenticated user, NestJS global guard via `APP_GUARD`/`useGlobalGuards`, Django `LoginRequiredMiddleware`, FastAPI app/router-level `dependencies=[Depends(...)]`, Express auth middleware mounted before the router, Go middleware on the router/group, gRPC auth interceptor) or a per-unit control (`[Authorize]`, `@UseGuards`, `@login_required`, DRF `permission_classes` other than `AllowAny`, `Depends(get_current_user)`, route-level middleware).
- **P1** (blocking) The unit is explicitly opened (`permitAll()`, `[AllowAnonymous]`, `AllowAnonymous()`, `@Public()`, `AllowAny`, `@login_not_required`, excluded from the auth middleware) and is **not** in `OVERRIDES.public_units`.
- **P2** (blocking) No enforcement covers the unit.
- **Platform:** `OVERRIDES.platform.authentication_at_gateway: true`, or mesh `RequestAuthentication` + `AuthorizationPolicy` requiring a principal for this host/path in repo manifests → `implemented_by_platform`.

| Framework | Default when no auth configuration is found |
|---|---|
| Spring Security on the classpath with no custom `SecurityFilterChain` | every request authenticated → `implemented_by_default` |
| Spring Security with a custom chain | only what the chain's rules say (first match wins); unmatched requests follow the last rule |
| ASP.NET Core | `FallbackPolicy` is null → endpoints without `[Authorize]` are open → P2 |
| Django REST framework | `DEFAULT_PERMISSION_CLASSES` = `AllowAny` → P2 unless set |
| Django (views) | open unless `LoginRequiredMiddleware`, `@login_required` or mixins |
| Express, Fastify, Koa, FastAPI, Flask, Go | open unless middleware/dependencies are added |
| `@nestjs/authentication` | global guard: every route requires a signed-in user; `@Public()` opts out |

### SEC-12 · Secure token and session validation (target: component)
- **I1** (required for JWT) Signatures verified with keys from trusted configuration (issuer JWKS URI/public key), never from the token's `jku`/`x5u`/`jwk` headers.
- **I2** (required for JWT) Algorithms pinned to an allowlist; `none` rejected.
- **I3** (required for JWT) `exp`/`nbf` validated.
- **I4** (non-required) `aud` and `iss` validated.
- **I5** (required for cookies) Session cookies are `Secure`, `HttpOnly` and `SameSite` (Lax or Strict).
- **I6** (required for sessions) Session ID rotated on login.
- **I7** (non-required) Idle/absolute session timeouts set.
- **P1** (blocking) PyJWT `options={"verify_signature": False}`; `jsonwebtoken.decode(` used for auth instead of `verify(`; jjwt `parseUnsecuredClaims`/unsecured parser; `ignoreExpiration: true`; `ValidateLifetime = false`; `ValidateIssuerSigningKey = false`; `RequireSignedTokens = false`; `jsonwebtoken.verify` without `algorithms` when keys are shared secrets and public keys.
- **P2** (non-blocking) `ValidateAudience = false`/no `audience` configured; express-session `cookie.secure` not set to true for production.

| Stack | Defaults |
|---|---|
| Spring Security OAuth2 resource server (`issuer-uri`/`jwk-set-uri`) | signature, `exp`/`nbf`, and `iss` (with `issuer-uri`) validated → I1–I3 by default; `aud` only when configured |
| Spring Security sessions | session fixation protection on (`changeSessionId`) → I6 by default; `server.servlet.session.timeout` 30 min → I7 by default |
| express-session | `httpOnly` true, `secure` false, `sameSite` unset → I5 not met unless configured; I6 needs `req.session.regenerate` |
| Django sessions | `SESSION_COOKIE_HTTPONLY` true, `SESSION_COOKIE_SAMESITE` "Lax", `SESSION_COOKIE_SECURE` **false** → I5 not met unless set; session key rotated on login → I6 by default |
| ASP.NET Core cookie auth | `HttpOnly` true, `SameSite` Lax, `Secure` same-as-request → I5 by default when HTTPS-only |
| ASP.NET Core `JwtBearer` | validates signature, lifetime, issuer and audience when configured → I1–I4 by default |

### SEC-13 · Password storage (target: component)
- **I1** (required) Adaptive hashing: Argon2id, scrypt, bcrypt or PBKDF2.
- **I2** (required) Adequate work factor (OWASP guidance: bcrypt cost ≥ 10; PBKDF2-HMAC-SHA256 ≥ 600,000 iterations; Argon2id ≥ 19 MiB memory, 2 iterations).
- **P1** (blocking) MD5/SHA-1/SHA-2 (salted or not) used for passwords, reversible encryption, or plaintext storage/comparison.
- Defaults: Spring Security `PasswordEncoderFactories.createDelegatingPasswordEncoder()` (bcrypt), Django's default PBKDF2 hasher, ASP.NET Core Identity `PasswordHasher` (PBKDF2), `@nestjs/authentication` (scrypt) → I1+I2 by default.

### SEC-14 · Brute-force protection on login (target: unit)
- **I1** (required) Throttling or lockout on this login unit: rate limiter scoped to the route (express-rate-limit, `@nestjs/throttler`, slowapi, Bucket4j filter on the path, ASP.NET rate limiter policy on the endpoint), django-axes, ASP.NET Identity `PasswordSignInAsync(..., lockoutOnFailure: true)`, failed-attempt counters with lockout or CAPTCHA.
- **Platform:** gateway/WAF rule for the login path in the repo, or `OVERRIDES.platform.rate_limiting_at_gateway: true` → `implemented_by_platform`.
- **P1** (non-blocking) ASP.NET Identity `PasswordSignInAsync(..., lockoutOnFailure: false)` (what the project templates pass).

### SEC-15 · CSRF protection (target: component)
- **I1** (required) Anti-CSRF tokens or equivalent origin checks on state-changing, cookie-authenticated requests.
- **I2** (non-required) Session cookies `SameSite=Lax` or `Strict` (defence in depth).
- **P1** (blocking) Protection disabled for cookie-authenticated routes: `csrf().disable()`/`csrf(AbstractHttpConfigurer::disable)`/`csrf(csrf -> csrf.disable())`, `@csrf_exempt` on mutating views, `IgnoreAntiforgeryToken` on mutating actions.
- Defaults: Spring Security CSRF on; Django `CsrfViewMiddleware` on (in the default `MIDDLEWARE`); DRF `SessionAuthentication` enforces CSRF; ASP.NET Core Razor Pages validate antiforgery tokens; Next.js server actions compare `Origin` with `Host` → `implemented_by_default`. Express, Fastify, FastAPI, Flask, Go: nothing by default (csrf-csrf, Flask-WTF `CSRFProtect`, gorilla/csrf add it).

### SEC-16 · Deny-by-default, function-level authorization (target: unit)
- **I1** (required) An explicit authorization decision covers this unit: role/permission/policy at the route or method (`hasRole`/`hasAuthority` request matchers, `@PreAuthorize`, `@Secured`, `@RolesAllowed`, `[Authorize(Roles=…|Policy=…)]`, `RequireAuthorization("policy")`, NestJS roles guard + `@Roles`, DRF `permission_classes`, `@permission_required`, FastAPI `Security(..., scopes=[...])`, casbin/OPA checks), or the unit is in `OVERRIDES.any_authenticated_user_units` and SEC-11 is satisfied.
- **I2** (required) Unmatched routes are denied or at least require authentication (deny-by-default at the global level).
- **P1** (blocking) An admin-like path protected only by authentication.
- **P2** (non-blocking) The only check is an ad-hoc `if` inside the handler body (record it; it counts toward I1).

### SEC-17 · Object-level and tenant-level authorization (target: unit)
Trace the handler to the data lookup (up to two hops).
- **I1** Ownership/tenant scoping in the lookup: query filtered by the current principal or tenant (`findByIdAndOwnerId(id, currentUser)`, `.filter(owner=request.user)`, DRF `get_queryset` filtered by `request.user`, `WHERE tenant_id = :tenant`, EF Core global query filters `HasQueryFilter` on tenant/owner, Hibernate filters).
- **I2** Explicit object check after lookup: `@PostAuthorize("returnObject.owner == authentication.name")`, `@PreAuthorize` with a permission evaluator on `#id`, ASP.NET `IAuthorizationService.AuthorizeAsync(user, resource, policy)`, policy/ability checks (CASL, casbin, Pundit-style), explicit owner comparison returning 403/404.
- **P1** (blocking) Lookup by ID only (`findById(id)`, `get_object_or_404(Model, pk=id)`, `Model.findById(req.params.id)`, `db.Find(&x, id)`) and the result is returned or modified with no I1/I2.
- **Status:** I1 or I2 → `implemented`; P1 → `missing`; data access cannot be traced → `cannot_verify_statically`.

### SEC-18 · CORS (target: component)
- **I1** (required) No CORS configuration (browsers keep same-origin) **or** an explicit allowlist of origins.
- **P1** (blocking) Credentials allowed with any origin: reflecting the request `Origin` (`origin: true` with `credentials: true`), `allowedOriginPatterns("*")` with `allowCredentials(true)`, `SetIsOriginAllowed(_ => true)` with `AllowCredentials()`, regex allowing any subdomain of an untrusted suffix.
- **P2** (non-blocking) `Access-Control-Allow-Origin: *` without credentials (for example `cors()` with no options in Express, which allows any origin).
- **Status:** no CORS config → `implemented_by_default`.

### SEC-20 · No hard-coded secrets (target: component)
Search code, config, `.env*` (except `.env.example`/`.env.sample`/`.env.template`), deployment files and Dockerfiles:
- private keys `-----BEGIN [A-Z ]*PRIVATE KEY-----`; AWS keys `AKIA[0-9A-Z]{16}`; GitHub tokens `gh[pousr]_[A-Za-z0-9]{36,}`; Slack `xox[abprs]-`; Google API keys `AIza[0-9A-Za-z_-]{35}`; Stripe `sk_live_`; credentials in URLs `://[^/:@\s]+:[^/@\s]+@`; and assignments `(password|passwd|pwd|secret|token|api[_-]?key|client[_-]?secret|access[_-]?key)\s*[:=]\s*["'][^"'${}<>]{8,}["']`.
- Ignore placeholders and references: `${…}`, `{{…}}`, `<…>`, `%(…)s`, `process.env.X`, `os.environ[...]`, `vault:`, `secretKeyRef`.
- **I1** (required) No hard-coded secret found.
- **I2** (non-required) Secrets come from env vars or a secret manager (Vault, cloud secret managers, Kubernetes `Secret` references).
- **P1** (blocking) A real-looking secret (record location and kind only; the value is `<redacted>`).
- **P2** (non-blocking) Default credentials in committed config (`password: admin`, `changeme`, `secret`).

### SEC-21 · No sensitive data in logs (target: component)
Search logging calls (`log.*`, `logger.*`, `LOG.*`, `console.*`, `print(`, `logging.*`, `fmt.Print*`/`log.Print*`, `slog.*`, `zap`/`zerolog`, `ILogger`/`_logger.Log*`, Serilog `Log.*`).
- **P1** (blocking) Arguments include passwords, tokens, secrets, API keys, `Authorization` headers, session IDs or cookies (identifiers matching `password|passwd|pwd|secret|token|api[_-]?key|authorization|cookie|session[_-]?id`).
- **P2** (non-blocking) Whole request bodies/headers or PII fields logged (`req.body`, `request.headers`, `@RequestBody` objects, `ssn`, `card`, `cvv`, `pan`, `dob`, `email`, `phone`), or wire/payload logging enabled in config (`logging.level.org.apache.http.wire=DEBUG`, `spring.mvc.log-request-details=true`, `CommonsRequestLoggingFilter` with payload/headers).
- **I1** (required) No P1 or P2 findings.
- **I2** (non-required) A masking/redaction facility is configured (pino `redact`, logback/log4j2 masking, structlog processors, Serilog destructuring policies).

### SEC-22 · Secure transport (target: component)
- **I1** (required) Certificate/hostname verification is never disabled.
- **I2** (required) Outbound URLs and connection strings use TLS (`https://`, `sslmode=require|verify-full`, `Encrypt=True`), except loopback or in-cluster traffic covered by mesh mTLS.
- **I3** (required) Inbound traffic is TLS: app TLS config, Ingress `tls:`, or `OVERRIDES.platform.tls_terminated_at_ingress: true` (platform).
- **P1** (blocking) `verify=False`; `rejectUnauthorized: false`; `NODE_TLS_REJECT_UNAUTHORIZED=0`; `InsecureSkipVerify: true`; trust-all `TrustManager`/`NoopHostnameVerifier`; `ServerCertificateCustomValidationCallback` returning true or `DangerousAcceptAnyServerCertificateValidator`; `ssl._create_unverified_context`/`CERT_NONE`; TLS 1.0/1.1 or SSL forced as the minimum.
- **P2** (non-blocking) `http://` to non-local hosts; `sslmode=disable`, `useSSL=false`, `TrustServerCertificate=True`.

### SEC-23 · Error responses do not leak internals (target: component)
- **I1** (required) Production error responses omit stack traces, exception class names and internal messages.
- **P1** (blocking) `server.error.include-stacktrace=always`/`include-exception=true`; Django `DEBUG = True` hard-coded in settings used for deployment; Flask/FastAPI `debug=True` in the deployed entry point; `UseDeveloperExceptionPage()` outside an `IsDevelopment()` check; handlers returning `err.stack`/`traceback.format_exc()`/`e.printStackTrace()` output to clients.
- **P2** (non-blocking) Raw exception messages returned to clients (`http.Error(w, err.Error(), 500)`, `res.status(500).send(err.message)`); Apollo/GraphQL debug or stack traces in error extensions without `NODE_ENV=production`.
- Defaults: Spring Boot `include-stacktrace` and `include-message` are `never` → by default. Express's default error handler prints the stack unless `NODE_ENV=production` → check the Dockerfile/deployment env; without it → P2.

### SEC-24 · Dependency vulnerability management (target: component)
- **I1** (required) Dependency versions are locked: a lockfile per ecosystem (`F.deps.lockfiles`), or exact versions/BOM-managed versions for Maven/Gradle/.NET.
- **I2** (required) Automated vulnerability scanning: a CI step running OWASP Dependency-Check, Trivy, Grype, OSV-Scanner, Snyk, `npm|yarn|pnpm audit`, pip-audit, safety, govulncheck, `dotnet list package --vulnerable`, GitHub `dependency-review-action`, Mend, Black Duck, JFrog Xray or Sonatype; or Dependabot/Renovate configured for security updates.
- **Platform:** `OVERRIDES.platform.dependency_scanning_external: true` → I2 as platform evidence.

### SEC-25 · Least-privilege container runtime (target: deployment)
- **Kubernetes I1** (required) `runAsNonRoot: true` or a non-zero `runAsUser` (pod or container `securityContext`).
- **Kubernetes I2** (required) `allowPrivilegeEscalation: false`.
- **Kubernetes I3** (non-required) `readOnlyRootFilesystem: true`; **I4** (non-required) `capabilities.drop: ["ALL"]`.
- **Dockerfile I1** (required) The final stage sets a non-root `USER`, or uses a non-root base image (`…:nonroot` distroless).
- **P1** (blocking) `privileged: true`, `hostPID`/`hostNetwork: true`, or `runAsUser: 0`.
- **P2** (non-blocking) `hostPath` volumes; added capabilities such as `SYS_ADMIN`/`NET_ADMIN`.

### SEC-26 · Open-redirect protection (target: component)
Check every `redirect` sink with `input_derived` true or `"unknown"`.
- **I1** (required) The target is validated: relative-path-only (starts with `/` and not `//` or `/\`), host allowlist, Django `url_has_allowed_host_and_scheme`, ASP.NET `Url.IsLocalUrl`/`LocalRedirect`, Spring `UrlUtils`/allowlist.
- **P1** (blocking) An input-derived redirect target with no validation.

### SEC-27 · GraphQL hardening (target: component)
- **I1** (required) Query depth limit (graphql-depth-limit, Apollo/Envelop validation rules, graphql-java `MaxQueryDepthInstrumentation`, HotChocolate `AddMaxExecutionDepthRule`, gqlgen complexity extension, strawberry `QueryDepthLimiter`).
- **I2** (non-required) Cost/complexity limits or persisted-query allowlist.
- **I3** (required) Introspection disabled in production.
- Defaults: Apollo Server disables introspection when `NODE_ENV=production` → I3 by default if the deployment sets it. Spring for GraphQL (`spring.graphql.schema.introspection.enabled`), graphene, strawberry and HotChocolate allow introspection unless disabled.

---

## Output format

`OUT/implementation/<slug>__backend_service.json` (schema: `PROMPTS/schemas/implementation.schema.json`):

```json
{
  "schema_version": "prs-implementation/1",
  "prompt": "03-implementation-check/backend_service@1",
  "catalog_version": 1,
  "component_id": "cmp:services/orders",
  "app_type": "backend_service",
  "role": "primary",
  "results": [
    {
      "result_id": "RES-01@dep:http:payment-service",
      "practice_id": "RES-01",
      "category": "resilience",
      "severity": "high",
      "target_id": "dep:http:payment-service",
      "applicability": "applicable",
      "status": "missing",
      "criteria_met": ["I1"],
      "criteria_failed": ["I2"],
      "pitfalls": ["P1"],
      "defaults_applied": [{"library": "spring-webflux WebClient (Reactor Netty)", "version": "managed", "setting": "response timeout", "default": "none"}],
      "findings": [{"file": "services/orders/src/main/java/com/acme/PaymentClient.java", "line": 21, "symbol": "PaymentClient", "snippet": "WebClient.builder().baseUrl(baseUrl).build()", "issue": "P1"}],
      "evidence": [],
      "notes": ""
    }
  ],
  "search_log": [{"pattern": "responseTimeout|ReadTimeoutHandler", "paths": "services/orders", "hits": 0}]
}
```

- One result per work-list item, same `result_id`, same order.
- `criteria_met` + `criteria_failed` list every criterion that applies to the target (omit criteria marked "required if/when…" when their condition is false).
- `notes`: at most 300 characters; plain facts only.
