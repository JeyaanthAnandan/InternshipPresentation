---
name: prs-implementation-frontend-web
version: 1
description: PRS step 3 for app type frontend_web. For every applicable or undetermined practice result from step 2, checks source, build config, hosting config and deployment files and decides whether the practice is implemented, using fixed criteria, pitfalls and default tables.
inputs: CODE_ROOT, CONFIG_PATHS (optional), OUT, OVERRIDES (optional), COMPONENT, APP_TYPE=frontend_web, ROLE, PROMPTS
output: OUT/implementation/<component slug>__frontend_web.json
---

# PRS step 3 — Implementation check: frontend web

## Role

For each practice that step 2 marked `applicable` or `undetermined`, find out whether it is **implemented** in this browser app, and record evidence. You read code and config; you never run, build or change anything.

Read first: `PROMPTS/shared/conventions.md`, `PROMPTS/shared/practice-catalog.yaml`, `OUT/facts.json` and `OUT/applicability/<slug>__frontend_web.json`.

## Procedure

1. **Work list:** every result in the applicability file with status `applicable` or `undetermined`, in file order. Do not add or drop results.
2. **Search scope:** the component root (source, `public/`, `index.html`, build configs such as `vite.config.*`, `webpack.config.*`, `angular.json`, `next.config.*`, `nuxt.config.*`, `svelte.config.*`), hosting configs (`nginx*.conf`, `vercel.json`, `netlify.toml`, `_headers`, `staticwebapp.config.json`, `firebase.json`, CDN IaC), `CONFIG_PATHS`, deployment files and CI files (`F.ci.files`). Apply conventions §9 exclusions.
3. For each result, evaluate the criteria (`I…`) and pitfalls (`P…`) of its practice section. A criterion is met only with evidence. Use only the defaults written in this prompt; if a library is not covered and nothing is configured explicitly, use `cannot_verify_statically` with `notes` starting `DEFAULT_UNKNOWN:`.
4. Choose the status with the practice's **Status** line, or else this order (first match wins):
   1. any **blocking** pitfall → `missing`
   2. all required criteria met **and** a non-blocking pitfall present → `partially_implemented`
   3. all required criteria met explicitly → `implemented`
   4. all required criteria met, at least one only through a documented default → `implemented_by_default`
   5. all required criteria met, at least one only through platform evidence (repo hosting/edge config or `OVERRIDES.platform`) → `implemented_by_platform`
   6. some required criteria met → `partially_implemented`
   7. the deciding evidence lives outside the repository or needs runtime data → `cannot_verify_statically`
   8. otherwise → `missing`
5. Record the result (format at the end). Put each offending location in `findings` with the pitfall ID (max 20, sorted by file and line).
6. Write the output, canonicalize and validate (conventions §12). Test evidence is out of scope.

---

## Performance

### PERF-08 · Bundle size budget enforced (target: component)
- **I1** (required) A size budget is configured: webpack `performance` with `maxAssetSize`/`maxEntrypointSize`; Angular `angular.json` `budgets`; size-limit (`.size-limit.*` or `"size-limit"` in `package.json`); bundlesize; Lighthouse CI `resource-summary:*:size` assertions or a `budget.json`.
- **I2** (required) The budget fails the build or CI: webpack `hints: "error"`, Angular budget `maximumError`, size-limit/bundlesize/LHCI executed in a CI workflow.
- **P1** (non-blocking) Warning-only budgets.
- Defaults: webpack in production mode warns at 250,000 bytes per asset/entrypoint (`hints: "warning"`) → I1 by default, I2 not met → `partially_implemented`. Vite only warns on chunks above `build.chunkSizeWarningLimit` (500 kB) → same. Next.js, Nuxt, SvelteKit have no build-failing budget by default.

### PERF-09 · Route-level code splitting (target: component)
- **I1** (required) Non-initial routes are lazy-loaded: `React.lazy(() => import(...))`, React Router `lazy:` route property, Angular `loadComponent`/`loadChildren`, Vue Router `component: () => import(...)`.
- **P1** (non-blocking) Routes whose page component is imported statically into the router (list each).
- Defaults: file-based routing in Next.js, Nuxt, SvelteKit, Remix/React Router framework mode and Astro splits per route → `implemented_by_default`.
- **Status:** all non-initial routes lazy → `implemented`; some → `partially_implemented`; none → `missing`.

### PERF-10 · Optimized images (target: component)
- **I1** (required) Images use the framework optimizer or responsive markup: `next/image`, Nuxt `<NuxtImg>`/`<NuxtPicture>`, Angular `NgOptimizedImage` (`ngSrc`), `srcset`/`sizes`, `<picture>`.
- **I2** (required) Below-the-fold images are lazy-loaded (`loading="lazy"`).
- **I3** (required) Images declare `width`/`height` (or an aspect ratio) to avoid layout shift.
- **P1** (non-blocking) Raster images larger than 500 KB committed under `public/`, `static/` or `assets/` (list each with size).
- Defaults: `next/image` and `NgOptimizedImage` lazy-load by default and require dimensions → I1–I3 by default where used.
- **Status:** count `<img>` usages; all compliant → `implemented`/`implemented_by_default`; some → `partially_implemented`; none → `missing`.

### PERF-11 · Core Web Vitals budgets or field measurement (target: component)
- **I1** Lighthouse CI config (`lighthouserc.*`, `.lighthouserc.*`) asserting `largest-contentful-paint` ≤ 2500 ms, `cumulative-layout-shift` ≤ 0.1 and `total-blocking-time` (lab stand-in for INP) at `error` level, or `categories:performance` with `minScore`.
- **I2** LHCI (or an equivalent synthetic check) runs in a CI workflow (`lhci autorun`, `treosh/lighthouse-ci-action`).
- **I3** Field measurement: the `web-vitals` library reporting `onLCP`/`onINP`/`onCLS`, or a RUM SDK initialised in the app (Sentry browser tracing, Datadog RUM, New Relic Browser, Dynatrace, Elastic RUM, Vercel Speed Insights).
- **P1** (non-blocking) Thresholds looser than the "good" values (LCP > 2500 ms, CLS > 0.1, INP > 200 ms).
- **Status:** (I1 and I2) or I3 → `implemented`; I1 without I2 → `partially_implemented`; P1 → `partially_implemented`; none → `missing`. Always add `notes`: `Actual Core Web Vitals need field data (p75).`

### PERF-12 · Long-term caching for static assets (target: component)
- **I1** (required) Production builds emit content-hashed file names.
- **I2** (required) Hashed assets are served with long-lived cache headers (`Cache-Control: public, max-age=31536000, immutable`) via hosting config in the repo.
- **I3** (non-required) The HTML entry is not cached long (`no-cache`).
- Defaults: Vite, Angular CLI production builds (`outputHashing: "all"`), Next.js, Nuxt, SvelteKit and Create React App hash file names → I1 by default; plain webpack needs `[contenthash]` in `output.filename`. Next.js serves `/_next/static` with immutable caching → I2 by default when self-hosted with `next start` or on Vercel.
- **Status:** I2 evidence absent and no hosting config in the repo → `cannot_verify_statically`; hosting config present without cache headers → `partially_implemented`.

### PERF-13 · Third-party scripts do not block rendering (target: component)
- **I1** (required) External scripts load with `async`, `defer` or `type="module"`, through Next.js `<Script strategy="afterInteractive"|"lazyOnload">`, or are injected after load.
- **P1** (non-blocking) A synchronous `<script src="https://…">` in `<head>` without `async`/`defer` (list each).

---

## Resilience

### RES-01 · Timeouts on outbound API calls (target: dependency)
Browsers do not expose connect timeouts, so only the request timeout is checked.
- **I2** (required) Every request through this client has a finite timeout: `AbortSignal.timeout(ms)` or an `AbortController` with a timer passed as `signal`; axios `timeout` > 0 on the instance or global defaults; RxJS `timeout(ms)` on Angular `HttpClient` calls (or an interceptor that adds it); an Apollo timeout link; ky's default.
- **P1** (blocking) The effective timeout is none (table below).
- **P2** (non-blocking) A timeout above 60 s.
- SSR/server-side fetches in meta-frameworks run on Node.js: Node's global `fetch` (undici) waits up to 300 s for headers and body → I2 by default, P2.

| Client | Default |
|---|---|
| Browser `fetch` | none → P1 unless a `signal` with a timeout is passed |
| axios | `timeout: 0` = none → P1 |
| Angular `HttpClient` | none → P1 unless a `timeout` operator or interceptor applies |
| Apollo `HttpLink` | uses `fetch` → none |
| ky | 10 s → by default |
| TanStack Query, SWR, RTK Query | add no timeout; the underlying client decides |

### RES-02 · Safe retries (target: dependency)
List every retry layer for this client (data-fetching library defaults count).
- **I0** No retry layer (fail fast) → satisfies the practice.
- **I1–I5** (required if retries exist): bounded attempts; backoff; jitter; only transient failures (network errors, 408/429/5xx); one layer only.
- **P1** (blocking) Unbounded retries (`retry: true` in TanStack Query, `errorRetryCount` effectively unlimited in SWR, custom loops without a cap).
- **P2** (blocking) Retrying mutations (POST/PUT/PATCH/DELETE) without an idempotency key.
- **P3** (non-blocking) Two or more layers (for example axios-retry **and** TanStack Query retries).
- **P4** (non-blocking) No backoff or no jitter.
- **Status:** I0 → `implemented`; else the general order.

| Layer | Default |
|---|---|
| TanStack Query (queries) | 3 retries, exponential backoff (`min(1000 × 2^n, 30000)` ms), no jitter → I1, I2 by default; P4 (no jitter); retries every error unless `retry` is a function |
| TanStack Query (mutations) | no retries |
| RTK Query | no retries unless the `retry` utility wraps the base query |
| Apollo Client | no retries unless `RetryLink` is added |
| SWR | retries failed requests with exponential backoff by default; check `errorRetryCount`/`shouldRetryOnError`, else `DEFAULT_UNKNOWN` for the bound |
| axios-retry | 3 retries, no delay unless `retryDelay` is set → P4 |

### RES-08 · Container requests and limits (target: deployment)
Same criteria as the backend prompt: **I1** CPU and memory requests, **I2** memory limit on every container; **P1** (non-blocking) no CPU request or limit below request; unresolved templated values → `cannot_verify_statically`.

### RES-12 · Error boundaries / global error handling (target: component)
- **I1** (required) Rendering errors are contained at the root and at least at route level: React error boundary (`componentDidCatch`/`getDerivedStateFromError` or `react-error-boundary`) wrapping the app or routes, React Router `errorElement`/route `ErrorBoundary`, Next.js `app/error.tsx` plus `app/global-error.tsx`, Angular custom `ErrorHandler` provider, Vue `app.config.errorHandler`, SvelteKit `+error.svelte` and `handleError` hooks, Nuxt `error.vue`.
- **I2** (required) Unhandled promise rejections and async errors are caught and reported: `window.addEventListener("unhandledrejection", …)`, an error-reporting SDK initialised (Sentry, Datadog RUM, etc.), TanStack `QueryCache`/`MutationCache` `onError`, Angular `ErrorHandler`.
- **P1** (non-blocking) Swallowed errors: empty `catch {}` or `.catch(() => {})` on API calls (list each).

### RES-13 · Loading, error and empty states (target: unit `ui_route`)
Check the route's component and its direct children (one level).
- **I1** (required) Loading state: `isLoading`/`isPending` branches, `<Suspense fallback>`, Next.js `loading.tsx` in the segment or an ancestor, Angular `@if`/`*ngIf` on loading or `async` pipe with an `else` template, Vue `v-if="loading"`.
- **I2** (required) Error state: `isError`/`error` branch, `errorElement`/`error.tsx` covering the route, RxJS `catchError` rendering a message.
- **I3** (non-required) Empty state for collections (`length === 0` branch or an empty-state component).
- **Status:** I1 and I2 → `implemented`; one of them → `partially_implemented`; neither → `missing`.

---

## Security

### SEC-06 · No dynamic code evaluation (target: component)
- **I1** (required) No `eval(`, `new Function(`, `Function(`, `setTimeout`/`setInterval` with string arguments, or template compilation from non-constant strings.
- **P1** (blocking) Any of the above with non-constant input (list each).
- **P2** (non-blocking) The same with constant strings.

### SEC-09 · Output encoding in the browser (target: component)
- **I1** (required) Rendering goes through the framework's escaping (JSX expressions, Angular interpolation and sanitization, Vue mustache, Svelte `{}`) → `implemented_by_default` for React, Angular, Vue, Svelte and Solid.
- **I2** (required) Every raw-HTML sink renders sanitised content (`DOMPurify.sanitize`, `sanitize-html`) or constants only: `dangerouslySetInnerHTML`, `v-html`, Svelte `{@html}`, `innerHTML`/`outerHTML`/`insertAdjacentHTML`/`document.write`, jQuery `.html(`, Lit `unsafeHTML`.
- **I3** (required when user- or API-supplied URLs are bound to `href`/`src`) Only `http`/`https`/relative URLs are allowed (no `javascript:`). Angular sanitizes URLs by default; React 19 blocks `javascript:` URLs but URL validation is still expected; Vue and Svelte do not.
- **P1** (blocking) A raw-HTML sink fed by remote data, URL parameters or user input without a sanitizer; `bypassSecurityTrustHtml`/`Script`/`Style`/`Url`/`ResourceUrl` on non-constant values.
- **P2** (non-blocking) A raw-HTML sink whose source is unknown.
- Note in `notes` if Trusted Types are enforced (`require-trusted-types-for 'script'`).

### SEC-10 · Security headers and CSP (target: component)
Find where the app's responses get headers: hosting configs in the repo (`nginx*.conf` `add_header`, `vercel.json` `headers`, `netlify.toml`/`_headers`, `staticwebapp.config.json` `globalHeaders`, `firebase.json`), framework config (`next.config.*` `headers()`/middleware, Nuxt `routeRules`/nuxt-security, SvelteKit `kit.csp` or `handle` hook, Angular SSR server), CDN IaC (CloudFront response headers policy), or `<meta http-equiv="Content-Security-Policy">`.
- **I1** (required) Content-Security-Policy (at least `object-src 'none'` and `base-uri`).
- **I2** (required) `X-Content-Type-Options: nosniff`.
- **I3** (required) Framing protection via CSP `frame-ancestors` or `X-Frame-Options` (a `<meta>` CSP cannot carry `frame-ancestors`).
- **I4** (required) `Strict-Transport-Security`.
- **Platform:** `OVERRIDES.platform.security_headers_at_edge: true`.
- **P1** (non-blocking) `unsafe-inline`/`unsafe-eval` in `script-src`, or wildcard sources.
- **Status:** no hosting/header config in the repo and no override → `cannot_verify_statically`.

### SEC-11 · Protected routes require authentication (target: unit `ui_route`)
- **I1** (required) A guard covers the route (on the route or an ancestor): Angular `canActivate`/`canMatch`; React Router `loader` redirect or a wrapper (`RequireAuth`, `ProtectedRoute`, `PrivateRoute`) around the element or a parent layout route; Next.js `middleware.ts` whose `matcher` covers the path and checks the session, or a server component/layout calling `redirect()` when `auth()`/`getServerSession()` returns no session; Vue Router `beforeEach`/`beforeEnter` with an auth check (including `meta.requiresAuth` patterns); Nuxt route middleware (`definePageMeta({ middleware: … })` or global); SvelteKit `hooks.server` `handle` or `+layout(.server)` `load` redirect; MSAL `MsalGuard`/`MsalAuthenticationTemplate`.
- **P1** (blocking) The route is outside every guard and is not a public unit.
- Always add `notes`: `Client-side guard only; server-side enforcement is checked in backend SEC-11/SEC-16.`

### SEC-19 · Tokens stored safely in the browser (target: component)
Policy: `OVERRIDES.policy.allow_tokens_in_web_storage` (default `false`).
- **I1** (required) Access/refresh/ID tokens and session identifiers are not kept in `localStorage`, `sessionStorage`, IndexedDB or JS-set cookies (`document.cookie = "token=…"`); they live in `HttpOnly` cookies set by the server/BFF, or in memory.
- **I2** (required) Tokens never appear in URLs; no OAuth implicit flow (`response_type=token`/`id_token token`).
- **I3** (non-required) Logout clears client-side auth state and calls the server logout.
- **P1** (blocking) Tokens in web storage while the policy is `false`; implicit flow or tokens in query strings.
- **P2** (non-blocking) Tokens in web storage while the policy is `true`.

| Library | Default token storage |
|---|---|
| `@azure/msal-browser` | `cacheLocation: "sessionStorage"` → web storage |
| `oidc-client-ts` | user store in `sessionStorage` → web storage |
| `@auth0/auth0-spa-js` | `cacheLocation: "memory"` → in memory |
| Auth.js / NextAuth | server-set `HttpOnly` cookies → I1 by default |

### SEC-20 · No secrets in code, config or the bundle (target: component)
Use the backend SEC-20 search patterns, plus:
- **P1** (blocking) A secret in a browser-exposed variable or file: `VITE_*`, `NEXT_PUBLIC_*`, `REACT_APP_*`, `NUXT_PUBLIC_*`, `PUBLIC_*` (SvelteKit), Angular `environment*.ts`, `public/` config JSON (private API keys, client secrets, DB URLs; publishable keys such as Stripe `pk_` or Firebase web config are not secrets).
- **P2** (non-blocking) Production source maps published (`build.sourcemap: true`, `productionBrowserSourceMaps: true`, Angular `sourceMap: true` in the production configuration).
- **I1** (required) No P1 findings.

### SEC-22 · Secure transport (target: component)
- **I1** (required) API base URLs for non-local hosts use `https://` in every production environment file/config.
- **I2** (required) Server-side code (SSR, BFF routes, build scripts) never disables TLS verification (`rejectUnauthorized: false`, `NODE_TLS_REJECT_UNAUTHORIZED=0`).
- **P1** (blocking) Any I2 violation.
- **P2** (non-blocking) `http://` URLs to non-local hosts.

### SEC-24 · Dependency vulnerability management (target: component)
- **I1** (required) A committed lockfile (`package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `bun.lock*`).
- **I2** (required) Automated scanning: CI step with `npm|yarn|pnpm audit`, OSV-Scanner, Trivy, Snyk, OWASP Dependency-Check, GitHub `dependency-review-action`, etc., or Dependabot/Renovate configured for security updates.
- **Platform:** `OVERRIDES.platform.dependency_scanning_external: true` → I2 as platform evidence.

### SEC-25 · Least-privilege container runtime (target: deployment)
Same criteria as the backend prompt: Kubernetes **I1** `runAsNonRoot`/non-zero `runAsUser`, **I2** `allowPrivilegeEscalation: false`; Dockerfile **I1** non-root `USER` in the final stage (for example `nginxinc/nginx-unprivileged` or `USER nginx` with a non-privileged port); **P1** (blocking) `privileged: true`, `hostPID`/`hostNetwork`, `runAsUser: 0`.

### SEC-26 · Open-redirect protection (target: component)
Check every `redirect` sink with `input_derived` true or `"unknown"` (`window.location = …`, `location.href = …`, `router.push(…)`, `navigate(…)`, `redirect(…)` fed by `returnUrl`/`next`/`redirect` query parameters).
- **I1** (required) The target is validated: same-origin relative path only (starts with `/`, not `//` or `/\`), or a host allowlist (`new URL(target, location.origin).origin === location.origin`).
- **P1** (blocking) An unvalidated redirect target.

---

## Output format

`OUT/implementation/<slug>__frontend_web.json` (schema: `PROMPTS/schemas/implementation.schema.json`):

```json
{
  "schema_version": "prs-implementation/1",
  "prompt": "03-implementation-check/frontend_web@1",
  "catalog_version": 1,
  "component_id": "cmp:web",
  "app_type": "frontend_web",
  "role": "primary",
  "results": [
    {
      "result_id": "RES-01@dep:http:VITE_API_URL",
      "practice_id": "RES-01",
      "category": "resilience",
      "severity": "high",
      "target_id": "dep:http:VITE_API_URL",
      "applicability": "applicable",
      "status": "missing",
      "criteria_met": [],
      "criteria_failed": ["I2"],
      "pitfalls": ["P1"],
      "defaults_applied": [{"library": "axios", "version": "1.7.9", "setting": "timeout", "default": "0 (none)"}],
      "findings": [{"file": "web/src/api/client.ts", "line": 3, "symbol": "api", "snippet": "export const api = axios.create({ baseURL: import.meta.env.VITE_API_URL })", "issue": "P1"}],
      "evidence": [],
      "notes": ""
    }
  ],
  "search_log": [{"pattern": "timeout|AbortSignal", "paths": "web/src", "hits": 0}]
}
```

- One result per work-list item, same `result_id`, same order.
- `criteria_met` + `criteria_failed` list every criterion that applies to the target (omit criteria marked "required when…" when their condition is false).
- `notes`: at most 300 characters; plain facts only.
