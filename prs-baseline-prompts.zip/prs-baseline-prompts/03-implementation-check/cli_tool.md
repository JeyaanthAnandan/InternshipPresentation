---
name: prs-implementation-cli-tool
version: 1
description: PRS step 3 for app type cli_tool. For every applicable or undetermined practice result from step 2, checks the CLI's code and config and decides whether the practice is implemented, using fixed criteria, pitfalls and default tables.
inputs: CODE_ROOT, CONFIG_PATHS (optional), OUT, OVERRIDES (optional), COMPONENT, APP_TYPE=cli_tool, ROLE, PROMPTS
output: OUT/implementation/<component slug>__cli_tool.json
---

# PRS step 3 — Implementation check: CLI tool

## Role

For each practice that step 2 marked `applicable` or `undetermined`, find out whether it is **implemented** in this command-line tool, and record evidence. You read code and config; you never run, build or change anything.

Read first: `PROMPTS/shared/conventions.md`, `PROMPTS/shared/practice-catalog.yaml`, `OUT/facts.json` and `OUT/applicability/<slug>__cli_tool.json`.

## Procedure

1. **Work list:** every result in the applicability file with status `applicable` or `undetermined`, in file order. Do not add or drop results.
2. **Search scope:** the component root, the entry module(s) declared in the manifest (`bin`, `console_scripts`, `[project.scripts]`, `cmd/*/main.go`, `Main`), command definitions, config loaders, `CONFIG_PATHS` and CI files. Apply conventions §9 exclusions. Start from the command units' evidence, then follow each command's handler one or two hops.
3. For each result, evaluate the criteria (`I…`) and pitfalls (`P…`) of its practice section. A criterion is met only with evidence. Use only the defaults written in this prompt; if a library is not covered and nothing is configured explicitly, use `cannot_verify_statically` with `notes` starting `DEFAULT_UNKNOWN:`.
4. Choose the status with the practice's **Status** line, or else this order (first match wins):
   1. any **blocking** pitfall → `missing`
   2. all required criteria met **and** a non-blocking pitfall present → `partially_implemented`
   3. all required criteria met explicitly → `implemented`
   4. all required criteria met, at least one only through a documented default → `implemented_by_default`
   5. all required criteria met, at least one only through platform evidence → `implemented_by_platform`
   6. some required criteria met → `partially_implemented`
   7. the deciding evidence lives outside the repository or needs runtime data → `cannot_verify_statically`
   8. otherwise → `missing`
5. Record the result (format at the end). Put each offending location in `findings` with the pitfall ID (max 20, sorted).
6. Write the output, canonicalize and validate (conventions §12). Test evidence is out of scope.

---

## Performance

### PERF-02 · No per-item calls inside loops (target: component)
Search loops over inputs (lines, files, records, IDs from arguments) whose body issues a query or remote call per item when a batch API exists (bulk endpoints, `IN (...)` queries, batch SDK calls).
- **I1** (required) No such loop found.
- **P1** (non-blocking) Each per-item call (record every one).
- **Status:** 0 findings → `implemented`; 1 or more → `partially_implemented`.

### PERF-05 · Streaming of large inputs and outputs (target: unit `cli_command`)
- **I1** (required) stdin and input files are read incrementally: `for line in sys.stdin`/`for line in f`, `click.File` used as a stream, `bufio.Scanner`/`bufio.Reader`, Node `readline.createInterface` or streams/`pipeline`, `BufferedReader.lines()`, `File.ReadLines`/`StreamReader.ReadLine`.
- **I2** (non-required) `-` is accepted for stdin/stdout.
- **P1** (non-blocking) Whole-input reads: `sys.stdin.read()`, `f.read()`, `json.load` on large inputs, `io.ReadAll(os.Stdin)`, `os.ReadFile`, `fs.readFileSync`, `Files.readAllBytes`/`readAllLines`, `File.ReadAllText`/`ReadAllLines`.

### PERF-14 · Fast startup (target: component)
Read the entry module(s) and the modules they import at top level.
- **I1** (required) No network calls, large file loads or heavy computation at import time, in static initialisers/`init()`, or before argument parsing.
- **I2** (required) Heavy optional dependencies are imported lazily inside the commands that need them (Python: `pandas`, `numpy`, `torch`, `tensorflow`, `boto3`, `matplotlib`, `scipy`, `sklearn` imported inside functions; Node: dynamic `import()` for heavy packages).
- **P1** (non-blocking) Each top-level network call, heavy import or large load in the entry path (list each).
- Always add `notes`: `Startup time needs runtime measurement.` Compiled CLIs (Go, Rust, .NET native AOT, GraalVM native image) with no I/O at init → I2 not applicable; judge on I1 alone.

---

## Resilience

### RES-01 · Timeouts on outbound calls (target: dependency)
- **I1** (required) Connect timeout finite. **I2** (required) Request/read or total timeout finite; for interactive commands, a user-configurable timeout flag or env var is a plus (note it).
- **P1** (blocking) Effective request timeout is none (table). **P2** (non-blocking) Above 120 s without a progress indicator.
- **DB special case:** a `db` dependency missing only I2 is `partially_implemented`.

| Client | Default |
|---|---|
| Python `requests` / `urllib.request.urlopen` | none → P1 |
| Python `httpx` | 5 s → by default |
| `boto3`/botocore | connect 60 s, read 60 s → by default |
| axios | `0` = none → P1 |
| Node.js global `fetch`/undici | headers/body 300 s → by default, P2 |
| ky | 10 s → by default |
| Go `http.Client{}`/`http.Get`/`DefaultClient` | none → P1 |
| Java `java.net.http.HttpClient` | no request timeout unless set → P1 |
| OkHttp | 10 s connect/read/write → by default |
| .NET `HttpClient` | 100 s → by default |
| gRPC | no deadline → P1 |
| other clients | explicit settings only, else `cannot_verify_statically` (`DEFAULT_UNKNOWN`) |

### RES-02 · Safe retries (target: dependency)
- **I0** No retry layer → satisfies the practice.
- **I1–I5** (required if retries exist): bounded attempts; backoff; jitter; transient failures only; one layer only.
- **P1** (blocking) Unbounded retries (tenacity without `stop`, `while True` retry loops).
- **P2** (blocking) Retrying non-idempotent operations without an idempotency key.
- **P3** (non-blocking) Multiple layers. **P4** (non-blocking) No backoff or no jitter.
- Defaults: tenacity retries forever with no wait unless configured; AWS SDKs standard mode 3 attempts with full jitter (one layer); axios-retry 3 retries with no delay.
- **Status:** I0 → `implemented`; else the general order.

### RES-12 · Centralized error handling (target: component)
- **I1** (required) Expected errors are turned into a clear message on stderr and a non-zero exit at one place: click/typer exceptions (`ClickException`, `UsageError`, `typer.Exit`), argparse `parser.error`, cobra `RunE` errors returned to `Execute()` with `os.Exit(1)` on error, commander `program.error()`/`exitOverride`, picocli execution-exception handler, System.CommandLine invocation returning an exit code, a top-level `try/except`/`try/catch` in `main`.
- **I2** (non-required) Full stack traces only with a `--debug`/`--verbose` flag or env var.
- **P1** (non-blocking) Swallowed errors that let the command continue or exit 0 (empty `except`/`catch`, ignored Go `err`), listed each.
- Defaults: click and typer convert their exceptions into messages with exit codes → I1 by default for parser-level errors.

### RES-19 · Meaningful exit codes (target: component)
- **I1** (required) Success exits 0 and every failure path exits non-zero.
- **I2** (required) Distinct codes for distinct failure classes (at least usage errors vs runtime failures), defined as named constants/enums or documented in help text/README.
- **P1** (blocking) Failure paths that exit 0: catch-all handlers followed by a normal return or `sys.exit(0)`; Go `main` that logs an error and returns without `os.Exit(1)`; Node `main().catch(console.error)` without setting `process.exitCode`; a `Main` returning 0 after catching exceptions.
- Defaults: uncaught exceptions exit non-zero in Python (1), Java (1) and .NET; a Go panic exits 2; Node.js ≥ 15 exits 1 on unhandled rejections; argparse and click usage errors exit 2 → I1 by default for those paths only.
- **Status:** I1 and I2 explicit → `implemented`; I1 only via defaults and I2 met → `implemented_by_default`; I1 without I2 → `partially_implemented`; P1 → `missing`.

### RES-20 · Signal handling with bounded cleanup (target: component)
- **I1** (required) SIGINT/SIGTERM are handled so work stops promptly and resources are cleaned up: Python top-level `except KeyboardInterrupt` with cleanup and exit code 130, or `signal.signal(SIGTERM, …)`; Node `process.on("SIGINT"|"SIGTERM", …)`; Go `signal.NotifyContext(ctx, os.Interrupt, syscall.SIGTERM)` with `ctx` passed to the work; Java `Runtime.getRuntime().addShutdownHook(...)`; .NET `Console.CancelKeyPress`/`AppDomain.ProcessExit` or the cancellation token supplied by System.CommandLine.
- **I2** (non-required) Cleanup is bounded (timeout, or a second Ctrl-C forces exit); temp files and partial outputs are removed.
- **P1** (non-blocking) Bare `except:` or `except BaseException:` around work (swallows Ctrl-C); cleanup that can block indefinitely.
- Defaults: Python raises `KeyboardInterrupt` on SIGINT and Node/Go terminate immediately, all without cleanup → `partially_implemented` when nothing is configured.

### RES-21 · Atomic, recoverable file outputs (target: component)
- **I1** (required) Output files are written to a temporary file in the same directory and atomically renamed (`os.replace`, `Files.move(..., ATOMIC_MOVE)`, `os.Rename`, `fs.rename` after the write completes, `File.Replace`/`File.Move` with overwrite).
- **I2** (required) Re-running a command does not duplicate output (overwrite, or explicit `--append`).
- **P1** (non-blocking) Writing directly to the final path (a crash leaves a partial file).
- **P2** (non-blocking) Overwriting existing files without a `--force`/confirmation for destructive operations.

---

## Security

### SEC-01 · Input validation for arguments, flags, env vars, stdin and files (target: unit `cli_command`)
For each input of the command (facts `inputs`):
- **I1** (required) Typed/constrained by the parser or validated before use: argparse `type=`/`choices=`; click types (`Choice`, `IntRange`, `Path(exists=True, dir_okay=False)`, `File`); typer annotations and `Enum`s; cobra `Args` validators plus checks in `PreRunE`/`RunE`; urfave/cli typed flags; picocli typed fields and validation; commander `.choices()`/argument parsers; System.CommandLine validators.
- **I2** (required for env vars and config files) Typed/validated settings (pydantic-settings, envconfig, viper unmarshal into structs with validation, `IOptions` validation).
- **I3** (required for stdin/input files) Content validated (schema/format checks) before use.
- **P1** (non-blocking) Untyped string inputs used without checks.
- **Status:** all inputs → `implemented`; some → `partially_implemented`; none → `missing`. List uncovered inputs in `findings`.

### SEC-04 · Safe file-system access (target: component)
- **I1** (required) User-supplied paths are normalised and, where the tool writes or deletes, confined to the intended directory or confirmed by the user; symlinks are not followed blindly when deleting/overwriting.
- **I2** (required) Temp files created securely (`tempfile.mkstemp`/`NamedTemporaryFile`/`TemporaryDirectory`, `Files.createTempFile`, `os.CreateTemp`).
- **I3** (non-required) Files holding secrets or tokens are written with owner-only permissions (`0o600`).
- **P1** (blocking) User/remote-derived paths reaching delete/overwrite APIs with no confinement or confirmation; archive extraction without checking entry paths (zip slip: `extractall` on untrusted archives, `ZipEntry.getName()` joined without checks).
- **P2** (blocking) `tempfile.mktemp(`, `os.tempnam(`.
- **P3** (non-blocking) World-writable permissions.

### SEC-05 · Injection-safe data access (target: component)
- **I1** (required) Every raw query uses bind parameters. **I2** (required) Dynamic identifiers come from an allowlist.
- **P1** (blocking) Query text built from arguments/env/stdin by concatenation, interpolation or formatting.
- Defaults: ORM-only access → `implemented_by_default`.

### SEC-06 · Safe command and code execution (target: component)
- **I1** (required) Sub-processes run without a shell, with argument lists, and user values are allowlisted or placed after `--` (prevents option injection such as a value starting with `-`).
- **I2** (required) No `eval`/`exec`/dynamic code or templates compiled from user input.
- **P1** (blocking) `shell=True`, `os.system(`, `sh -c`, `child_process.exec(` with interpolation, `Runtime.exec(String)` with concatenation, where `input_derived` is true or `"unknown"`.
- **P2** (blocking) `eval`/`exec`/`new Function` on user input.

### SEC-07 · Safe deserialization and XML parsing (target: component)
- **I1** (required) Config and input files are parsed with data-only loaders (`yaml.safe_load`, SnakeYAML ≥ 2.0 defaults, js-yaml ≥ 4 `load`, JSON, TOML).
- **I2** (required) XML parsers have DTDs/external entities disabled (`defusedxml`; hardened Java factories; .NET Core and Go defaults are safe).
- **P1** (blocking) `pickle`/`marshal`/`shelve`/`dill`/`jsonpickle` on user-supplied files; `yaml.load(..., Loader=yaml.Loader|UnsafeLoader)`/`yaml.unsafe_load`; Java `ObjectInputStream` without a filter; .NET `BinaryFormatter`.
- **P2** (non-blocking) Python stdlib XML parsers on user files.

### SEC-20 · No hard-coded secrets (target: component)
Search code, default config files and `.env*` (except examples) for: private keys `-----BEGIN [A-Z ]*PRIVATE KEY-----`; `AKIA[0-9A-Z]{16}`; `gh[pousr]_[A-Za-z0-9]{36,}`; `xox[abprs]-`; `AIza[0-9A-Za-z_-]{35}`; `sk_live_`; `://[^/:@\s]+:[^/@\s]+@`; `(password|passwd|pwd|secret|token|api[_-]?key|client[_-]?secret|access[_-]?key)\s*[:=]\s*["'][^"'${}<>]{8,}["']`. Ignore placeholders and references.
- **I1** (required) No hard-coded secret found.
- **I2** (non-required) Credentials come from env vars, OS keychains (`keyring`, `go-keyring`), credential files with owner-only permissions, or interactive prompts.
- **P1** (blocking) A real-looking secret (location and kind only; value `<redacted>`).

### SEC-21 · No sensitive data in logs or terminal output (target: component)
- **I1** (required) Secrets and tokens are never printed or logged, including in `--verbose`/`--debug` modes and HTTP debug output.
- **P1** (blocking) Printing/logging passwords, tokens, API keys, `Authorization` headers or credential-bearing URLs.
- **P2** (non-blocking) Secrets accepted only as command-line flags (`--password`, `--token`, `--secret`, `--api-key`; visible in process lists and shell history) without an env var, file or prompt alternative; interactive secret prompts that echo input (use `getpass`, `click.prompt(hide_input=True)`, `term.ReadPassword`).
- **P3** (non-blocking) Dumping whole request/response bodies in debug output without redaction.

### SEC-22 · Secure transport (target: component)
- **I1** (required) TLS verification never disabled by default. An explicit opt-in flag (for example `--insecure`) that prints a warning is acceptable; note it.
- **I2** (required) Default endpoints use `https://`/TLS.
- **P1** (blocking) Verification disabled unconditionally (`verify=False`, `rejectUnauthorized: false`, `InsecureSkipVerify: true`, trust-all `TrustManager`, `CERT_NONE`), or forced TLS < 1.2.
- **P2** (non-blocking) `http://` default endpoints for non-local hosts.

### SEC-24 · Dependency vulnerability management (target: component)
- **I1** (required) Locked dependency versions (lockfiles; `go.sum`; exact/BOM-managed versions).
- **I2** (required) Automated vulnerability scanning in CI (pip-audit, govulncheck, `npm audit`, OSV-Scanner, Trivy, Snyk, OWASP Dependency-Check, `dotnet list package --vulnerable`, `dependency-review-action`), or Dependabot/Renovate security updates.
- **Platform:** `OVERRIDES.platform.dependency_scanning_external: true` → I2 as platform evidence.

---

## Output format

`OUT/implementation/<slug>__cli_tool.json` (schema: `PROMPTS/schemas/implementation.schema.json`):

```json
{
  "schema_version": "prs-implementation/1",
  "prompt": "03-implementation-check/cli_tool@1",
  "catalog_version": 1,
  "component_id": "cmp:tools/acmectl",
  "app_type": "cli_tool",
  "role": "primary",
  "results": [
    {
      "result_id": "RES-19@cmp:tools/acmectl",
      "practice_id": "RES-19",
      "category": "resilience",
      "severity": "medium",
      "target_id": "cmp:tools/acmectl",
      "applicability": "applicable",
      "status": "partially_implemented",
      "criteria_met": ["I1"],
      "criteria_failed": ["I2"],
      "pitfalls": [],
      "defaults_applied": [{"library": "click", "version": "8.1.7", "setting": "usage error exit code", "default": "2"}],
      "findings": [],
      "evidence": [{"file": "tools/acmectl/acmectl/main.py", "line": 88, "symbol": "cli", "snippet": "sys.exit(1)"}],
      "notes": "Only exit codes 0, 1 and 2 are used; no distinct code for network failures."
    }
  ],
  "search_log": [{"pattern": "sys\\.exit\\(|raise SystemExit", "paths": "tools/acmectl", "hits": 4}]
}
```

- One result per work-list item, same `result_id`, same order.
- `criteria_met` + `criteria_failed` list every criterion that applies to the target.
- `notes`: at most 300 characters; plain facts only.
