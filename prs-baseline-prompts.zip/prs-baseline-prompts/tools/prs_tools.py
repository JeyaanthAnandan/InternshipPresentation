#!/usr/bin/env python3
"""PRS pipeline helper: canonicalize, validate, compare and summarize outputs.

Usage
  python prs_tools.py canonicalize <file.json> [...]
  python prs_tools.py validate <OUT dir>
  python prs_tools.py compare <OUT dir A> <OUT dir B>
  python prs_tools.py summarize <OUT dir> [--write]

Needs Python 3.9+ and PyYAML. jsonschema is optional (schema checks are
skipped with a warning when it is missing):  pip install pyyaml jsonschema
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CATALOG = ROOT / "shared" / "practice-catalog.yaml"
SCHEMAS = ROOT / "schemas"
APP_TYPES = ["backend_service", "frontend_web", "batch_job", "cli_tool"]
PRIORITY = ["backend_service", "frontend_web", "batch_job", "cli_tool", "library"]
NETWORK = {"http", "grpc", "graphql", "db", "cache", "broker_publish", "smtp", "ldap", "cloud_sdk", "other"}


# ───────────────────────── helpers ─────────────────────────
def load_json(path: Path):
    with path.open(encoding="utf-8") as f:
        return json.load(f)


def dump_json(path: Path, data) -> None:
    text = json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True)
    path.write_text(text + "\n", encoding="utf-8")


def load_catalog():
    try:
        import yaml  # type: ignore
    except ImportError:
        sys.exit("PyYAML is required: pip install pyyaml")
    with CATALOG.open(encoding="utf-8") as f:
        data = yaml.safe_load(f)
    practices = [p for p in data["practices"] if not p.get("retired")]
    return {p["id"]: p for p in practices}, [p["id"] for p in practices]


def ev_key(e):
    return (str(e.get("file", "")), int(e.get("line", 0) or 0), str(e.get("snippet", "")))


# ───────────────────────── canonicalize ─────────────────────────
def canonicalize_obj(obj, parent_key: str = ""):
    if isinstance(obj, dict):
        return {k: canonicalize_obj(v, k) for k, v in obj.items()}
    if isinstance(obj, list):
        items = [canonicalize_obj(v, parent_key) for v in obj]
        if not items or not all(isinstance(i, dict) for i in items):
            return items
        if parent_key in ("evidence", "call_sites"):
            return sorted(items, key=ev_key)
        if parent_key == "findings":
            return sorted(items, key=lambda e: ev_key(e) + (e.get("issue", ""),))
        if parent_key == "results":
            return sorted(items, key=lambda r: (r.get("practice_id", ""), r.get("target_id", "")))
        if parent_key == "component_facts":
            return sorted(items, key=lambda r: (r.get("component_id", ""), r.get("key", "")))
        if parent_key == "routing":
            return sorted(items, key=lambda r: (r.get("component_id", ""), r.get("role") != "primary", r.get("app_type", "")))
        if parent_key == "unresolved":
            return sorted(items, key=lambda r: (r.get("where", ""), r.get("what", "")))
        if parent_key in ("discovery_log", "search_log"):
            return items  # logs keep their order
        if all("id" in i for i in items):
            return sorted(items, key=lambda r: r["id"])
        return items
    return obj


def cmd_canonicalize(files):
    for name in files:
        p = Path(name)
        dump_json(p, canonicalize_obj(load_json(p)))
        print(f"canonicalized {p}")


# ───────────────────────── validate ─────────────────────────
class Report:
    def __init__(self):
        self.errors, self.warnings = [], []

    def err(self, where, msg):
        self.errors.append(f"ERROR {where}: {msg}")

    def warn(self, where, msg):
        self.warnings.append(f"WARN  {where}: {msg}")


def schema_check(rep: Report, data, schema_name: str, where: str):
    try:
        import jsonschema  # type: ignore
    except ImportError:
        rep.warn(where, "jsonschema not installed; schema checks skipped (pip install jsonschema)")
        return
    schema = load_json(SCHEMAS / schema_name)
    validator = jsonschema.Draft202012Validator(schema)
    for e in sorted(validator.iter_errors(data), key=lambda e: list(e.path)):
        loc = "/".join(str(p) for p in e.path) or "<root>"
        rep.err(where, f"schema: {loc}: {e.message}")


def expected_practices(cat, order, app_type, role, primary):
    out = []
    for pid in order:
        p = cat[pid]
        if app_type not in p["app_types"]:
            continue
        if role == "secondary" and not (p["scope"] == "unit" or primary not in p["app_types"]):
            continue
        out.append(pid)
    return out


def validate_facts(rep, facts):
    where = "facts.json"
    schema_check(rep, facts, "facts.schema.json", where)
    comps = {c["id"]: c for c in facts.get("components", [])}
    for section in ("components", "units", "dependencies", "data_access", "sinks", "deployments"):
        ids = [x.get("id") for x in facts.get(section, [])]
        if len(ids) != len(set(ids)):
            rep.err(where, f"duplicate ids in {section}")
        if ids != sorted(ids):
            rep.warn(where, f"{section} not sorted by id (run canonicalize)")
    for c in comps.values():
        types = [t for t in PRIORITY if t in c.get("app_types", [])]
        if types and c.get("primary_app_type") != types[0]:
            rep.err(where, f"{c['id']}: primary_app_type should be {types[0]} (priority rule)")
    for u in facts.get("units", []):
        c = comps.get(u.get("component_id"))
        if not c:
            rep.err(where, f"unit {u.get('id')}: unknown component {u.get('component_id')}")
        elif u.get("app_type") not in c.get("app_types", []):
            rep.err(where, f"unit {u['id']}: app_type {u.get('app_type')} not in component app_types")
    for section in ("dependencies", "data_access", "sinks", "component_facts"):
        for x in facts.get(section, []):
            if x.get("component_id") not in comps:
                rep.err(where, f"{section} {x.get('id', x.get('key'))}: unknown component {x.get('component_id')}")
    jobs = {(r["component_id"], r["app_type"]) for r in facts.get("routing", [])}
    for c in comps.values():
        for t in c.get("app_types", []):
            if (c["id"], t) not in jobs:
                rep.err(where, f"routing is missing job ({c['id']}, {t})")
    for r in facts.get("routing", []):
        c = comps.get(r["component_id"])
        if c is None:
            rep.err(where, f"routing job for unknown component {r['component_id']}")
            continue
        want_role = "primary" if r["app_type"] == c.get("primary_app_type") else "secondary"
        if r.get("role") != want_role:
            rep.err(where, f"routing ({r['component_id']}, {r['app_type']}): role should be {want_role}")
        if (r["app_type"] == "library") != bool(r.get("skipped")):
            rep.err(where, f"routing ({r['component_id']}, {r['app_type']}): only library jobs are skipped")
    return comps


def target_exists(facts, comp_id, app_type, scope, target):
    if target == comp_id:
        return True
    if scope == "unit":
        return any(u["id"] == target and u["component_id"] == comp_id and u["app_type"] == app_type for u in facts["units"])
    if scope == "dependency":
        return any(d["id"] == target and d["component_id"] == comp_id for d in facts["dependencies"])
    if scope == "deployment":
        return any(d["id"] == target and d["component_id"] == comp_id for d in facts["deployments"])
    return False


def validate_applicability(rep, facts, comps, cat, order, path):
    where = f"applicability/{path.name}"
    data = load_json(path)
    schema_check(rep, data, "applicability.schema.json", where)
    comp = comps.get(data.get("component_id"))
    if comp is None:
        rep.err(where, f"unknown component {data.get('component_id')}")
        return data
    app_type, role = data.get("app_type"), data.get("role")
    job = next((r for r in facts["routing"] if r["component_id"] == comp["id"] and r["app_type"] == app_type), None)
    if job is None:
        rep.err(where, "no routing job for this component/app type")
    elif job.get("role") != role:
        rep.err(where, f"role {role} does not match routing ({job.get('role')})")
    expected = expected_practices(cat, order, app_type, role, comp.get("primary_app_type"))
    seen, ids, sort_keys = set(), set(), []
    for r in data.get("results", []):
        pid, rid = r.get("practice_id"), r.get("result_id")
        p = cat.get(pid)
        if p is None:
            rep.err(where, f"{rid}: unknown practice {pid}")
            continue
        if pid not in expected:
            rep.err(where, f"{rid}: practice {pid} is not evaluated by a {role} {app_type} job")
        if rid != f"{pid}@{r.get('target_id')}":
            rep.err(where, f"{rid}: result_id must be <practice_id>@<target_id>")
        if rid in ids:
            rep.err(where, f"{rid}: duplicate result")
        ids.add(rid)
        for field in ("category", "scope", "severity"):
            if r.get(field) != p[field]:
                rep.err(where, f"{rid}: {field} must be {p[field]} (catalog)")
        if r.get("reason") == "NO_TARGETS":
            if r.get("target_id") != comp["id"] or r.get("rule") != "N0":
                rep.err(where, f"{rid}: NO_TARGETS results use the component as target and rule N0")
        elif not target_exists(facts, comp["id"], app_type, p["scope"], r.get("target_id")):
            rep.err(where, f"{rid}: target {r.get('target_id')} not found in facts for scope {p['scope']}")
        seen.add(pid)
        sort_keys.append((order.index(pid), r.get("target_id", "")))
    for pid in expected:
        if pid not in seen:
            rep.err(where, f"missing practice {pid} (every expected practice needs at least one result)")
    if sort_keys != sorted(sort_keys):
        rep.warn(where, "results not in catalog/target order (run canonicalize)")
    return data


def validate_implementation(rep, cat, appl, path):
    where = f"implementation/{path.name}"
    data = load_json(path)
    schema_check(rep, data, "implementation.schema.json", where)
    if appl is None:
        rep.err(where, "no matching applicability file")
        return
    work = [r for r in appl["results"] if r["status"] in ("applicable", "undetermined")]
    want = [r["result_id"] for r in work]
    got = [r.get("result_id") for r in data.get("results", [])]
    if sorted(got) != sorted(want):
        missing, extra = sorted(set(want) - set(got)), sorted(set(got) - set(want))
        if missing:
            rep.err(where, f"missing results: {missing}")
        if extra:
            rep.err(where, f"unexpected results: {extra}")
    elif got != want:
        rep.warn(where, "results not in applicability order (run canonicalize on both)")
    by_id = {r["result_id"]: r for r in work}
    for r in data.get("results", []):
        a = by_id.get(r.get("result_id"))
        p = cat.get(r.get("practice_id"))
        if a and r.get("applicability") != a["status"]:
            rep.err(where, f"{r['result_id']}: applicability must be {a['status']}")
        if p and (r.get("severity") != p["severity"] or r.get("category") != p["category"]):
            rep.err(where, f"{r['result_id']}: severity/category must match the catalog")
        if r.get("status") == "missing" and not (r.get("pitfalls") or r.get("criteria_failed")):
            rep.err(where, f"{r['result_id']}: status missing needs a failed criterion or a pitfall")
        if r.get("status") in ("implemented", "implemented_by_default", "implemented_by_platform") and r.get("criteria_failed"):
            rep.warn(where, f"{r['result_id']}: implemented status with failed criteria; check optional criteria")


def cmd_validate(out_dir):
    out = Path(out_dir)
    rep = Report()
    cat, order = load_catalog()
    facts_path = out / "facts.json"
    if not facts_path.exists():
        sys.exit(f"{facts_path} not found")
    facts = load_json(facts_path)
    comps = validate_facts(rep, facts)
    appl_by_name, seen_results = {}, {}
    for p in sorted((out / "applicability").glob("*.json")):
        data = validate_applicability(rep, facts, comps, cat, order, p)
        appl_by_name[p.name] = data
        for r in data.get("results", []):
            key = (data.get("component_id"), r.get("result_id"))
            if r.get("reason") != "NO_TARGETS" and key in seen_results:
                rep.err(f"applicability/{p.name}", f"{r.get('result_id')} also evaluated in {seen_results[key]} (ownership rule)")
            seen_results.setdefault(key, p.name)
    for p in sorted((out / "implementation").glob("*.json")):
        validate_implementation(rep, cat, appl_by_name.get(p.name), p)
    for line in rep.warnings + rep.errors:
        print(line)
    print(f"validate: {len(rep.errors)} error(s), {len(rep.warnings)} warning(s)")
    sys.exit(1 if rep.errors else 0)


# ───────────────────────── compare ─────────────────────────
def collect(out: Path):
    facts = load_json(out / "facts.json")
    inv = {s: {x["id"] for x in facts.get(s, [])} for s in ("components", "units", "dependencies", "data_access", "sinks", "deployments")}
    appl, impl = {}, {}
    for p in (out / "applicability").glob("*.json"):
        for r in load_json(p).get("results", []):
            appl[r["result_id"]] = r["status"]
    for p in (out / "implementation").glob("*.json"):
        for r in load_json(p).get("results", []):
            impl[r["result_id"]] = (r["status"], tuple(sorted(r["criteria_met"])), tuple(sorted(r["pitfalls"])))
    return inv, appl, impl


def jaccard(a, b):
    return 1.0 if not a and not b else len(a & b) / len(a | b)


def agreement(a: dict, b: dict, label: str):
    keys = sorted(set(a) | set(b))
    same = [k for k in keys if a.get(k) == b.get(k)]
    pct = 100.0 * len(same) / len(keys) if keys else 100.0
    print(f"{label}: {len(same)}/{len(keys)} identical ({pct:.1f}%)")
    for k in keys:
        if a.get(k) != b.get(k):
            print(f"  ≠ {k}: {a.get(k)}  vs  {b.get(k)}")
    return pct


def cmd_compare(dir_a, dir_b):
    inv_a, appl_a, impl_a = collect(Path(dir_a))
    inv_b, appl_b, impl_b = collect(Path(dir_b))
    print("Inventory (Jaccard similarity of ID sets):")
    for s in inv_a:
        j = jaccard(inv_a[s], inv_b[s])
        print(f"  {s:13s} {j:.3f}  ({len(inv_a[s])} vs {len(inv_b[s])})")
        for x in sorted(inv_a[s] ^ inv_b[s]):
            print(f"    only in {'A' if x in inv_a[s] else 'B'}: {x}")
    agreement(appl_a, appl_b, "Applicability status")
    agreement({k: v[0] for k, v in impl_a.items()}, {k: v[0] for k, v in impl_b.items()}, "Implementation status")
    agreement(impl_a, impl_b, "Implementation status+criteria+pitfalls")


# ───────────────────────── summarize ─────────────────────────
def cmd_summarize(out_dir, write=False):
    out = Path(out_dir)
    cat, order = load_catalog()
    lines = ["# PRS baseline summary", ""]
    for p in sorted((out / "implementation").glob("*.json")):
        data = load_json(p)
        appl_path = out / "applicability" / p.name
        appl = load_json(appl_path).get("results", []) if appl_path.exists() else []
        lines += [f"## {data['component_id']} · {data['app_type']} ({data['role']})", "",
                  "| Practice | Target | Severity | Applicability | Implementation | Pitfalls |",
                  "|---|---|---|---|---|---|"]
        counts = {}
        for r in sorted(data["results"], key=lambda r: (order.index(r["practice_id"]), r["target_id"])):
            name = cat[r["practice_id"]]["name"]
            counts[r["status"]] = counts.get(r["status"], 0) + 1
            target = r["target_id"].replace("|", "\\|")
            lines.append(f"| {r['practice_id']} {name} | `{target}` | {r['severity']} | {r['applicability']} | "
                         f"{r['status']} | {', '.join(r['pitfalls']) or '—'} |")
        na = [r for r in appl if r["status"] == "not_applicable"]
        lines += ["", "Totals: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())) + f"; not applicable {len(na)}", ""]
    text = "\n".join(lines)
    if write:
        (out / "summary.md").write_text(text + "\n", encoding="utf-8")
        print(f"wrote {out / 'summary.md'}")
    else:
        print(text)


def main(argv):
    if len(argv) < 2:
        sys.exit(__doc__)
    cmd, args = argv[1], argv[2:]
    if cmd == "canonicalize" and args:
        cmd_canonicalize(args)
    elif cmd == "validate" and len(args) == 1:
        cmd_validate(args[0])
    elif cmd == "compare" and len(args) == 2:
        cmd_compare(*args)
    elif cmd == "summarize" and args:
        cmd_summarize(args[0], write="--write" in args)
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main(sys.argv)
