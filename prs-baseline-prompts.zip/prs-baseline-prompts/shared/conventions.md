---
name: prs-conventions
version: 1
description: Rules that every PRS (performance, resilience, security) session must follow. Read this before any prompt in 01-, 02- or 03-.
---

# PRS analysis — shared conventions (v1)

Every session in this pipeline (fact discovery, applicability, implementation check) follows these rules. If a step prompt seems to conflict with this file, this file wins.

The pipeline:

```
01 fact discovery      → out/facts.json                                   (one session per repo)
02 applicability       → out/applicability/<component-slug>__<app_type>.json   (one session per job)
03 implementation      → out/implementation/<component-slug>__<app_type>.json (one session per job)
```

Each step reads only files written by earlier steps plus the repository. No step relies on chat history from an earlier session.

## 1. Golden rules

1. **Read-only.** Never modify, build, install, run or test the repository. Never call the network. Only read files and run read-only search commands (`rg`, `grep`, `find`, `ls`, `cat`, `head`, `sed -n`).
2. **No invention.** Every fact, target and verdict must point to evidence in the repository, the config paths or the overrides file. If you cannot point to evidence, use the "unknown" form the schema provides (`"unknown"`, `undetermined`, `cannot_verify_statically`). Never guess to fill a gap.
3. **Closed vocabularies.** Use only the IDs, statuses, reason codes, rule IDs, criteria IDs and fact keys defined in these prompts and in `shared/practice-catalog.yaml`. Do not add practices, rename IDs or create new status values.
4. **First match wins.** Where a prompt gives numbered rules, evaluate them in the order listed and stop at the first rule that matches. Record that rule's ID.
5. **Same input, same output.** Process files, targets and practices in the orders defined in section 10. Do not sample, skip ahead or "spot check". If the job is too large to finish, stop and record the remaining work in `unresolved` rather than silently covering part of it.
6. **JSON is the deliverable.** Write the output file exactly in the documented format. No prose outside the JSON file, except a final one-line status message.
7. **Never copy secret values.** If you find a credential, record its location and kind, and replace the value with `"<redacted>"`.

## 2. Inputs and paths

- `CODE_ROOT`: the code repository root. All `file` paths in outputs are relative to it, POSIX style (`src/main/App.java`), never absolute.
- `CONFIG_PATHS`: optional extra config locations (outside or inside the repo). Paths outside `CODE_ROOT` are written as `config:<n>/<relative path>`, where `<n>` is the index of the config path as given.
- `OVERRIDES`: optional YAML file of human-supplied knowledge (see `shared/overrides.example.yaml`). Its content counts as evidence, cited as `{"file": "overrides", "key": "<dotted.key>"}`.
- `OUT`: output directory (default `prs-out/` next to the repo, never inside `CODE_ROOT`).

## 3. App types

Exactly five app types exist. Use these exact strings.

| app_type | Definition (any one signal is enough) |
|---|---|
| `backend_service` | A long-running process that serves network requests or consumes messages: HTTP/gRPC/GraphQL/WebSocket servers, message or queue workers, background-service hosts. |
| `frontend_web` | Code that is built into assets that run in a browser: React, Angular, Vue, Svelte, Solid and similar apps, or meta-frameworks such as Next.js, Nuxt, SvelteKit and Remix. |
| `batch_job` | Run-to-completion or scheduled work: Spring Batch, Airflow/Dagster/Prefect DAGs, Kubernetes Job/CronJob, `@Scheduled` or cron-style tasks, Celery beat, Quartz, Hangfire recurring jobs, standalone ETL scripts that a scheduler runs. |
| `cli_tool` | A command-line program for humans or scripts: declared console entry points (`bin`, `console_scripts`, `[project.scripts]`, Go `cmd/*` mains) or an argument-parser library defining commands. |
| `library` | None of the above: code consumed by other code only. **No PRS prompts run for libraries**; they are listed in routing with `"skipped": true`. |

A component can have several app types (for example a Spring Boot service with `@Scheduled` tasks is `backend_service` + `batch_job`; a Next.js app with API routes is `frontend_web` + `backend_service`).

**Primary app type** is chosen by this fixed priority, first match wins: `backend_service` > `frontend_web` > `batch_job` > `cli_tool` > `library`.

## 4. Ownership rule (who evaluates what)

One routing job exists per (component, app_type). To avoid evaluating the same thing twice:

- **Primary job** (component's primary app type): evaluates every practice listed for that app type in the catalog, for all scopes.
- **Secondary job** (any other app type of the component): evaluates
  - practices with `scope: unit`, only for units whose `app_type` is this job's app type, and
  - practices of any scope that are listed for this app type but **not** for the primary app type.

Each unit has exactly one `app_type`. Dependencies, deployments and the component itself belong to the primary job, except as stated above.

## 5. Identifiers

IDs are built from meaning, never from line numbers or ordinals of discovery. Lower-case the parts noted; keep the rest as written in code.

| Entity | ID format | Example |
|---|---|---|
| Component | `cmp:<root path relative to CODE_ROOT>` (`cmp:.` for the repo root) | `cmp:services/orders` |
| Component slug (file names) | root path with `/` replaced by `_`, `.` for root becomes `root` | `services_orders` |
| HTTP endpoint | `http:<METHOD> <full path template>`; path params written `{}`; include mount prefixes and context paths | `http:GET /api/orders/{}` |
| gRPC method | `grpc:<package.Service>/<Method>` | `grpc:shop.v1.Orders/Create` |
| GraphQL operation | `gql:<Query\|Mutation\|Subscription>.<field>` | `gql:Mutation.createOrder` |
| WebSocket | `ws:<path>` | `ws:/live` |
| Message consumer | `msg:<broker>:<destination>` (broker in `kafka`, `rabbitmq`, `sqs`, `sns`, `pubsub`, `servicebus`, `jms`, `redis`, `celery`, `nats`, `other`) | `msg:kafka:orders.created` |
| UI route | `ui:<route path>`; params as `{}` | `ui:/orders/{}` |
| UI form | `uiform:<route path>#<form name or component name>` | `uiform:/checkout#PaymentForm` |
| Batch job | `job:<job or DAG name>` | `job:nightly-settlement` |
| Batch step / task | `step:<job name>/<step or task name>` | `step:nightly-settlement/load` |
| Scheduled task | `sched:<fully qualified symbol>` | `sched:com.acme.Cleanup.purge` |
| CLI command | `cli:<program> <subcommand path>` (root command is `cli:<program>`) | `cli:acme deploy rollback` |
| Unit input | `<unit id>~in:<location>:<name>` | `http:POST /api/orders~in:body:OrderRequest` |
| Dependency | `dep:<protocol>:<logical name>` — logical name is the config key, service/host name or client bean name, in that order of preference; if none is knowable, `<client library>@<file>` | `dep:http:payment-service` |
| Deployment | `deploy:<file>#<Kind>/<name>` | `deploy:k8s/orders.yaml#Deployment/orders` |
| Result | `<practice_id>@<target id>` | `RES-01@dep:http:payment-service` |

If two different things would get the same ID, append `#2`, `#3` in sorted order of their file path, and record both in `unresolved` with reason `ID_COLLISION`.

## 6. Scopes

Each practice has one scope (see the catalog). The scope decides which targets get a result.

| Scope | Targets | When there are no targets |
|---|---|---|
| `component` | the component itself (one result) | — |
| `unit` | units of this job's app type that match the practice's **Targets** line (kind plus attribute filter) | one result with `target_id` = component ID, `status: not_applicable`, `reason: NO_TARGETS`, `rule: N0` |
| `dependency` | entries in `dependencies` of the component that match the practice's **Targets** line (protocol plus filter) | same as above |
| `deployment` | entries in `deployments` of the component that match the practice's **Targets** line (kind) | same as above |

Things that do not match a practice's Targets line get **no** result for that practice (for example, only login endpoints are targets of the brute-force practice). A filter that says "true or unknown" includes `"unknown"` values, so missing facts surface as `undetermined` instead of disappearing. An attribute that the unit's kind does not define (for example `accepts_files` on a `message_consumer`) does not match a filter.

## 7. Evidence

Evidence is a list of objects:

```json
{"file": "src/main/java/com/acme/PaymentClient.java", "line": 42, "symbol": "PaymentClient.charge", "snippet": "return restClient.post().uri(\"/charge\")..."}
```

- `file` is required; `line` is the 1-based line of the most specific match; `symbol` is the enclosing class/function if known, else `""`.
- `snippet` is one line, max 160 characters, trimmed, secrets redacted.
- Overrides evidence: `{"file": "overrides", "key": "public_units"}`.
- Absence evidence (proving something is *not* there): `{"file": "*", "search": "<pattern>", "scope": "<paths searched>", "hits": 0}`.
- Give at most 5 evidence items per record, choosing the first ones in sorted file/line order.

## 8. Status vocabularies

**Applicability** (`02-*`):

| status | meaning | allowed `reason` |
|---|---|---|
| `applicable` | The practice must be in place for this target. | `FACT_MATCH`, `OVERRIDE` |
| `not_applicable` | Positive evidence that it does not apply. | `NO_TARGETS`, `FACT_EXCLUDES`, `OVERRIDE` |
| `undetermined` | The facts needed to decide are missing or conflict. Never silently treat this as not applicable. | `MISSING_FACT`, `CONFLICTING_FACTS`, `UNRESOLVED_TARGET` |

**Implementation** (`03-*`), evaluated only for `applicable` and `undetermined` results:

| status | meaning |
|---|---|
| `implemented` | All required criteria are met in code/config, and no blocking pitfall was found. |
| `implemented_by_default` | No explicit config exists, but the framework/library default at the resolved version satisfies the practice (cite the default). |
| `implemented_by_platform` | Satisfied outside the app code: manifests in the repo (mesh, ingress, gateway) or an `OVERRIDES` platform key. |
| `partially_implemented` | Some required criteria are met, or a non-blocking pitfall is present. |
| `missing` | Required criteria are not met, or a blocking pitfall is present. |
| `cannot_verify_statically` | The answer needs runtime data or information the repository does not contain. |

## 9. Search procedure (fact discovery and implementation check)

- Exclude these paths everywhere unless the prompt says otherwise: `.git/`, `node_modules/`, `vendor/`, `third_party/`, `dist/`, `build/`, `out/`, `target/`, `bin/`, `obj/`, `.next/`, `.nuxt/`, `coverage/`, `__pycache__/`, `.venv/`, `venv/`, `*.min.js`, `*.map`, `*.lock` (read lockfiles explicitly when resolving versions), files whose first 40 lines contain `Code generated` / `@generated` / `<auto-generated`, and anything matched by `OVERRIDES.excluded_paths`.
- Test code is excluded from PRS analysis (it is handled by a later test-evidence step): `**/test/**`, `**/tests/**`, `**/__tests__/**`, `**/*.test.*`, `**/*.spec.*`, `**/*_test.go`, `**/*Test.java`, `**/*Tests.cs`, `**/test_*.py`, `**/*_test.py`, `**/e2e/**`, `**/cypress/**`, `**/playwright/**`.
- Prefer `rg -n --no-heading --sort path` so results come back in sorted path order. If `rg` is not available, use `grep -rn` and sort the output.
- Record every search in `discovery_log` (fact discovery) or `search_log` (implementation): pattern, paths, and hit count.

## 10. Ordering

- Practices: in catalog order (the order of `shared/practice-catalog.yaml`).
- Targets within a practice: sorted by target ID (byte order).
- Arrays of facts (`components`, `units`, `dependencies`, `deployments`, `sinks`, `data_access`, `component_facts`): sorted by `id` (or by `component_id` then `key` for `component_facts`).
- Evidence: sorted by `file`, then `line`.

Run `python tools/prs_tools.py canonicalize <file>` after writing, if the tool is available; it sorts keys and arrays so outputs can be diffed.

## 11. Overrides

`OVERRIDES` carries knowledge the code cannot show (intentionally public endpoints, target ASVS level, latency targets, platform controls). Rules that cite overrides say so explicitly. An override never invents a target; it only changes how an existing target is judged.

## 12. Finishing a session

1. Write the output file.
2. If available, run `python tools/prs_tools.py validate <OUT>` and fix every error it reports. Do not change verdicts to satisfy the validator; fix format and completeness only.
3. End with one line: `DONE <output path> results=<n> undetermined=<n> unresolved=<n>`.
