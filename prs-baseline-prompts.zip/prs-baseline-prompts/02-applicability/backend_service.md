---
name: prs-applicability-backend-service
version: 1
description: PRS step 2 for app type backend_service (HTTP/gRPC/GraphQL/WebSocket servers and message workers). Decides, for every catalog practice and target, whether the practice applies. Pure function of facts.json and overrides.
inputs: CODE_ROOT, OUT, OVERRIDES (optional), COMPONENT, APP_TYPE=backend_service, ROLE (primary|secondary), PROMPTS
output: OUT/applicability/<component slug>__backend_service.json
---

# PRS step 2 — Applicability: backend service

## Role

You decide **which practices apply** to one component's backend-service surface. You do not decide whether they are implemented.

**Use only `OUT/facts.json` and `OVERRIDES`.** Do not open or search the repository in this session. If a rule needs a fact that is `"unknown"` or absent, follow the rule table (usually `undetermined`). This keeps applicability a pure function of the facts, so repeated runs agree.

Read first: `PROMPTS/shared/conventions.md` and `PROMPTS/shared/practice-catalog.yaml`.

## Procedure

1. Load `OUT/facts.json`. Select the component `COMPONENT`. Let **U** be its units with `app_type == "backend_service"`, **D** its dependencies, **P** its deployments, **F** its `component_facts` (as key → value), **S** its sinks, **Q** its data-access sites.
2. Select practices: the catalog entries whose `app_types` include `backend_service`. If `ROLE == secondary`, apply the ownership rule (conventions §4): keep `scope: unit` practices, plus practices whose `app_types` do not include the component's `primary_app_type`.
3. For each selected practice in catalog order:
   1. Build its targets from its **Targets** line below. If there are none, write one `N0` result (conventions §6).
   2. For each target in sorted ID order, evaluate the rule table top to bottom; the **first** matching row decides `status`, `reason` and `rule`.
   3. Record `facts_used` (the facts you compared, written as `path=value`, such as `F.identity.has_end_users=true` or `units[http:GET /api/orders/{}].attributes.returns_collection=true`) and copy up to 5 evidence items from the facts you used.
4. Write the output (format at the end), canonicalize and validate (conventions §12).
5. Hand off: start a **new** session with
   ```
   Read PROMPTS/shared/conventions.md, then follow PROMPTS/03-implementation-check/backend_service.md.
   CODE_ROOT=<path> CONFIG_PATHS=<paths or none> OVERRIDES=<path or none> OUT=<path>
   COMPONENT=<component_id> APP_TYPE=backend_service ROLE=<role>
   ```
   If you cannot start sessions, print that message and stop.

**Shorthands used below**

- *Inbound units*: units of kind `http_endpoint`, `grpc_method`, `graphql_operation`, `websocket`.
- *Network dependencies*: dependencies with protocol `http`, `grpc`, `graphql`, `db`, `cache`, `broker_publish`, `smtp`, `ldap`, `cloud_sdk`, `other`.
- *Health paths*: `/health`, `/healthz`, `/livez`, `/readyz`, `/ready`, `/live`, `/ping`, `/actuator/health`, `/actuator/health/liveness`, `/actuator/health/readiness` (exact match after removing any context path).
- *Admin-like path*: a path segment equal to `admin`, `internal`, `manage`, `management`, `ops` or `backoffice`.
- *Public unit*: listed in `OVERRIDES.public_units`.

---

## Performance

### PERF-01 · Bounded result sets on collection endpoints
**Targets:** units of kind `http_endpoint` or `graphql_operation` with `returns_collection` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | path is a health path | not_applicable | FACT_EXCLUDES |
| A1 | `returns_collection` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### PERF-02 · No per-item database or remote calls inside loops
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | D has a dependency with protocol `db`, `http`, `grpc`, `graphql` or `cache`, or Q is not empty | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### PERF-03 · Connection pooling and client reuse
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | D has a dependency with protocol `db`, `http`, `grpc`, `graphql` or `cache` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### PERF-04 · No blocking I/O on async or event-loop request paths
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.async.event_loop` is true | applicable | FACT_MATCH |
| N1 | `F.async.event_loop` is false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### PERF-05 · Large inputs and outputs are streamed
**Targets:** inbound units and `message_consumer` units with `bulk_io` true or `"unknown"`, or `accepts_files` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `bulk_io` is true or `accepts_files` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### PERF-06 · Performance target declared for latency-sensitive units
**Targets:** units of kind `http_endpoint`, `grpc_method`, `graphql_operation`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | unit is a key of `OVERRIDES.latency_targets` | applicable | OVERRIDE |
| N1 | path is a health path | not_applicable | FACT_EXCLUDES |
| A2 | always (a synchronous inbound path is latency-sensitive) | applicable | FACT_MATCH |

---

## Resilience

### RES-01 · Timeouts on every outbound call
**Targets:** network dependencies.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | always | applicable | FACT_MATCH |

### RES-02 · Safe retries
**Targets:** network dependencies.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | always (step 3 checks that any retry layer, explicit or default, is safe; "no retries" is a valid outcome) | applicable | FACT_MATCH |

### RES-03 · Circuit breaker / fail-fast for synchronous dependencies
**Targets:** dependencies with protocol `http`, `grpc`, `graphql`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | U contains at least one inbound unit (dependency may be called on a request path) | applicable | FACT_MATCH |
| N1 | U contains no inbound units (worker only) | not_applicable | FACT_EXCLUDES |

### RES-04 · Idempotent handling of retried or redelivered work
**Targets:** units of kind `message_consumer`, `http_endpoint`, `grpc_method`, `graphql_operation` with `mutating` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | kind is `message_consumer` and `mutating` is true (at-least-once delivery) | applicable | FACT_MATCH |
| A2 | unit is in `OVERRIDES.retried_units` and `mutating` is true | applicable | OVERRIDE |
| N1 | kind is not `message_consumer`, `mutating` is true, and the unit is not in `OVERRIDES.retried_units` (no evidence of upstream retries) | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### RES-05 · Dead-letter / poison-message handling
**Targets:** units of kind `message_consumer`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | always | applicable | FACT_MATCH |

### RES-06 · Readiness and liveness health checks
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | `F.runtime.long_running` is false | not_applicable | FACT_EXCLUDES |
| N2 | `F.deploy.kinds` contains only `ServerlessFunction` | not_applicable | FACT_EXCLUDES |
| A1 | `F.runtime.long_running` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### RES-07 · Graceful shutdown
**Targets:** the component. Same rule table as RES-06 (N1, N2, A1, U1).

### RES-08 · Container CPU/memory requests and limits
**Targets:** deployments of kind `Deployment`, `StatefulSet`, `DaemonSet`, `Rollout`, `Job`, `CronJob`, `EcsTaskDefinition`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | always | applicable | FACT_MATCH |

### RES-09 · Inbound rate limiting / throttling
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | U contains no inbound units | not_applicable | FACT_EXCLUDES |
| A1 | `OVERRIDES.platform.rate_limiting_at_gateway` is set (true or false) | applicable | OVERRIDE |
| A2 | otherwise | applicable | FACT_MATCH |

### RES-10 · Bounded concurrency and queues
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | `F.runtime.long_running` is false | not_applicable | FACT_EXCLUDES |
| A1 | `F.runtime.long_running` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### RES-11 · Request body and upload size limits
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | U contains no inbound units | not_applicable | FACT_EXCLUDES |
| A1 | some inbound unit has an input with location `body`, `form` or `file`, or a `graphql_operation` unit exists | applicable | FACT_MATCH |
| N2 | otherwise (only path/query/header/cookie inputs) | not_applicable | FACT_EXCLUDES |

### RES-12 · Centralized error handling
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | U is not empty | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

---

## Security

### SEC-01 · Input validation on every external input
**Targets:** inbound units and `message_consumer` units.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | the unit has no inputs | not_applicable | FACT_EXCLUDES |
| A1 | otherwise | applicable | FACT_MATCH |

### SEC-02 · Mass-assignment protection
**Targets:** units of kind `http_endpoint` or `graphql_operation` that have an input with location `body` or `form`.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | `mutating` is false | not_applicable | FACT_EXCLUDES |
| A1 | `mutating` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-03 · File upload validation
**Targets:** units of kind `http_endpoint` or `graphql_operation` with `accepts_files` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `accepts_files` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-04 · Safe file-system access
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `file_path` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-05 · Injection-safe data access
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | Q is not empty, or D has a dependency with protocol `db` or `ldap` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-06 · Safe command and code execution
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `os_exec`, `dynamic_code` or `template_string` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-07 · Safe deserialization and XML parsing
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `deserialization` or `xml_parser` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-08 · SSRF protection for user-controlled outbound URLs
**Targets:** dependencies with protocol `http`, `grpc`, `graphql` or `cloud_sdk` and `url_from_input` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `url_from_input` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-09 · Contextual output encoding
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.http.serves_browser_html` is true | applicable | FACT_MATCH |
| A2 | S has a sink of kind `html_raw` | applicable | FACT_MATCH |
| N1 | `F.http.serves_browser_html` is false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-10 · Browser security headers and CSP
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.http.serves_browser_html` is true | applicable | FACT_MATCH |
| N1 | `F.http.serves_browser_html` is false (machine-to-machine API) | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-11 · Authentication enforced on every non-public entry point
**Targets:** inbound units.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | unit is a public unit | not_applicable | OVERRIDE |
| N2 | method is `GET` and path is a health path | not_applicable | FACT_EXCLUDES |
| A1 | always (every other network entry point must be authenticated, by the app or by a declared gateway) | applicable | FACT_MATCH |

### SEC-12 · Secure token and session validation
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.identity.mechanisms` contains `jwt_bearer`, `session_cookie`, `oauth2_oidc_login`, `oauth2_resource_server` or `saml` | applicable | FACT_MATCH |
| N1 | `F.identity.mechanisms` is `none_found` or contains only `api_key`, `basic`, `mtls` | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-13 · Passwords stored with an adaptive hashing function
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.identity.local_password_store` is true | applicable | FACT_MATCH |
| N1 | `F.identity.local_password_store` is false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-14 · Brute-force protection on login
**Targets:** units of kind `http_endpoint` or `graphql_operation` with `is_login` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `is_login` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-15 · CSRF protection for cookie-authenticated state changes
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | no unit of kind `http_endpoint` has `mutating` true or `"unknown"` | not_applicable | FACT_EXCLUDES |
| A1 | `F.identity.mechanisms` contains `session_cookie` or `oauth2_oidc_login` | applicable | FACT_MATCH |
| N2 | `F.identity.mechanisms` is known and contains neither (tokens are not sent automatically by browsers) | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-16 · Deny-by-default, function-level authorization
**Targets:** inbound units that are not public units and whose path is not a health path.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.authz.role_model` is true | applicable | FACT_MATCH |
| A2 | path is admin-like | applicable | FACT_MATCH |
| N1 | `F.authz.role_model` is false (no roles or permissions exist; all authenticated callers are equal) | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-17 · Object-level and tenant-level authorization
**Targets:** units of kind `http_endpoint` with a non-empty `resource_id_params` (or `"unknown"`), and units of kind `graphql_operation` or `grpc_method` with an input whose name is `id` or ends in `Id`/`_id`.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | unit is a public unit | not_applicable | OVERRIDE |
| A1 | `F.identity.has_end_users` is true | applicable | FACT_MATCH |
| A2 | `F.tenancy.multi_tenant` is true | applicable | FACT_MATCH |
| N2 | `F.identity.has_end_users` is false and `F.tenancy.multi_tenant` is false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise (including `resource_id_params` = `"unknown"`) | undetermined | MISSING_FACT |

### SEC-18 · CORS restricted to trusted origins
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | U contains a unit of kind `http_endpoint`, `graphql_operation` or `websocket` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-20 · No hard-coded secrets
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-21 · No sensitive data written to logs
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-22 · Secure transport
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | D has a network dependency, or U contains an inbound unit | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-23 · Error responses do not leak internal details
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | U contains an inbound unit | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-24 · Dependency vulnerability management
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-25 · Least-privilege container runtime
**Targets:** deployments of kind `Deployment`, `StatefulSet`, `DaemonSet`, `Rollout`, `Job`, `CronJob`, `Dockerfile`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | always | applicable | FACT_MATCH |

### SEC-26 · Open-redirect protection
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `redirect` with `input_derived` true or `"unknown"` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-27 · GraphQL hardening
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.graphql.present` is true | applicable | FACT_MATCH |
| N1 | `F.graphql.present` is false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

---

## Output format

`OUT/applicability/<slug>__backend_service.json` (schema: `PROMPTS/schemas/applicability.schema.json`):

```json
{
  "schema_version": "prs-applicability/1",
  "prompt": "02-applicability/backend_service@1",
  "catalog_version": 1,
  "component_id": "cmp:services/orders",
  "app_type": "backend_service",
  "role": "primary",
  "results": [
    {
      "result_id": "RES-01@dep:http:payment-service",
      "practice_id": "RES-01",
      "category": "resilience",
      "scope": "dependency",
      "severity": "high",
      "target_id": "dep:http:payment-service",
      "status": "applicable",
      "reason": "FACT_MATCH",
      "rule": "A1",
      "facts_used": ["dependencies[dep:http:payment-service].protocol=http"],
      "evidence": [{"file": "services/orders/src/main/java/com/acme/PaymentClient.java", "line": 42, "symbol": "PaymentClient.charge", "snippet": "restClient.post().uri(\"/charge\")"}]
    }
  ]
}
```

`category`, `scope` and `severity` are copied from the catalog. Results are ordered by catalog order, then `target_id`.
