---
name: prs-applicability-cli-tool
version: 1
description: PRS step 2 for app type cli_tool (command-line programs built with argparse, click, typer, cobra, urfave/cli, commander, yargs, oclif, picocli, System.CommandLine and similar). Decides, for every catalog practice and target, whether the practice applies. Pure function of facts.json and overrides.
inputs: CODE_ROOT, OUT, OVERRIDES (optional), COMPONENT, APP_TYPE=cli_tool, ROLE (primary|secondary), PROMPTS
output: OUT/applicability/<component slug>__cli_tool.json
---

# PRS step 2 — Applicability: CLI tool

## Role

You decide **which practices apply** to one component's command-line surface. You do not decide whether they are implemented.

**Use only `OUT/facts.json` and `OVERRIDES`.** Do not open or search the repository in this session. If a rule needs a fact that is `"unknown"` or absent, follow the rule table (usually `undetermined`).

Read first: `PROMPTS/shared/conventions.md` and `PROMPTS/shared/practice-catalog.yaml`.

## Procedure

1. Load `OUT/facts.json`. Select the component `COMPONENT`. Let **U** be its units with `app_type == "cli_tool"`, **D** its dependencies, **F** its `component_facts`, **S** its sinks, **Q** its data-access sites.
2. Select practices: catalog entries whose `app_types` include `cli_tool`. If `ROLE == secondary` (for example a management CLI shipped inside a service), apply the ownership rule (conventions §4): keep `scope: unit` practices, plus practices whose `app_types` do not include the component's `primary_app_type`.
3. For each selected practice in catalog order, build its targets from its **Targets** line (or write an `N0` result if there are none), then evaluate the rule table top to bottom for each target in sorted ID order. The first matching row decides. Record `facts_used` and up to 5 evidence items copied from the facts used.
4. Write the output, canonicalize and validate (conventions §12).
5. Hand off: start a **new** session with
   ```
   Read PROMPTS/shared/conventions.md, then follow PROMPTS/03-implementation-check/cli_tool.md.
   CODE_ROOT=<path> CONFIG_PATHS=<paths or none> OVERRIDES=<path or none> OUT=<path>
   COMPONENT=<component_id> APP_TYPE=cli_tool ROLE=<role>
   ```
   If you cannot start sessions, print that message and stop.

**Shorthands used below**

- *Command units*: units of kind `cli_command`.
- *Network dependencies*: dependencies with protocol `http`, `grpc`, `graphql`, `db`, `cache`, `broker_publish`, `smtp`, `ldap`, `cloud_sdk`, `other`.

---

## Performance

### PERF-02 · No per-item database or remote calls inside loops
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | D has a dependency with protocol `db`, `http`, `grpc`, `graphql`, `cache` or `cloud_sdk`, or Q is not empty | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### PERF-05 · Large inputs and outputs are streamed
**Targets:** command units with `reads_stdin` or `reads_files` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `reads_stdin` is true or `reads_files` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### PERF-14 · Fast CLI startup
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

---

## Resilience

### RES-01 · Timeouts on every outbound call
**Targets:** network dependencies. **A1** always → applicable, FACT_MATCH.

### RES-02 · Safe retries
**Targets:** network dependencies. **A1** always → applicable, FACT_MATCH. ("No retries" is a valid outcome in step 3.)

### RES-12 · Centralized error handling (top-level handler, clear message, no raw stack trace for expected errors)
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### RES-19 · Meaningful exit codes
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### RES-20 · Signal handling with bounded cleanup
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.cli.network` is true | applicable | FACT_MATCH |
| A2 | `F.files.writes_outputs` is true | applicable | FACT_MATCH |
| A3 | some command unit has `reads_stdin` true | applicable | FACT_MATCH |
| N1 | `F.cli.network` is false, `F.files.writes_outputs` is false and no command unit has `reads_stdin` true or `"unknown"` (short read-only commands) | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### RES-21 · Atomic, recoverable file outputs
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.files.writes_outputs` is true | applicable | FACT_MATCH |
| N1 | `F.files.writes_outputs` is false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

---

## Security

### SEC-01 · Input validation on every external input (arguments, flags, env vars, stdin, files)
**Targets:** command units.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | the unit has no inputs | not_applicable | FACT_EXCLUDES |
| A1 | otherwise | applicable | FACT_MATCH |

### SEC-04 · Safe file-system access (path handling, temp files, permissions)
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `file_path` | applicable | FACT_MATCH |
| A2 | `F.files.writes_outputs` is true | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-05 · Injection-safe data access
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | Q is not empty, or D has a dependency with protocol `db` or `ldap` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-06 · Safe command and code execution (argument injection, shell use, eval)
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `os_exec`, `dynamic_code` or `template_string` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-07 · Safe deserialization and XML parsing (config files, YAML, pickle)
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `deserialization` or `xml_parser` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-20 · No hard-coded secrets
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-21 · No sensitive data written to logs or terminal output
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-22 · Secure transport
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | D has a network dependency | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-24 · Dependency vulnerability management
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

---

## Output format

`OUT/applicability/<slug>__cli_tool.json`, same structure as every applicability file (schema: `PROMPTS/schemas/applicability.schema.json`):

```json
{
  "schema_version": "prs-applicability/1",
  "prompt": "02-applicability/cli_tool@1",
  "catalog_version": 1,
  "component_id": "cmp:tools/acmectl",
  "app_type": "cli_tool",
  "role": "primary",
  "results": [
    {
      "result_id": "RES-19@cmp:tools/acmectl",
      "practice_id": "RES-19",
      "category": "resilience",
      "scope": "component",
      "severity": "medium",
      "target_id": "cmp:tools/acmectl",
      "status": "applicable",
      "reason": "FACT_MATCH",
      "rule": "A1",
      "facts_used": ["app_type=cli_tool"],
      "evidence": [{"file": "tools/acmectl/pyproject.toml", "line": 14, "symbol": "", "snippet": "acmectl = \"acmectl.main:cli\""}]
    }
  ]
}
```

`category`, `scope` and `severity` are copied from the catalog. Results are ordered by catalog order, then `target_id`.
