---
name: prs-applicability-batch-job
version: 1
description: PRS step 2 for app type batch_job (Spring Batch, Airflow/Dagster/Prefect, Kubernetes Job/CronJob, @Scheduled/cron tasks, Celery beat, Quartz, Hangfire, ETL scripts). Decides, for every catalog practice and target, whether the practice applies. Pure function of facts.json and overrides.
inputs: CODE_ROOT, OUT, OVERRIDES (optional), COMPONENT, APP_TYPE=batch_job, ROLE (primary|secondary), PROMPTS
output: OUT/applicability/<component slug>__batch_job.json
---

# PRS step 2 — Applicability: batch job

## Role

You decide **which practices apply** to one component's batch and scheduled work. You do not decide whether they are implemented.

**Use only `OUT/facts.json` and `OVERRIDES`.** Do not open or search the repository in this session. If a rule needs a fact that is `"unknown"` or absent, follow the rule table (usually `undetermined`).

Read first: `PROMPTS/shared/conventions.md` and `PROMPTS/shared/practice-catalog.yaml`.

## Procedure

1. Load `OUT/facts.json`. Select the component `COMPONENT`. Let **U** be its units with `app_type == "batch_job"`, **D** its dependencies, **P** its deployments, **F** its `component_facts`, **S** its sinks, **Q** its data-access sites.
2. Select practices: catalog entries whose `app_types` include `batch_job`. If `ROLE == secondary` (for example `@Scheduled` tasks inside a web service), apply the ownership rule (conventions §4): keep `scope: unit` practices, plus practices whose `app_types` do not include the component's `primary_app_type`.
3. For each selected practice in catalog order, build its targets from its **Targets** line (or write an `N0` result if there are none), then evaluate the rule table top to bottom for each target in sorted ID order. The first matching row decides. Record `facts_used` and up to 5 evidence items copied from the facts used.
4. Write the output, canonicalize and validate (conventions §12).
5. Hand off: start a **new** session with
   ```
   Read PROMPTS/shared/conventions.md, then follow PROMPTS/03-implementation-check/batch_job.md.
   CODE_ROOT=<path> CONFIG_PATHS=<paths or none> OVERRIDES=<path or none> OUT=<path>
   COMPONENT=<component_id> APP_TYPE=batch_job ROLE=<role>
   ```
   If you cannot start sessions, print that message and stop.

**Shorthands used below**

- *Runnable units*: units of kind `batch_job` or `scheduled_task` (what a scheduler starts).
- *Work units*: units of kind `batch_step`, plus `batch_job` units whose `steps` list is empty, plus `scheduled_task` units (where records are actually read and written).
- *Network dependencies*: dependencies with protocol `http`, `grpc`, `graphql`, `db`, `cache`, `broker_publish`, `smtp`, `ldap`, `cloud_sdk`, `other`.
- *Reads input*: a `batch_job` with a non-empty `reads` list, a `batch_step` with a `reader`, or any unit with an input of location `input_file`, `record` or `message`.

---

## Performance

### PERF-02 · No per-item database or remote calls inside loops
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | D has a dependency with protocol `db`, `http`, `grpc`, `graphql` or `cache`, or Q is not empty | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### PERF-03 · Connection pooling and client reuse
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | D has a dependency with protocol `db`, `http`, `grpc`, `graphql` or `cache` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### PERF-05 · Large inputs are streamed, not loaded whole into memory
**Targets:** work units.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | the unit reads input | applicable | FACT_MATCH |
| N1 | the unit's `reads` is an empty list and it has no `reader` and no inputs | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### PERF-06 · Performance target (time window) declared
**Targets:** runnable units.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | unit is a key of `OVERRIDES.window_bound_units` | applicable | OVERRIDE |
| A2 | `schedule` is a non-empty string (a scheduled job must finish before its next run) | applicable | FACT_MATCH |
| N1 | `schedule` is null (manually or externally triggered) | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### PERF-07 · Chunked processing with bulk writes
**Targets:** work units with `writes_data` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `writes_data` is true and the unit reads input | applicable | FACT_MATCH |
| N1 | `writes_data` is true and the unit's `reads` is an empty list with no `reader` (single write, nothing to chunk) | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

---

## Resilience

### RES-01 · Timeouts on every outbound call
**Targets:** network dependencies. **A1** always → applicable, FACT_MATCH.

### RES-02 · Safe retries
**Targets:** network dependencies. **A1** always → applicable, FACT_MATCH. ("No retries" is a valid outcome in step 3.)

### RES-04 · Idempotent re-runs
**Targets:** runnable units with `writes_data` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `writes_data` is true (failed jobs are re-run by schedulers, `backoffLimit`, task retries or operators) | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### RES-08 · Container CPU/memory requests and limits
**Targets:** deployments of kind `Job`, `CronJob`, `Deployment`, `StatefulSet`, `EcsTaskDefinition`. **A1** always → applicable, FACT_MATCH.

### RES-10 · Bounded concurrency and queues
**Targets:** the component. **A1** always → applicable, FACT_MATCH. (Single-threaded processing is a valid outcome in step 3.)

### RES-12 · Centralized error handling (no swallowed failures)
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### RES-14 · Job restartability / checkpointing
**Targets:** runnable units.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | kind is `batch_job` and it reads input (multi-record work can resume from a checkpoint) | applicable | FACT_MATCH |
| A2 | kind is `batch_job` and `steps` has 2 or more entries | applicable | FACT_MATCH |
| N1 | kind is `scheduled_task` (re-runs on its next schedule; idempotency is covered by RES-04) | not_applicable | FACT_EXCLUDES |
| N2 | kind is `batch_job`, `reads` is an empty list and `steps` has fewer than 2 entries | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### RES-15 · Bounded skip and retry policy for bad records
**Targets:** work units.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | kind is `batch_step` and `step_type` is `chunk` | applicable | FACT_MATCH |
| A2 | the unit has an input of location `input_file`, `record` or `message` | applicable | FACT_MATCH |
| N1 | `step_type` is `tasklet` or `operator` and the unit has no inputs | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### RES-16 · Job execution deadline / timeout
**Targets:** runnable units. **A1** always → applicable, FACT_MATCH.

### RES-17 · Overlapping runs prevented
**Targets:** runnable units.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `schedule` is a non-empty string | applicable | FACT_MATCH |
| A2 | kind is `scheduled_task`, `in_process` is true and `F.deploy.multi_instance` is true or `"unknown"` (the task runs on every replica) | applicable | FACT_MATCH |
| N1 | `schedule` is null | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### RES-18 · Job failure is surfaced
**Targets:** runnable units. **A1** always → applicable, FACT_MATCH.

### RES-21 · Atomic, recoverable file outputs
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.files.writes_outputs` is true | applicable | FACT_MATCH |
| N1 | `F.files.writes_outputs` is false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

---

## Security

### SEC-01 · Input validation on every external input (files, records, messages, API responses)
**Targets:** work units.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | the unit reads input | applicable | FACT_MATCH |
| N1 | the unit has no inputs, an empty `reads` list and no `reader` | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-04 · Safe file-system access
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `file_path` | applicable | FACT_MATCH |
| A2 | `F.files.writes_outputs` is true (temp and output files) | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-05 · Injection-safe data access
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | Q is not empty, or D has a dependency with protocol `db` or `ldap` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-06 · Safe command and code execution
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `os_exec`, `dynamic_code` or `template_string` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-07 · Safe deserialization and XML parsing
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `deserialization` or `xml_parser` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-20 · No hard-coded secrets
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-21 · No sensitive data written to logs
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-22 · Secure transport
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | D has a network dependency | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-24 · Dependency vulnerability management
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-25 · Least-privilege container runtime
**Targets:** deployments of kind `Job`, `CronJob`, `Deployment`, `StatefulSet`, `Dockerfile`. **A1** always → applicable, FACT_MATCH.

---

## Output format

`OUT/applicability/<slug>__batch_job.json`, same structure as every applicability file (schema: `PROMPTS/schemas/applicability.schema.json`):

```json
{
  "schema_version": "prs-applicability/1",
  "prompt": "02-applicability/batch_job@1",
  "catalog_version": 1,
  "component_id": "cmp:jobs/settlement",
  "app_type": "batch_job",
  "role": "primary",
  "results": [
    {
      "result_id": "RES-17@job:nightly-settlement",
      "practice_id": "RES-17",
      "category": "resilience",
      "scope": "unit",
      "severity": "high",
      "target_id": "job:nightly-settlement",
      "status": "applicable",
      "reason": "FACT_MATCH",
      "rule": "A1",
      "facts_used": ["units[job:nightly-settlement].attributes.schedule=0 2 * * *"],
      "evidence": [{"file": "deploy/settlement-cronjob.yaml", "line": 7, "symbol": "", "snippet": "schedule: \"0 2 * * *\""}]
    }
  ]
}
```

`category`, `scope` and `severity` are copied from the catalog. Results are ordered by catalog order, then `target_id`.
