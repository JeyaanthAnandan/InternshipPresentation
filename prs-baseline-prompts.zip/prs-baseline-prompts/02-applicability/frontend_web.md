---
name: prs-applicability-frontend-web
version: 1
description: PRS step 2 for app type frontend_web (browser apps built with React, Angular, Vue, Svelte, Next.js, Nuxt and similar). Decides, for every catalog practice and target, whether the practice applies. Pure function of facts.json and overrides.
inputs: CODE_ROOT, OUT, OVERRIDES (optional), COMPONENT, APP_TYPE=frontend_web, ROLE (primary|secondary), PROMPTS
output: OUT/applicability/<component slug>__frontend_web.json
---

# PRS step 2 — Applicability: frontend web

## Role

You decide **which practices apply** to one component's browser-app surface. You do not decide whether they are implemented.

**Use only `OUT/facts.json` and `OVERRIDES`.** Do not open or search the repository in this session. If a rule needs a fact that is `"unknown"` or absent, follow the rule table (usually `undetermined`).

Read first: `PROMPTS/shared/conventions.md` and `PROMPTS/shared/practice-catalog.yaml`.

Scope note: server-side parts of meta-frameworks (Next.js route handlers, server actions, Nuxt/SvelteKit server routes) are `backend_service` units and are judged by the backend prompts. This prompt covers what runs in, or is shipped to, the browser, plus the frontend's own outbound API clients (including server-side fetches during SSR).

## Procedure

1. Load `OUT/facts.json`. Select the component `COMPONENT`. Let **U** be its units with `app_type == "frontend_web"`, **D** its dependencies, **P** its deployments, **F** its `component_facts`, **S** its sinks.
2. Select practices: catalog entries whose `app_types` include `frontend_web`. If `ROLE == secondary`, apply the ownership rule (conventions §4): keep `scope: unit` practices, plus practices whose `app_types` do not include the component's `primary_app_type`.
3. For each selected practice in catalog order, build its targets from its **Targets** line (or write an `N0` result if there are none), then evaluate the rule table top to bottom for each target in sorted ID order. The first matching row decides. Record `facts_used` and up to 5 evidence items copied from the facts used.
4. Write the output, canonicalize and validate (conventions §12).
5. Hand off: start a **new** session with
   ```
   Read PROMPTS/shared/conventions.md, then follow PROMPTS/03-implementation-check/frontend_web.md.
   CODE_ROOT=<path> CONFIG_PATHS=<paths or none> OVERRIDES=<path or none> OUT=<path>
   COMPONENT=<component_id> APP_TYPE=frontend_web ROLE=<role>
   ```
   If you cannot start sessions, print that message and stop.

**Shorthands used below**

- *API dependencies*: dependencies with protocol `http`, `graphql`, `grpc` or `cloud_sdk`.
- *Default public routes*: `/login`, `/logout`, `/signin`, `/sign-in`, `/signup`, `/sign-up`, `/register`, `/forgot-password`, `/reset-password`, `/verify-email`, `/callback`, any path starting `/auth/`, `/404`, `/500`, `/error`, `/not-found`, `/terms`, `/privacy`, `/about`, `/help`, `/contact`, and routes with `catch_all: true`. (`/` is **not** public by default; list it in `OVERRIDES.public_units` if it is.)
- *Public unit*: listed in `OVERRIDES.public_units`.

---

## Performance

### PERF-08 · Bundle size budget enforced in the build
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### PERF-09 · Route-level code splitting / lazy loading
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | U contains at least 2 units of kind `ui_route` | applicable | FACT_MATCH |
| N1 | U contains exactly 1 `ui_route` unit and no `ui_route` unit has `resolved: false` | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### PERF-10 · Optimized images
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.frontend.has_images` is true | applicable | FACT_MATCH |
| N1 | `F.frontend.has_images` is false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### PERF-11 · Core Web Vitals budgets asserted in CI or measured in the field
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### PERF-12 · Long-term caching for static assets
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### PERF-13 · Third-party scripts do not block rendering
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.frontend.third_party_scripts` is true | applicable | FACT_MATCH |
| N1 | `F.frontend.third_party_scripts` is false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

---

## Resilience

### RES-01 · Timeouts on every outbound call
**Targets:** API dependencies. **A1** always → applicable, FACT_MATCH.

### RES-02 · Safe retries
**Targets:** API dependencies. **A1** always → applicable, FACT_MATCH. (Step 3 checks any retry layer, including data-fetching library defaults; "no retries" is a valid outcome.)

### RES-08 · Container CPU/memory requests and limits
**Targets:** deployments of kind `Deployment`, `StatefulSet`, `DaemonSet`, `Rollout`, `EcsTaskDefinition`. **A1** always → applicable, FACT_MATCH.

### RES-12 · Centralized error handling (error boundaries / global handler)
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### RES-13 · UI handles loading, error and empty states for remote data
**Targets:** units of kind `ui_route` with `fetches_data` true or `"unknown"`.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `fetches_data` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

---

## Security

### SEC-06 · Safe command and code execution (no eval / new Function / string templates)
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `dynamic_code` or `template_string` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

### SEC-09 · Contextual output encoding
**Targets:** the component. **A1** always → applicable, FACT_MATCH. (Every browser UI renders data; step 3 checks framework escaping and raw-HTML sinks.)

### SEC-10 · Browser security headers and CSP
**Targets:** the component. **A1** always → applicable, FACT_MATCH. (Headers may be set by hosting config or the edge; step 3 decides.)

### SEC-11 · Protected routes require authentication (route guards)
**Targets:** units of kind `ui_route`.

Note: client-side guards are a usability control, not a security boundary; the server must enforce access (backend SEC-11/SEC-16). This practice checks that protected screens are not reachable without a session in the UI.

| Rule | When | Status | Reason |
|---|---|---|---|
| N1 | unit is a public unit | not_applicable | OVERRIDE |
| N2 | path is a default public route | not_applicable | FACT_EXCLUDES |
| N3 | `F.identity.has_end_users` is false and `F.identity.authenticates_callers` is false (the app has no login) | not_applicable | FACT_EXCLUDES |
| A1 | `F.identity.has_end_users` is true or `F.identity.authenticates_callers` is true | applicable | FACT_MATCH |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-19 · Tokens and session data stored safely in the browser
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | `F.identity.has_end_users` is true or `F.identity.authenticates_callers` is true | applicable | FACT_MATCH |
| N1 | both are false | not_applicable | FACT_EXCLUDES |
| U1 | otherwise | undetermined | MISSING_FACT |

### SEC-20 · No hard-coded secrets in code, config or built assets
**Targets:** the component. **A1** always → applicable, FACT_MATCH. (Anything bundled for the browser, including `VITE_*`, `NEXT_PUBLIC_*`, `REACT_APP_*` and Angular `environment*.ts` values, is public.)

### SEC-22 · Secure transport
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-24 · Dependency vulnerability management
**Targets:** the component. **A1** always → applicable, FACT_MATCH.

### SEC-25 · Least-privilege container runtime
**Targets:** deployments of kind `Deployment`, `StatefulSet`, `DaemonSet`, `Rollout`, `Dockerfile`. **A1** always → applicable, FACT_MATCH.

### SEC-26 · Open-redirect protection
**Targets:** the component.

| Rule | When | Status | Reason |
|---|---|---|---|
| A1 | S has a sink of kind `redirect` with `input_derived` true or `"unknown"` | applicable | FACT_MATCH |
| N1 | otherwise | not_applicable | FACT_EXCLUDES |

---

## Output format

`OUT/applicability/<slug>__frontend_web.json`, same structure as every applicability file (schema: `PROMPTS/schemas/applicability.schema.json`):

```json
{
  "schema_version": "prs-applicability/1",
  "prompt": "02-applicability/frontend_web@1",
  "catalog_version": 1,
  "component_id": "cmp:web",
  "app_type": "frontend_web",
  "role": "primary",
  "results": [
    {
      "result_id": "RES-13@ui:/orders",
      "practice_id": "RES-13",
      "category": "resilience",
      "scope": "unit",
      "severity": "low",
      "target_id": "ui:/orders",
      "status": "applicable",
      "reason": "FACT_MATCH",
      "rule": "A1",
      "facts_used": ["units[ui:/orders].attributes.fetches_data=true"],
      "evidence": [{"file": "web/src/routes/orders.tsx", "line": 12, "symbol": "OrdersPage", "snippet": "const { data } = useQuery({ queryKey: ['orders'], queryFn: fetchOrders })"}]
    }
  ]
}
```

`category`, `scope` and `severity` are copied from the catalog. Results are ordered by catalog order, then `target_id`.
