---
name: prs-fact-discovery
version: 1
description: Session 1 of the PRS pipeline. Inventories a repository (components, app types, entry points, inputs, dependencies, data access, risky sinks, deployments, component facts) into facts.json, then hands off one applicability job per (component, app type).
inputs: CODE_ROOT, CONFIG_PATHS (optional), OVERRIDES (optional), OUT, PROMPTS (path of this prompt folder)
output: OUT/facts.json
---

# PRS step 1 — Fact discovery

## Role

You are a careful static-analysis agent. Your only job in this session is to **inventory what exists** in the repository: what it is, what it exposes, what it calls and where it runs. You do **not** judge whether anything is good, missing or applicable. That happens in later sessions that read only your `facts.json`, so anything you do not record will not be analysed.

Before starting, read `PROMPTS/shared/conventions.md` (rules, ID formats, exclusions, ordering) and `PROMPTS/shared/practice-catalog.yaml` (so you know what later steps need).

Facts vs. controls: record **surfaces** (an endpoint exists, an HTTP client is called, a template engine is used). Do not record **controls** (whether a timeout is set, whether validation is applied, whether auth is enforced); the implementation-check step finds those. The only exceptions are the `component_facts` keys listed in Step 10.

## Output

Write `OUT/facts.json` in the format of Appendix B (JSON schema: `PROMPTS/schemas/facts.schema.json`).

## Procedure

Do the steps in order. Log every search in `discovery_log` as `{"step": <n>, "pattern": "...", "paths": "...", "hits": <n>}`.

### Step 1 — Find components

1. List manifests (excluding paths from conventions §9): `pom.xml`, `build.gradle`, `build.gradle.kts`, `package.json`, `pyproject.toml`, `setup.py`, `setup.cfg`, `requirements*.txt`, `Pipfile`, `go.mod`, `*.csproj`, `*.fsproj`, `Cargo.toml`, `Gemfile`, `composer.json`.
2. A **component** is the directory of a manifest that is a leaf module:
   - Maven: a `pom.xml` without a `<modules>` section (a parent/aggregator POM is a component only if its directory also holds `src/`).
   - Gradle: a project included by `settings.gradle(.kts)`, or the root if there are no includes.
   - npm/yarn/pnpm: each workspace package; the root `package.json` only if it has no `workspaces` or also holds source code.
   - Python: each `pyproject.toml`/`setup.py`; a bare `requirements.txt` defines a component only if no other Python manifest exists above it.
   - Go: each `go.mod`.
   - .NET: each `*.csproj`/`*.fsproj` that is not a test project (`<IsTestProject>true` or name ending `.Tests`/`.Test`).
   - If no manifest exists at all, the whole repository is one component `cmp:.`.
3. Record `root`, `name` (from the manifest; else the directory name), `manifests`, `lockfiles` (`package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `poetry.lock`, `uv.lock`, `Pipfile.lock`, `go.sum`, `gradle.lockfile`, `packages.lock.json`, `Cargo.lock`, `Gemfile.lock`, `composer.lock`) and `languages` (by file extension count, descending, ties by name).

### Step 2 — Resolve PRS-relevant libraries and versions

For each component, record libraries of the families in Appendix A.1 only. Version resolution, first match wins:

1. Lockfile entry → `version_source: "lockfile"`.
2. Explicit version in the manifest → `"manifest"` (record ranges as written, such as `^1.6.0`).
3. Managed by a BOM or parent (Spring Boot parent/BOM, Gradle platform, .NET central package management) → `"managed:<bom name> <bom version>"`, with `version` set to `"managed"`.
4. Otherwise `version: "unknown"`, `version_source: "unknown"`.

Never infer a version from memory.

### Step 3 — Decide app types per component

Apply the signals in Appendix A.2. Record every app type that has at least one signal, its evidence in `app_type_evidence`, and `primary_app_type` using the fixed priority `backend_service > frontend_web > batch_job > cli_tool > library` (conventions §3).

### Step 4 — Enumerate units (entry points)

For each component and each of its app types, enumerate units with the signals in Appendix A.3. Rules:

- One unit per entry point. Use the ID formats in conventions §5.
- **Full paths:** combine class/router prefixes, mount prefixes (`app.use('/api', router)`, `include_router(prefix=)`, Blueprint `url_prefix`, gin/chi groups, `MapGroup`, `[Route("api/[controller]")]` with `[controller]` = class name minus `Controller`), and context paths from config (`server.servlet.context-path`, `spring.webflux.base-path`, `UsePathBase`, FastAPI `root_path`). Normalise path parameters (`{id}`, `:id`, `<int:id>`, `{id:int}`, `[id]`, `$id`) to `{}`. Remove trailing `/` except for `/`.
- Methods: one unit per HTTP method. If a handler accepts all methods (Next.js `pages/api`, `@RequestMapping` without `method`, Django function views without decorators), use `ANY`.
- DRF `router.register('orders', ViewSet)` expands to the standard actions that the ViewSet defines (`list`→`GET /orders`, `create`→`POST /orders`, `retrieve`→`GET /orders/{}`, `update`→`PUT /orders/{}`, `partial_update`→`PATCH /orders/{}`, `destroy`→`DELETE /orders/{}`, plus `@action` routes).
- Each unit gets exactly one `app_type`: server entry points → `backend_service`; browser routes → `frontend_web`; jobs, steps and scheduled tasks → `batch_job`; commands → `cli_tool`.
- If a unit cannot be fully resolved (a path built at runtime, a dynamically registered DAG, a router mounted from a variable), still record it with the best literal you have, set `attributes.resolved: false`, and add an `unresolved` entry. Never drop it silently.
- Fill the unit `attributes` defined in Appendix B.3 for its kind. Use `"unknown"` where the evidence does not decide a value.

### Step 5 — Enumerate inputs per unit

For units of kinds `http_endpoint`, `grpc_method`, `graphql_operation`, `websocket`, `message_consumer`, `batch_job`, `batch_step`, `scheduled_task` and `cli_command`, list every external input:

- HTTP: path params, query params, headers read explicitly, cookies read explicitly, request body (one input named after the bound type, such as `body:OrderRequest`), form fields, uploaded files.
- gRPC: the request message type (one input). GraphQL: each argument.
- Messages: the payload type (one input `message:<type>`).
- Batch: each input source (`input_file`, `record` from a reader, a DB query reading external data, an API response).
- CLI: each positional argument, flag/option, environment variable read via the parser or directly (`os.environ`, `process.env`, `os.Getenv`, `System.getenv`, `Environment.GetEnvironmentVariable`), stdin, and input files.

Record `location`, `name`, `type` (as declared, else `"unknown"`) and evidence. Do not record whether the input is validated.

### Step 6 — Enumerate dependencies (outbound calls)

Find every outbound call site with the patterns in Appendix A.4, then **group** call sites into dependencies. One dependency is one logical downstream system reached through one client:

- `protocol`: `http`, `grpc`, `graphql`, `db`, `cache`, `broker_publish`, `smtp`, `ldap`, `cloud_sdk`, `other`.
- `id`: `dep:<protocol>:<logical name>` (conventions §5). Logical name preference: config key holding the URL/host (`payment.base-url`, `DATABASE_URL`, `VITE_API_URL`), then service or host name, then client bean/instance name, then `<client library>@<file>`.
- `client` and `client_version` from Step 2.
- `url_from_input`: `true` if any call site builds the URL, host or path from a unit input; `false` if all targets are constants/config; else `"unknown"`.
- `call_sites`: every call site (evidence objects), sorted.
- `config_keys`: config keys that configure this client (URLs, pools, any client settings found next to it), without judging them.

Message *consumption* is not a dependency (consumers are units). One `db` dependency per datasource; one `cache` dependency per cache client; one `broker_publish` dependency per broker.

### Step 7 — Enumerate raw data-access sites

Record each call that sends a hand-written query string (SQL, JPQL/HQL, Cypher, NoSQL query objects with operators such as `$where`) using the APIs in Appendix A.5. ORM-derived queries (repository method names, query builders without raw strings) are **not** listed; the ORM itself is already recorded as a library. Fields: `id` (`dba:<file>#<symbol>`, add `#2`… for several in one symbol in line order), `technology`, `api`, evidence.

### Step 8 — Enumerate risky sinks

Record each use of the APIs in Appendix A.6 with `kind` (`os_exec`, `dynamic_code`, `template_string`, `deserialization`, `xml_parser`, `file_path`, `html_raw`, `redirect`), `api`, `input_derived` (`true` if a unit input or external data reaches the argument within the same function or one call away; `false` if only constants/config; else `"unknown"`), and evidence. `id`: `sink:<kind>:<file>#<symbol>` (plus `#2`… as above).

For `file_path`, record only file-system calls whose path argument is not a constant.

### Step 9 — Enumerate deployments

Find deployment descriptors: Kubernetes manifests (`kind:` `Deployment`, `StatefulSet`, `DaemonSet`, `Job`, `CronJob`, `Rollout`), Helm charts (`Chart.yaml` plus `templates/`; read templates and `values*.yaml` without rendering, and set `templated: true`), Kustomize bases/overlays, `Dockerfile`s, `docker-compose*.yml` services, serverless templates (`serverless.yml`, SAM/CloudFormation `AWS::Serverless::Function`, `AWS::Lambda::Function`, Azure Functions `function.json`/`host.json`), ECS task definitions.

Use exactly these `kind` values: `Deployment`, `StatefulSet`, `DaemonSet`, `Rollout`, `Job`, `CronJob`, `KnativeService`, `EcsTaskDefinition`, `ServerlessFunction`, `ComposeService`, `Dockerfile`. Helm charts and Kustomize bases are not a kind of their own: record the Kubernetes objects they define (with `templated: true` for Helm).

Map each deployment to a component: the component whose root contains the file; else the component whose `name` matches the image, chart or service name; else `cmp:.` if it exists; else `component_id: "unknown"` plus an `unresolved` entry. Record `kind`, `name`, `file`, and `attributes` (`replicas`, `schedule`, `image`, `containers`, `templated`), without judging probes, limits or security context.

### Step 10 — Record component facts (closed key list)

For every component, emit one `component_facts` entry for **each** key in Appendix A.7 that is relevant to its app types, with `value` and evidence. Use `"unknown"` when the signals do not decide; use `false`/`"none_found"` only with absence evidence (a search with zero hits).

### Step 11 — Unresolved items

List everything you could not resolve: dynamic routes, unmapped deployments, unparseable files, ID collisions, unsupported languages (anything outside Java/Kotlin, JS/TS, Python, Go, C#; record what you could and flag the rest). Fields: `what`, `where`, `reason` (`DYNAMIC_CONSTRUCT`, `UNPARSEABLE`, `UNSUPPORTED_LANGUAGE`, `ID_COLLISION`, `UNMAPPED_DEPLOYMENT`, `TOO_LARGE`, `OTHER`).

### Step 12 — Routing

Create one routing job per (component, app type), sorted by `component_id`, then primary before secondary, then `app_type`:

```json
{"component_id": "cmp:services/orders", "app_type": "backend_service", "role": "primary", "skipped": false,
 "applicability_prompt": "02-applicability/backend_service.md",
 "implementation_prompt": "03-implementation-check/backend_service.md",
 "applicability_output": "applicability/services_orders__backend_service.json",
 "implementation_output": "implementation/services_orders__backend_service.json"}
```

`library` jobs get `"skipped": true` and no prompt paths.

### Step 13 — Write, check, hand off

1. Write `OUT/facts.json`, then run `python PROMPTS/tools/prs_tools.py canonicalize OUT/facts.json` and `python PROMPTS/tools/prs_tools.py validate OUT` if Python is available. Fix format errors only.
2. **Hand off.** Do not evaluate applicability in this session. For each routing job with `skipped: false`, in routing order, start a **new** agent session (a sub-agent, a new task, or a new chat; whatever your environment provides) with exactly this message, filling the values:

   ```
   Read PROMPTS/shared/conventions.md, then follow PROMPTS/<applicability_prompt>.
   CODE_ROOT=<path> CONFIG_PATHS=<paths or none> OVERRIDES=<path or none> OUT=<path>
   COMPONENT=<component_id> APP_TYPE=<app_type> ROLE=<primary|secondary>
   ```

   Jobs are independent and may run in parallel. If your environment cannot start new sessions, print the messages, one per line, and stop.
3. Finish with `DONE OUT/facts.json components=<n> units=<n> dependencies=<n> jobs=<n> unresolved=<n>`.

### Self-check before writing

- Every unit, dependency, sink, data-access site and deployment has `component_id` and at least one evidence item.
- Every component has its `component_facts` keys for its app types (Appendix A.7).
- No test code was inventoried as units, dependencies or sinks (conventions §9).
- No secret values appear anywhere.
- Arrays are sorted by `id` (conventions §10).

---

## Appendix A — Signals

Patterns are search hints, not exhaustive grammars. Confirm each hit by reading the surrounding code. Ecosystems: **JVM** = Java/Kotlin, **JS** = JavaScript/TypeScript, **PY** = Python, **GO** = Go, **NET** = C#.

### A.1 Library families to record

| Family | JVM | JS | PY | GO | NET |
|---|---|---|---|---|---|
| web_framework | spring-boot-starter-web/-webflux, quarkus, micronaut, jax-rs/jersey, vert.x, ktor | express, fastify, koa, @nestjs/core, hapi, next, nuxt, hono | fastapi, flask, django, djangorestframework, starlette, aiohttp, sanic | net/http, gin, echo, chi, fiber, gorilla/mux | Microsoft.AspNetCore.* |
| http_client | RestTemplate/RestClient/WebClient (spring-web), okhttp, httpclient5, java.net.http, feign, retrofit | axios, node-fetch, undici, got, ky, superagent | requests, httpx, aiohttp, urllib3 | net/http, resty | HttpClient, Refit, RestSharp, Flurl |
| grpc / graphql | grpc-java, spring-graphql, graphql-java | @grpc/grpc-js, @apollo/server, graphql-yoga, apollo-client, urql | grpcio, graphene, strawberry, ariadne | google.golang.org/grpc, gqlgen | Grpc.AspNetCore, HotChocolate |
| db_driver / orm | JDBC drivers, spring-data-jpa, hibernate, mybatis, jooq, spring-data-mongodb | pg, mysql2, mongodb, mongoose, prisma, typeorm, sequelize, knex, drizzle | sqlalchemy, psycopg, pymysql, django ORM, pymongo, sqlmodel | database/sql, sqlx, gorm, pgx, mongo-driver | EF Core, Dapper, Npgsql, MongoDB.Driver |
| cache_client | lettuce, jedis, spring-data-redis, caffeine | ioredis, redis | redis, django-redis | go-redis | StackExchange.Redis |
| messaging | spring-kafka, spring-amqp, spring-cloud-stream, spring-jms, awspring sqs | kafkajs, amqplib, bullmq, sqs-consumer, @nestjs/microservices | kafka-python, confluent-kafka, aiokafka, pika, celery, boto3 (sqs) | segmentio/kafka-go, sarama, amqp091-go | Confluent.Kafka, MassTransit, Azure.Messaging.ServiceBus, RabbitMQ.Client |
| resilience | resilience4j, spring-retry, failsafe, spring-cloud-circuitbreaker | opossum, cockatiel, p-retry, axios-retry | tenacity, backoff, stamina, pybreaker | failsafe-go, gobreaker, cenkalti/backoff | Polly, Microsoft.Extensions.Http.Resilience |
| validation | hibernate-validator, jakarta.validation | zod, joi, yup, class-validator, ajv, express-validator, valibot | pydantic, marshmallow, cerberus, DRF serializers | go-playground/validator | FluentValidation, DataAnnotations |
| security_auth | spring-security, keycloak, jjwt, nimbus-jose-jwt | passport, jsonwebtoken, jose, express-session, next-auth/@auth/*, helmet, csurf alternatives, express-rate-limit | django.contrib.auth, flask-login, authlib, pyjwt, python-jose, fastapi-users, slowapi | golang-jwt, gorilla/sessions, casbin | Microsoft.AspNetCore.Authentication.*, Identity |
| templating | thymeleaf, freemarker, mustache, jsp | ejs, pug, handlebars, nunjucks | jinja2, django templates, mako | html/template, text/template | Razor |
| serialization / xml | jackson, gson, snakeyaml, xstream, jaxb | js-yaml, xml2js, fast-xml-parser, libxmljs | pyyaml, lxml, defusedxml, jsonpickle | encoding/xml, yaml.v3 | Newtonsoft.Json, System.Text.Json, YamlDotNet |
| frontend | react, angular, vue, svelte, solid; vite, webpack, rspack, turbopack, parcel; react-router, @angular/router, vue-router; @tanstack/*-query, swr, @reduxjs/toolkit (RTK Query), @apollo/client; lighthouse-ci (@lhci/cli), size-limit, bundlesize; web-vitals | | | | |
| cli_parser | picocli, jcommander, spring-shell | commander, yargs, oclif, cac, meow | argparse (stdlib), click, typer, fire | cobra, urfave/cli, flag (stdlib), kong | System.CommandLine, Spectre.Console.Cli, CommandLineParser |
| batch_scheduler | spring-batch, quartz, spring scheduling, shedlock | node-cron, @nestjs/schedule, agenda, bullmq repeatable | apache-airflow, dagster, prefect, apscheduler, celery beat, schedule | robfig/cron, go-co-op/gocron | Hangfire, Quartz.NET |
| cloud_sdk | aws-sdk v2, azure-*, google-cloud-* | @aws-sdk/*, @azure/*, @google-cloud/* | boto3, azure-*, google-cloud-* | aws-sdk-go-v2, azure-sdk-for-go | AWSSDK.*, Azure.* |
| logging | slf4j/logback/log4j2 | winston, pino, bunyan | logging, structlog, loguru | log/slog, zap, zerolog, logrus | Microsoft.Extensions.Logging, Serilog, NLog |

### A.2 App-type signals

- **backend_service:** any unit of kind `http_endpoint`, `grpc_method`, `graphql_operation`, `websocket` or `message_consumer` (Appendix A.3); or a server/worker bootstrap: `SpringApplication.run` with a web or messaging starter, `app.listen(`/`server.listen(`, `uvicorn.run`/`gunicorn`/`manage.py runserver` in a start script or Dockerfile `CMD`, `http.ListenAndServe`/`http.Server{`, `WebApplication.CreateBuilder` + `app.Run()`, `BackgroundService`/`IHostedService` workers, Celery workers (`celery -A … worker`).
- **frontend_web:** a browser framework dependency (react, @angular/core, vue, svelte, solid-js) **plus** a bundler or meta-framework config (`vite.config.*`, `webpack.config.*`, `angular.json`, `next.config.*`, `nuxt.config.*`, `svelte.config.*`, `remix.config.*`, `rsbuild.config.*`) or an `index.html` entry that loads a script bundle.
- **batch_job:** Spring Batch jobs, `@Scheduled`/`@Cron` methods, Quartz/Hangfire jobs, Airflow/Dagster/Prefect definitions, Celery beat schedules, APScheduler/`schedule` usage, node-cron/agenda, robfig/cron, Kubernetes `Job`/`CronJob` manifests pointing at this component, or a script entry point invoked by a scheduler (CronJob `command`, Dockerfile `CMD` of a run-to-completion script).
- **cli_tool:** `bin` in `package.json`; `[project.scripts]`, `[tool.poetry.scripts]` or `console_scripts`; Go `package main` under `cmd/` or the module root **with** argument parsing (`flag`, cobra, urfave/cli, kong) and no server bootstrap; picocli/JCommander/Spring Shell; System.CommandLine/Spectre.Console.Cli; argparse/click/typer/fire defining commands in a module with `if __name__ == "__main__"` or a script entry.
- **library:** none of the above.

### A.3 Unit signals

**HTTP / gRPC / GraphQL / WebSocket (`backend_service`)**

- JVM: `@RestController`, `@Controller`, `@RequestMapping`, `@(Get|Post|Put|Patch|Delete)Mapping`; JAX-RS `@Path` with `@GET|@POST|@PUT|@PATCH|@DELETE`; WebFlux `RouterFunctions.route()`, `coRouter {`; Micronaut `@Controller` + `@Get…`; Ktor `routing {` with `get(`/`post(`; gRPC `extends *ImplBase`, `@GrpcService`; GraphQL `@QueryMapping`, `@MutationMapping`, `@SchemaMapping`, `*.graphqls`; WebSocket `@ServerEndpoint`, `WebSocketHandler`, `@MessageMapping` (STOMP).
- JS: Express/Koa/Hapi `app|router.(get|post|put|patch|delete|all)(`, `app.use('<prefix>', router)`, `server.route({`; Fastify `fastify.(get|post|…)(`, `fastify.route({`, `register(…, {prefix})`; NestJS `@Controller('<prefix>')` + `@Get|@Post|@Put|@Patch|@Delete`, `@Resolver` + `@Query|@Mutation`, `@WebSocketGateway`; Next.js `app/**/route.(ts|js)` exporting `GET|POST|PUT|PATCH|DELETE`, `pages/api/**`, server actions (`'use server'` functions, ID `http:POST <route>#action:<name>`); SvelteKit `+server.(ts|js)`; Nuxt `server/api/**`; Hono `app.(get|post…)(`; Apollo `resolvers = { Query: {…}, Mutation: {…} }`; `@grpc/grpc-js` `server.addService(`.
- PY: FastAPI `@<app|router>.(get|post|put|patch|delete|api_route)(`, `include_router(…, prefix=)`; Flask `@<app|bp>.route(…, methods=[…])`, `@<app|bp>.(get|post|…)(`, `Blueprint(…, url_prefix=)`; Django `urlpatterns` with `path(`/`re_path(`/`include(`, DRF `@api_view([…])`, `APIView`, `ViewSet` + `router.register(`; aiohttp `web.(get|post…)(`, `add_route(`; gRPC `add_*Servicer_to_server(`; GraphQL graphene/strawberry/ariadne types; WebSocket `@app.websocket(`, Django Channels consumers.
- GO: `http.HandleFunc(`/`mux.HandleFunc(`/`Handle(` (Go 1.22 method patterns such as `"GET /items/{id}"`), gin `.(GET|POST|PUT|PATCH|DELETE|Any)(` and `.Group(`, echo `e.(GET|POST…)(` and `Group(`, chi `r.(Get|Post|Put|Patch|Delete)(` and `r.Route(`/`r.Mount(`, fiber `app.(Get|Post…)(`, gorilla `HandleFunc(…).Methods(`; gRPC `Register*Server(`; gqlgen resolvers.
- NET: `[ApiController]`/`ControllerBase` with `[Route]` and `[Http(Get|Post|Put|Patch|Delete)]`; minimal APIs `Map(Get|Post|Put|Patch|Delete)(`, `MapGroup(`; Razor Pages `@page`; `MapGrpcService<`; HotChocolate types; SignalR `MapHub<`.

**Message consumers (`backend_service`)**

- JVM: `@KafkaListener`, `@RabbitListener`, `@JmsListener`, `@SqsListener`, Spring Cloud Stream function beans bound by `spring.cloud.stream.bindings.<fn>-in-0.destination`.
- JS: kafkajs `consumer.subscribe(`/`consumer.run(`, amqplib `channel.consume(`, `sqs-consumer` `Consumer.create(`, BullMQ `new Worker(`, NestJS `@MessagePattern`/`@EventPattern`.
- PY: `KafkaConsumer(`, confluent `Consumer(…).subscribe(`, aiokafka, pika `basic_consume(`, Celery `@shared_task`/`@app.task` (`msg:celery:<task name>`), SQS polling loops with `receive_message(`.
- GO: kafka-go `NewReader(`, sarama `ConsumerGroup`/`ConsumeClaim`, `amqp` `Consume(`, SQS `ReceiveMessage(` loops.
- NET: MassTransit `IConsumer<`, `ServiceBusProcessor`, Confluent `consumer.Subscribe(`, RabbitMQ `BasicConsume(`.
- Serverless: functions triggered by queue/stream events in SAM/serverless/Azure Functions config.

**Batch (`batch_job`)**

- JVM: Spring Batch `new JobBuilder("<name>"`, `new StepBuilder("<name>"`, `jobBuilderFactory.get(`, `.chunk(`, `.tasklet(`; `@Scheduled(` (kind `scheduled_task`); Quartz `implements Job`; ShedLock annotations are controls, not units.
- JS: node-cron `cron.schedule(`, NestJS `@Cron(`/`@Interval(`, agenda `define(`, BullMQ repeatable jobs.
- PY: Airflow `DAG(`, `with DAG(`, `@dag`, operators with `task_id=`, `@task`; Dagster `@job`, `@op`, `@asset`, `ScheduleDefinition`; Prefect `@flow`, `@task`, `prefect.yaml`; APScheduler `add_job(`; `schedule.every(`; Celery `beat_schedule`.
- GO: robfig/cron `AddFunc(`, gocron `Every(`.
- NET: Hangfire `RecurringJob.AddOrUpdate(`, Quartz.NET `IJob`, timer-driven `BackgroundService`.
- Manifests: Kubernetes `CronJob` (unit `job:<metadata.name>`, `schedule`), `Job`.

**CLI (`cli_tool`)**

- JVM: picocli `@Command(name=`, `subcommands = {`, `@Option`, `@Parameters`; JCommander `@Parameter`; Spring Shell `@ShellMethod`/`@Command`.
- JS: commander `program.command(`/`.option(`/`.requiredOption(`/`.argument(`; yargs `.command(`/`.option(`; oclif classes in `src/commands/**`; `cac`; raw `process.argv`.
- PY: `argparse.ArgumentParser(`, `add_subparsers(`, `add_parser(`, `add_argument(`; click `@click.group`, `@click.command`, `@<group>.command`, `@click.option`, `@click.argument`; typer `typer.Typer(`, `@app.command(`; fire `fire.Fire(`.
- GO: cobra `&cobra.Command{Use:`, `AddCommand(`, `Flags()`; urfave/cli `&cli.Command{Name:`/`cli.App{`; std `flag.(String|Int|Bool…)(`; kong structs.
- NET: System.CommandLine `new RootCommand(`, `new Command("`, `new Option<`; Spectre.Console.Cli `CommandApp`, `AddCommand<`; CommandLineParser `[Verb(`/`[Option(`.

**Frontend routes (`frontend_web`)**

- React Router: `createBrowserRouter([`, `<Route path=`, `useRoutes([`; React Router v7 / Remix `app/routes/*` file names (`.` → `/`, `$id` → `{}`) and `routes.ts`.
- Next.js app router: `app/**/page.(tsx|jsx|ts|js)`; drop `(group)` segments and `@slot` folders; `[id]` → `{}`; `[...x]`/`[[...x]]` → `{}` with `attributes.catch_all: true`. Pages router: `pages/**` except `_app`, `_document`, `_error`, `api/`.
- Angular: `Routes = [` / `RouterModule.for(Root|Child)(` with `path:` (including nested `children` and `loadChildren`).
- Vue Router `routes: [` with `path:`; Nuxt `pages/**.vue`; SvelteKit `src/routes/**/+page.svelte`.

### A.4 Outbound-call signals (dependencies)

- JVM: `RestTemplate`, `RestClient`, `WebClient`, `java.net.http.HttpClient`, `OkHttpClient`, `HttpClients.create`/`HttpClientBuilder`, `@FeignClient`, `@HttpExchange` interfaces, Retrofit; gRPC `newBlockingStub|newStub|newFutureStub`; `DataSource`/`spring.datasource.*` (db); `RedisTemplate`, Lettuce/Jedis (cache); `KafkaTemplate.send`, `RabbitTemplate.convertAndSend`, `JmsTemplate.send`, `StreamBridge.send` (broker_publish); `JavaMailSender` (smtp); `LdapTemplate` (ldap); AWS/Azure/GCP SDK clients (cloud_sdk).
- JS: `fetch(`, `axios(`/`axios.<method>(`/`axios.create(`, `got`, `ky`, `undici.request(`, `http(s).request(`, `superagent`, Angular `HttpClient`, `new ApolloClient({ uri`, gRPC clients; db clients `pg.Pool`, `mysql2.createPool`, `mongoose.connect`, `new PrismaClient`, TypeORM `DataSource`, `knex(`; `ioredis`/`createClient` (redis); kafkajs `producer.send`, amqplib `sendToQueue`/`publish`; nodemailer; `@aws-sdk/client-*`.
- PY: `requests.<method>(`/`requests.Session(`, `httpx.(Client|AsyncClient|<method>)(`, `aiohttp.ClientSession(`, `urllib.request.urlopen(`, `urllib3.PoolManager(`; `grpc.(insecure|secure)_channel(`; `create_engine(`, `psycopg.connect(`, Django `DATABASES`, `MongoClient(`; `redis.Redis(`; `KafkaProducer(`, confluent `Producer(`, pika `basic_publish(`, Celery `.delay(`/`.apply_async(`; `smtplib.SMTP(`; `boto3.client|resource(`.
- GO: `http.(Get|Post|Head|PostForm)(`, `http.NewRequest(`, `&http.Client{`/`http.Client{`, `http.DefaultClient`, resty; `grpc.(Dial|NewClient)(`; `sql.Open(`, `sqlx.Connect(`, `gorm.Open(`, `pgxpool.New(`; go-redis `NewClient(`; kafka-go `Writer`, sarama producers; `smtp.SendMail(`; aws-sdk-go-v2 `NewFromConfig(`.
- NET: `HttpClient`, `IHttpClientFactory`/`AddHttpClient`, Refit, RestSharp, Flurl; `GrpcChannel.ForAddress(`; `DbContext`/`UseSqlServer|UseNpgsql`, `SqlConnection(`, Dapper; `ConnectionMultiplexer.Connect(`; Kafka `IProducer`, MassTransit `Publish(`/`Send(`, `ServiceBusSender`; `SmtpClient`; AWS/Azure SDK clients.
- Frontend: base API clients (`axios.create({ baseURL`, `fetch(` with an env base URL such as `import.meta.env.VITE_*`/`process.env.NEXT_PUBLIC_*`/Angular `environment.apiUrl`), GraphQL clients, tRPC clients.

### A.5 Raw data-access APIs

- JVM: `JdbcTemplate.(query|queryForObject|queryForList|update|execute|batchUpdate)(`, `NamedParameterJdbcTemplate`, `createNativeQuery(`, `createQuery(` (JPQL/HQL strings), `@Query(` (record `nativeQuery`), `Statement.execute*(`, `Connection.prepareStatement(`, `MongoTemplate` with `BasicQuery(`/`$where`, jOOQ `DSL.query(`/`fetch(String`.
- JS: `.query(` on pg/mysql2 clients, `sequelize.query(`, `knex.raw(`, `prisma.$queryRaw`/`$queryRawUnsafe`/`$executeRaw`/`$executeRawUnsafe`, TypeORM `.query(`/`.where(` with template strings, Mongo `$where`.
- PY: `cursor.execute(`/`executemany(`, `connection.execute(`, `session.execute(text(`, `engine.execute(`, Django `.raw(`, `.extra(`, `RawSQL(`, `connection.cursor()`, Mongo `$where`.
- GO: `db.(Query|QueryRow|Exec|QueryContext|ExecContext)(`, sqlx `Select(`/`Get(`, gorm `.Raw(`/`.Exec(`/`.Where("…"+`, pgx `conn.Query(`.
- NET: `new SqlCommand(`, `FromSqlRaw(`, `ExecuteSqlRaw(`, `FromSqlInterpolated(`, `ExecuteSqlCommand(`, Dapper `.Query(`/`.Execute(`.

### A.6 Risky sinks

| kind | JVM | JS | PY | GO | NET |
|---|---|---|---|---|---|
| os_exec | `Runtime.getRuntime().exec(`, `ProcessBuilder(` | `child_process.exec(`/`execSync(`/`spawn(`/`execFile(`, `shell: true` | `subprocess.run(`/`call(`/`Popen(`/`check_output(`, `os.system(`, `os.popen(` | `exec.Command(` | `Process.Start(` |
| dynamic_code | `ScriptEngine.eval(`, `SpelExpressionParser`/`parseExpression(`, `GroovyShell` | `eval(`, `new Function(`, `vm.run*(`, `setTimeout("…")` | `eval(`, `exec(`, `compile(` | `plugin.Open(` | `CSharpScript.EvaluateAsync(` |
| template_string | FreeMarker `new Template(` from strings, `?interpret`, Velocity `evaluate(` | `ejs.render(` / `pug.render(` / `Handlebars.compile(` on non-constant strings | Jinja2 `Template(`/`from_string(`, Flask `render_template_string(` | `template.New(…).Parse(` on non-constant strings | Razor runtime compilation of strings |
| deserialization | `ObjectInputStream.readObject(`, `XMLDecoder`, XStream `fromXML(`, Jackson `activateDefaultTyping`/`enableDefaultTyping`/`@JsonTypeInfo(use = Id.CLASS)`, SnakeYAML `new Yaml(` | `node-serialize`, `serialize-javascript` eval round-trips, js-yaml `load(` (record the js-yaml version) | `pickle.load(s)(`, `yaml.load(`/`yaml.unsafe_load(`, `marshal.loads(`, `shelve`, `jsonpickle.decode(`, `dill` | `gob.NewDecoder(` on network input | `BinaryFormatter`, `NetDataContractSerializer`, `LosFormatter`, Newtonsoft `TypeNameHandling` not `None` |
| xml_parser | `DocumentBuilderFactory`, `SAXParserFactory`, `XMLInputFactory`, `TransformerFactory`, `SAXReader`, `SAXBuilder`, `Unmarshaller` | `libxmljs.parseXml(`, `xml2js`, `fast-xml-parser` | `xml.etree.ElementTree`, `xml.dom.minidom`, `xml.sax`, `lxml.etree.parse(`/`fromstring(`/`XMLParser(` | `xml.NewDecoder(` | `XmlDocument`, `XmlReader.Create(`, `XmlTextReader` |
| file_path | `new File(`, `Paths.get(`, `Files.read…(`/`write…(`/`newInputStream(`/`copy(`, `FileInputStream(` | `fs.readFile…(`/`writeFile…(`/`createReadStream(`/`createWriteStream(`/`unlink…(`, `res.sendFile(`, `path.join(` with request data | `open(`, `os.remove(`, `shutil.*(`, `send_file(`, `FileResponse(` | `os.Open(`/`Create(`/`ReadFile(`/`WriteFile(`/`Remove(`, `http.ServeFile(` | `File.ReadAll*(`/`WriteAll*(`/`Open(`/`Delete(`, `PhysicalFile(`, `FileStream(` |
| html_raw | Thymeleaf `th:utext`, JSP `<%=`, `escapeXml="false"` | `dangerouslySetInnerHTML`, `v-html`, `[innerHTML]`, `bypassSecurityTrust`, `.innerHTML =`, `.outerHTML =`, `insertAdjacentHTML(`, `document.write(`, jQuery `.html(`, EJS `<%-`, Handlebars `{{{`, Pug `!=` | `\|safe`, `mark_safe(`, `{% autoescape off %}`, `Markup(`, Jinja2 `Environment(` without `autoescape` | `template.HTML(`, `text/template` used for HTML responses | `Html.Raw(`, `new HtmlString(`, `MarkupString` |
| redirect | `"redirect:" +`, `sendRedirect(`, `RedirectView(` | `res.redirect(`, `redirect(` (Next.js), `window.location =`, `location.href =`, `router.push(` with query-derived values | `redirect(`, `HttpResponseRedirect(`, `RedirectResponse(` | `http.Redirect(`, `c.Redirect(` | `Redirect(`, `LocalRedirect(` |

### A.7 Component fact keys (closed list)

| key | value | Signals | For app types |
|---|---|---|---|
| `runtime.long_running` | bool | Any backend unit or server/worker bootstrap (A.2). | all |
| `http.serves_browser_html` | bool | Server-side templates rendered by handlers, or the server serves an HTML entry/SPA bundle (`express.static`, `static/index.html`, Next/Nuxt SSR). | backend_service, frontend_web |
| `identity.authenticates_callers` | bool | Any authentication library or middleware is wired in (A.1 security_auth), or handlers read an authenticated principal. | backend_service, frontend_web |
| `identity.has_end_users` | bool \| unknown | Login/registration endpoints or pages, user entities, OIDC login, principal access (`@AuthenticationPrincipal`, `request.user`, `User.Identity`, `req.user`, `getServerSession`). | backend_service, frontend_web |
| `identity.mechanisms` | list of `jwt_bearer`, `session_cookie`, `oauth2_oidc_login`, `oauth2_resource_server`, `api_key`, `basic`, `mtls`, `saml`, `none_found` | Auth configuration and libraries. | backend_service, frontend_web |
| `identity.local_password_store` | bool | The app hashes or verifies passwords itself (password field on a persisted user, PasswordEncoder, bcrypt/argon2/scrypt/passlib, ASP.NET Identity, Django auth `User`). | backend_service |
| `authz.role_model` | bool | Roles, permissions, scopes or policies are defined or checked anywhere (`hasRole`, `@PreAuthorize`, `@RolesAllowed`, `[Authorize(Roles=…)]`/`[Authorize(Policy=…)]`, DRF permission classes, casbin, CASL, scope checks). | backend_service |
| `tenancy.multi_tenant` | bool \| unknown | `OVERRIDES.multi_tenant` first; else tenant/organisation IDs in entities plus tenant resolvers or filters. | backend_service |
| `async.event_loop` | bool | WebFlux/Reactor/Vert.x/reactive Quarkus routes; Node.js servers; Python `async def` handlers (FastAPI, Starlette, aiohttp, Sanic). Go and .NET are `false`. | backend_service |
| `messaging.consumes` | bool | Any `message_consumer` unit. | backend_service |
| `messaging.produces` | bool | Any `broker_publish` dependency. | backend_service, batch_job |
| `graphql.present` | bool | Any `graphql_operation` unit or GraphQL server library. | backend_service |
| `deploy.kinds` | list of deployment kinds, or `none_found` | Step 9. | all |
| `deploy.multi_instance` | bool \| unknown | `replicas` > 1 or an HPA/KEDA scaler → true; `replicas: 1` and no autoscaler → false; else unknown. | backend_service, batch_job |
| `platform.service_mesh` | `istio` \| `linkerd` \| `consul` \| `none_found` | `VirtualService`, `DestinationRule`, `ServiceProfile`, sidecar-injection labels/annotations. | backend_service |
| `platform.gateway_or_ingress` | list of `k8s_ingress`, `gateway_api`, `kong`, `nginx_conf`, `cloud_api_gateway`, `none_found` | Manifests and config files in the repo. | backend_service, frontend_web |
| `frontend.framework` | string | react, angular, vue, svelte, solid. | frontend_web |
| `frontend.meta_framework` | string \| `none_found` | next, nuxt, sveltekit, remix, react-router-framework, astro, analog. | frontend_web |
| `frontend.bundler` | string | vite, webpack, angular-cli (esbuild), rspack, turbopack, parcel. | frontend_web |
| `frontend.rendering` | `spa` \| `ssr` \| `ssg` \| `hybrid` | Meta-framework and config. | frontend_web |
| `frontend.data_fetching` | list | tanstack-query, swr, rtk-query, apollo, plain-fetch, axios, angular-httpclient. | frontend_web |
| `frontend.third_party_scripts` | bool | `<script src="https://…">` in HTML entries, tag managers, analytics or chat widgets loaded by URL. | frontend_web |
| `frontend.has_images` | bool | `<img`, `next/image`, `NgOptimizedImage`, image imports in source. | frontend_web |
| `cli.parser` | string | A.1 cli_parser. | cli_tool |
| `cli.network` | bool \| unknown | Any http/grpc/db/cloud_sdk dependency in the component. | cli_tool |
| `cli.reads_stdin_or_files` | bool \| unknown | stdin reads, file-path arguments, `-` handling. | cli_tool |
| `files.writes_outputs` | bool \| unknown | Writes files (non-log) as part of its job. | batch_job, cli_tool |
| `ci.files` | list of paths, or `none_found` | `.github/workflows/*.y*ml`, `.gitlab-ci.yml`, `Jenkinsfile`, `azure-pipelines.yml`, `.circleci/config.yml`, `bitbucket-pipelines.yml`, `.buildkite/*`. | all |
| `deps.lockfiles` | list of paths, or `none_found` | Step 1. | all |

---

## Appendix B — facts.json format

### B.1 Top level

```json
{
  "schema_version": "prs-facts/1",
  "prompt": "01-fact-discovery@1",
  "catalog_version": 1,
  "run": {"code_root": ".", "config_paths": [], "overrides": "none", "commit": "<git HEAD or unknown>"},
  "components": [],
  "component_facts": [],
  "units": [],
  "dependencies": [],
  "data_access": [],
  "sinks": [],
  "deployments": [],
  "unresolved": [],
  "routing": [],
  "discovery_log": []
}
```

### B.2 Component

```json
{
  "id": "cmp:services/orders", "slug": "services_orders", "root": "services/orders", "name": "orders-service",
  "languages": ["java"], "manifests": ["services/orders/pom.xml"], "lockfiles": [],
  "libraries": [
    {"name": "org.springframework.boot:spring-boot-starter-web", "family": "web_framework",
     "version": "managed", "version_source": "managed:spring-boot-starter-parent 3.3.2",
     "evidence": [{"file": "services/orders/pom.xml", "line": 31, "symbol": "", "snippet": "<artifactId>spring-boot-starter-web</artifactId>"}]}
  ],
  "app_types": ["backend_service", "batch_job"],
  "primary_app_type": "backend_service",
  "app_type_evidence": {"backend_service": [], "batch_job": []}
}
```

### B.3 Unit

```json
{
  "id": "http:POST /api/orders", "component_id": "cmp:services/orders", "app_type": "backend_service",
  "kind": "http_endpoint",
  "handler": {"file": "services/orders/src/main/java/com/acme/OrderController.java", "symbol": "OrderController.create", "line": 48},
  "attributes": {"method": "POST", "path": "/api/orders", "resolved": true},
  "inputs": [
    {"id": "http:POST /api/orders~in:body:CreateOrderRequest", "location": "body", "name": "CreateOrderRequest", "type": "CreateOrderRequest", "evidence": []}
  ],
  "evidence": []
}
```

`kind` and its attributes (all attributes also allow `"unknown"`; `resolved` is required on every unit):

| kind | attributes |
|---|---|
| `http_endpoint` | `method`, `path`, `framework`, `mutating` (method in POST/PUT/PATCH/DELETE, or ANY), `returns_collection` (return type is a list/array/page/stream/QuerySet, or handler name starts with `list`/`findAll`/`search`/`getAll`), `resource_id_params` (path params that identify a record: names `id`, `*Id`, `*_id`, `uuid`, `slug`, `key`), `accepts_files` (multipart/file inputs), `is_login` (POST to a path or handler matching `login`, `signin`, `sign-in`, `token`, `authenticate` or `session`), `issues_redirect`, `bulk_io` (handler streams/reads/writes files, exports or imports data, or returns file downloads) |
| `grpc_method` | `service`, `method`, `streaming` (`none`/`client`/`server`/`bidi`), `mutating` (method name starts with Create, Update, Delete, Remove, Set, Put, Add, Insert, Upsert, Patch, Cancel, Submit, Approve, Reject) |
| `graphql_operation` | `operation_type` (`Query`/`Mutation`/`Subscription`), `field`, `mutating` (`operation_type == Mutation`), `returns_collection` |
| `websocket` | `path` |
| `message_consumer` | `broker`, `destination`, `group`, `mutating` (handler writes to a store or publishes) |
| `ui_route` | `path`, `framework`, `fetches_data` (route component or loader calls an API or data-fetching hook), `catch_all` |
| `batch_job` | `framework`, `schedule`, `steps` (step unit IDs), `writes_data`, `reads` (list of `file`, `db`, `api`, `queue`), `deployment_ids` |
| `batch_step` | `job`, `step_type` (`chunk`/`tasklet`/`task`/`operator`), `reader`, `processor`, `writer`, `writes_data` |
| `scheduled_task` | `framework`, `schedule`, `writes_data`, `in_process` (runs inside a long-running service) |
| `cli_command` | `program`, `command_path` (list), `parser`, `flags` (list), `positionals` (list), `reads_stdin`, `reads_files`, `writes_files`, `network` |

### B.4 Other records

```json
{"id": "dep:http:payment-service", "component_id": "cmp:services/orders", "protocol": "http",
 "client": "spring-web RestClient", "client_version": "managed", "target": "config:payment.base-url",
 "url_from_input": false, "config_keys": ["payment.base-url"], "call_sites": [], "evidence": []}

{"id": "dba:services/orders/src/main/java/com/acme/ReportDao.java#ReportDao.search", "component_id": "cmp:services/orders",
 "technology": "jdbc", "api": "JdbcTemplate.query", "evidence": []}

{"id": "sink:os_exec:tools/cli.py#export", "component_id": "cmp:tools", "kind": "os_exec", "api": "subprocess.run",
 "input_derived": "unknown", "evidence": []}

{"id": "deploy:k8s/orders.yaml#Deployment/orders", "component_id": "cmp:services/orders", "kind": "Deployment",
 "name": "orders", "file": "k8s/orders.yaml", "attributes": {"replicas": 3, "templated": false}, "evidence": []}

{"component_id": "cmp:services/orders", "key": "identity.has_end_users", "value": true, "evidence": []}

{"what": "router mounted from variable `routes[name]`", "where": "src/app.ts:88", "reason": "DYNAMIC_CONSTRUCT"}
```
